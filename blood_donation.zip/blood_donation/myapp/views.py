from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
import datetime
from django.utils import timezone
import re
from django.http import JsonResponse
from django.contrib import messages
from django.contrib.auth.models import User, Group
from django.db.models import Q, Max
from myapp.models import user_table, patient_table, hospitl_table, donor_table, blood_banks_table, blood_requests_table, donation_history_table, donor_response_table, transfusion_table, blood_inventory_table, blood_allocation_table, appointment_table
from myapp.location_utils import (
    calculate_distance_km,
    format_distance_str,
    get_coordinates_from_location,
    is_blood_compatible,
    get_compatible_donor_groups,
    get_nearest_hospitals,
    get_nearest_blood_banks,
    get_nearest_donors,
    rank_blood_requests_by_distance,
)



# Create your views here.

def parse_units_required(units_str):
    try:
        parts = str(units_str).strip().split()
        return max(1, int(parts[0]))
    except Exception:
        return 1

def index(request):
    return render(request, 'index.html')


def loginpage(request):
    return render(request,'login.html')


def login_get(request):
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user = authenticate(request,username=username,password=password)
        if user is not None:
            if user.groups.filter(name="admin").exists():
                login(request,user)
                return redirect('/myapp/admin_home/')
            elif user.groups.filter(name="patient").exists():
                login(request,user)
                try:
                    patient = patient_table.objects.get(LOGIN=user)
                    if patient.is_first_login:
                        patient.is_first_login = False
                        patient.save()
                        return redirect('/myapp/patient_blood_request/')
                    else:
                        return redirect('/myapp/patient_home/')
                except patient_table.DoesNotExist:
                    return redirect('/myapp/patient_home/')
            elif user.groups.filter(name="donor").exists():
                login(request,user)
                return redirect('/myapp/donor_home/')
            elif user.groups.filter(name="bloodbank").exists():
                login(request,user)
                return redirect('/myapp/bloodbank_home/')
            elif user.groups.filter(name="hospital").exists():
                login(request,user)
                return redirect('/myapp/hospital_home/')
        else:
            messages.error(request, "Invalid username or password!")
            return redirect('/myapp/loginpage/')
    return redirect('/myapp/loginpage/')

#################################admin########################
def admin_home(request):
    if not request.user.is_authenticated or not request.user.groups.filter(name='admin').exists():
        messages.error(request, "Access restricted to administrators.")
        return redirect('/myapp/loginpage/')

    total_hospitals = hospitl_table.objects.count()
    total_bloodbanks = blood_banks_table.objects.count()
    total_donors = donor_table.objects.count()
    total_patients = patient_table.objects.count()
    total_requests = blood_requests_table.objects.count()

    pending_hospitals = hospitl_table.objects.filter(status='pending').count()
    pending_bloodbanks = blood_banks_table.objects.filter(status='pending').count()

    recent_hospitals = hospitl_table.objects.order_by('-id')[:5]
    recent_bloodbanks = blood_banks_table.objects.order_by('-id')[:5]

    context = {
        'total_hospitals': total_hospitals,
        'total_bloodbanks': total_bloodbanks,
        'total_donors': total_donors,
        'total_patients': total_patients,
        'total_requests': total_requests,
        'pending_hospitals': pending_hospitals,
        'pending_bloodbanks': pending_bloodbanks,
        'recent_hospitals': recent_hospitals,
        'recent_bloodbanks': recent_bloodbanks,
    }
    return render(request, 'admin/admin_home.html', context)


def verify_blood_bank(request):
    if not request.user.is_authenticated or not request.user.groups.filter(name='admin').exists():
        messages.error(request, "Access restricted to administrators.")
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        bb_id = request.POST.get('blood_bank_id')
        action = request.POST.get('action')
        try:
            bb = blood_banks_table.objects.get(id=bb_id)
            if action == 'approve':
                bb.status = 'active'
                bb.save()
                messages.success(request, f"Blood Bank '{bb.blood_bank_name}' has been verified and activated.")
            elif action == 'reject':
                bb.status = 'rejected'
                bb.save()
                messages.warning(request, f"Blood Bank '{bb.blood_bank_name}' has been rejected.")
        except blood_banks_table.DoesNotExist:
            messages.error(request, "Blood Bank record not found.")

        return redirect('/myapp/verify_blood_bank/')

    blood_banks = blood_banks_table.objects.all().order_by('-id')
    return render(request, 'admin/verify_blood_bank.html', {'blood_banks': blood_banks})


def verify_hospital(request):
    if not request.user.is_authenticated or not request.user.groups.filter(name='admin').exists():
        messages.error(request, "Access restricted to administrators.")
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        hosp_id = request.POST.get('hospital_id')
        action = request.POST.get('action')
        try:
            hosp = hospitl_table.objects.get(id=hosp_id)
            if action == 'approve':
                hosp.status = 'active'
                hosp.save()
                messages.success(request, f"Hospital '{hosp.hospital_name}' has been verified and activated.")
            elif action == 'reject':
                hosp.status = 'rejected'
                hosp.save()
                messages.warning(request, f"Hospital '{hosp.hospital_name}' has been rejected.")
        except hospitl_table.DoesNotExist:
            messages.error(request, "Hospital record not found.")

        return redirect('/myapp/verify_hospital/')

    hospitals = hospitl_table.objects.all().order_by('-id')
    return render(request, 'admin/verify_hospital.html', {'hospitals': hospitals})


############################## API Endpoints ######################

def api_nearby_facilities(request):
    """
    JSON API endpoint returning nearby hospitals, blood banks, and compatible donors
    based on requested location and optional blood group.
    """
    location = request.GET.get('location', '').strip()
    blood_group = request.GET.get('blood_group', '').strip()
    
    if not location and request.user.is_authenticated:
        try:
            pt = patient_table.objects.get(LOGIN=request.user)
            location = pt.address or ''
            if not blood_group:
                blood_group = pt.blood_group or ''
        except Exception:
            try:
                dn = donor_table.objects.get(LOGIN=request.user)
                location = dn.address or ''
                if not blood_group:
                    blood_group = dn.blood_group or ''
            except Exception:
                pass
                
    if not location:
        location = 'Kozhikode, Kerala'
        
    nearest_hospitals = get_nearest_hospitals(location, limit=8)
    nearest_blood_banks = get_nearest_blood_banks(location, blood_group=blood_group, limit=8)
    nearest_donors = get_nearest_donors(location, blood_group=blood_group, limit=8)
    compatible_groups = get_compatible_donor_groups(blood_group) if blood_group else []

    hospitals_data = []
    for h in nearest_hospitals:
        hospitals_data.append({
            'id': h['id'],
            'name': h['hospital_name'],
            'address': h['address'],
            'phone': str(h['phone']),
            'email': h['email'],
            'has_blood_bank': h['has_blood_bank'],
            'distance_km': h['distance_km'],
            'distance_str': h['distance_str'],
        })

    blood_banks_data = []
    for bb in nearest_blood_banks:
        blood_banks_data.append({
            'id': bb['id'],
            'name': bb['blood_bank_name'],
            'address': bb['address'],
            'phone': str(bb['phone']),
            'email': bb['email'],
            'distance_km': bb['distance_km'],
            'distance_str': bb['distance_str'],
            'stock_units': bb['stock_units'],
            'stock_status': bb['stock_status'],
        })

    donors_data = []
    for d in nearest_donors:
        donors_data.append({
            'id': d['id'],
            'name': d['name'],
            'blood_group': d['blood_group'],
            'address': d['address'],
            'phone': str(d['phone']) if d['phone'] else '',
            'distance_km': d['distance_km'],
            'distance_str': d['distance_str'],
        })

    return JsonResponse({
        'success': True,
        'location': location,
        'blood_group': blood_group,
        'compatible_groups': compatible_groups,
        'hospitals': hospitals_data,
        'blood_banks': blood_banks_data,
        'donors': donors_data,
    })


##############################patient######################

def check_and_update_timeouts():
    try:
        timed_out_reqs = blood_requests_table.objects.filter(
            required_date__lt=datetime.date.today()
        ).exclude(
            request_status__in=['COMPLETED', 'REJECTED', 'TIMED OUT']
        )
        for req in timed_out_reqs:
            # Check for any active RESERVED allocations linked to this request
            active_allocs = blood_allocation_table.objects.filter(BLOOD_REQUEST=req, status='RESERVED')
            for alloc in active_allocs:
                # Restore units to blood bank inventory
                inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=alloc.BLOOD_BANK, blood_group=alloc.blood_group).first()
                if inv_item:
                    try:
                        avail = int(inv_item.units_available)
                    except ValueError:
                        avail = 0
                    inv_item.units_available = str(avail + alloc.units_allocated)
                    inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                    inv_item.save()
                alloc.status = 'RETURNED'
                alloc.notes = f"Automatically returned {alloc.units_allocated} unit(s) due to request timeout."
                alloc.save()
            req.request_status = 'TIMED OUT'
            req.save()
            transfusion_table.objects.filter(BLOOD_REQUEST=req).delete()
    except Exception:
        pass


def patient_home(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')
    
    check_and_update_timeouts()
    
    # Get profile
    patient_profile = None
    patient_age = None
    try:
        patient_profile = patient_table.objects.get(LOGIN=request.user)
        if patient_profile.dob:
            today = datetime.date.today()
            dob_date = patient_profile.dob
            patient_age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
    except patient_table.DoesNotExist:
        pass

    patient_loc = patient_profile.address if (patient_profile and patient_profile.address) else 'Kozhikode, Kerala'
    patient_bg = patient_profile.blood_group if patient_profile else None

    # Donation history and donor profile
    donations = []
    donor_profile = None
    try:
        donor_profile = donor_table.objects.get(LOGIN=request.user)
        donations = donation_history_table.objects.filter(DONOR=donor_profile).order_by('-donation_date')
    except Exception:
        pass

    next_eligible_date = None
    if donor_profile and donor_profile.last_donation_date:
        next_eligible_date = donor_profile.last_donation_date + datetime.timedelta(days=90)

    # Get patient's own requests (My Requests - UI format 16)
    my_requests = []
    latest_request_response = None
    accepted_responses = []
    accepted_count = 0
    if patient_profile:
        raw_requests = blood_requests_table.objects.filter(PATIENT=patient_profile).order_by('-id')
        for req in raw_requests:
            req.is_creator = True
            req.is_my_donation = False
            req_accepted = donor_response_table.objects.filter(BLOOD_REQUEST=req, response_status__in=['ACCEPTED', 'ASSIGNED']).order_by('-id')
            req.accepted_responses = list(req_accepted)
            req.accepted_count = req_accepted.count()
            req.latest_response = req_accepted.first()
            req.assigned_donor = req_accepted.filter(response_status='ASSIGNED').first()
            # Attach distance to hospital
            req_hosp_loc = req.HOSPITAL.address if req.HOSPITAL else ''
            req.distance_km = calculate_distance_km(patient_loc, req_hosp_loc)
            req.distance_str = format_distance_str(req.distance_km)
            my_requests.append(req)
    user_donor = donor_profile
    if not user_donor and patient_profile:
        user_donor = donor_table.objects.filter(LOGIN=request.user).first()

    if my_requests:
        accepted_responses = my_requests[0].accepted_responses
        accepted_count = my_requests[0].accepted_count
        latest_request_response = my_requests[0].latest_response

    # Get all verified and normal requests (Verified Requests - UI format 13)
    verified_requests = blood_requests_table.objects.filter(request_status__in=['APPROVED', 'PENDING']).order_by('-id')
    if patient_profile:
        verified_requests = verified_requests.filter(blood_group=patient_profile.blood_group).exclude(PATIENT=patient_profile)

    # Exclude requests that this user has already confirmed/accepted to donate for
    if user_donor:
        already_accepted_ids = donor_response_table.objects.filter(
            DONOR=user_donor,
            response_status__in=['ACCEPTED', 'ASSIGNED']
        ).values_list('BLOOD_REQUEST_id', flat=True)
        verified_requests = verified_requests.exclude(id__in=already_accepted_ids)
    
    # Rank verified requests by distance from patient location
    verified_requests = rank_blood_requests_by_distance(verified_requests, patient_loc)
    if donor_profile and donor_profile.last_donation_date:
        next_eligible_date = donor_profile.last_donation_date + datetime.timedelta(days=90)

    # Build dynamic notifications
    notifications = []
    
    # Fetch all approved emergency requests created by hospitals
    hospital_emergencies = blood_requests_table.objects.filter(
        emergency='yes',
        request_status='APPROVED',
        PATIENT__LOGIN__username='hospital_emergency'
    ).order_by('-id')

    for req in hospital_emergencies:
        notifications.append({
            'title': '🚨 Hospital Emergency Request',
            'message': f"Emergency: {req.blood_group} blood ({req.units_required} units) required at {req.HOSPITAL.hospital_name}.",
            'time': f"Published on {req.created_at}",
            'icon': 'bi-exclamation-triangle-fill',
            'class': 'bg-red-light',
            'is_emergency': True
        })
    
    # 1. Patient's own requests notifications
    for req in my_requests:
        if req.request_status == 'PENDING':
            notifications.append({
                'title': 'Request Verification Pending',
                'message': f"Your request for {req.blood_group} ({req.units_required}) at {req.HOSPITAL.hospital_name} is registered and pending verification.",
                'time': f"Submitted on {req.created_at}",
                'icon': 'bi-clock-history',
                'class': 'bg-blue-light'
            })
        elif req.request_status == 'APPROVED':
            notifications.append({
                'title': 'Request Verified & Published',
                'message': f"Your request for {req.blood_group} ({req.units_required}) has been verified and published to active donors.",
                'time': f"Approved",
                'icon': 'bi-check-circle-fill',
                'class': 'bg-green-light'
            })
        elif req.request_status == 'REJECTED':
            notifications.append({
                'title': 'Request Rejected',
                'message': f"Your request for {req.blood_group} has been rejected by the hospital.",
                'time': f"Processed",
                'icon': 'bi-x-circle-fill',
                'class': 'bg-red-light'
            })

    # 2. General notifications (matched blood requests from others)
    if patient_profile:
        matched_reqs = blood_requests_table.objects.filter(
            request_status='APPROVED',
            blood_group=patient_profile.blood_group
        ).exclude(PATIENT=patient_profile).order_by('-id')[:5]
        
        for req in matched_reqs:
            notifications.append({
                'title': 'Urgent Blood Requirement Matched',
                'message': f"An urgent request for blood group {req.blood_group} ({req.units_required}) is available for donation at {req.HOSPITAL.hospital_name}.",
                'time': f"Published on {req.created_at}",
                'icon': 'bi-droplet-fill',
                'class': 'bg-red-light'
            })

    # Check if this user has any active blood requests that are not completed/rejected/timed out
    has_active_request = False
    if patient_profile:
        has_active_request = blood_requests_table.objects.filter(
            PATIENT=patient_profile
        ).exclude(request_status__in=['COMPLETED', 'REJECTED', 'TIMED OUT']).exists()

    hospitals = hospitl_table.objects.all()
    nearest_hospitals = get_nearest_hospitals(patient_loc, limit=6)
    nearest_bloodbanks = get_nearest_blood_banks(patient_loc, blood_group=patient_bg, limit=6)

    context = {
        'profile': patient_profile,
        'user_table': patient_profile.USER if patient_profile else None,
        'patient_age': patient_age,
        'role': 'patient',
        'my_requests': my_requests,
        'verified_requests': verified_requests,
        'donations': donations,
        'donor_profile': donor_profile,
        'notifications': notifications,
        'latest_request_response': latest_request_response,
        'next_eligible_date': next_eligible_date,
        'accepted_responses': accepted_responses,
        'accepted_count': accepted_count,
        'has_active_request': has_active_request,
        'latest_emergency': hospital_emergencies.first(),
        'hospitals': hospitals,
        'nearest_hospitals': nearest_hospitals,
        'nearest_bloodbanks': nearest_bloodbanks,
        'user_location': patient_loc,
    }
    return render(request,'patient/patient_home.html', context)

def patient_registration(request):
    # Ensure there is at least one hospital to select
    hospitals = hospitl_table.objects.all()
    if not hospitals.exists():
        # Let's seed a default hospital
        h_user, created = User.objects.get_or_create(username='gov_hospital', email='gov_hospital@gmail.com')
        if created:
            h_user.set_password('Hospital@123')
            h_user.save()
            h_group, _ = Group.objects.get_or_create(name='hospital')
            h_user.groups.add(h_group)
        
        h_user_tab, created = user_table.objects.get_or_create(
            LOGIN=h_user,
            defaults={
                'name': 'Government Medical College Hospital',
                'email': 'gov_hospital@gmail.com',
                'phone': 9876543210,
                'role': 'hospital',
                'status': 'active',
                'created_at': datetime.date.today()
            }
        )
        
        hospitl_table.objects.get_or_create(
            LOGIN=h_user,
            USER=h_user_tab,
            defaults={
                'hospital_name': 'Government Medical College Hospital',
                'license_number': 'LIC123456',
                'address': 'Kozhikode, Kerala',
                'contact_person': 'Dr. John Doe',
                'phone': 9876543210,
                'email': 'gov_hospital@gmail.com',
                'status': 'active'
            }
        )
        hospitals = hospitl_table.objects.all()

    if request.method == 'POST':
        full_name = request.POST.get('full_name', '').strip()
        dob = request.POST.get('dob')
        gender = request.POST.get('gender')
        blood_group = request.POST.get('blood_group')
        phone = request.POST.get('phone', '').strip()
        email = request.POST.get('email', '').strip()
        address = request.POST.get('address', '').strip()
        hospital_id = request.POST.get('hospital')
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validation
        if not username:
            messages.error(request, "Username is required!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "Username is already taken!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "Email is already registered!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        # Email format validation
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            messages.error(request, "Please enter a valid email address!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        # Phone number validation (exactly 10 digits)
        if not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must be exactly 10 digits!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        # Date of birth validation (above 18 and max 150)
        if dob:
            try:
                dob_date = datetime.datetime.strptime(dob, "%Y-%m-%d").date()
                today = datetime.date.today()
                age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
                if age < 18:
                    messages.error(request, "You must be at least 18 years old to register.")
                    return render(request, 'patient/registration.html', {'hospitals': hospitals})
                if age > 150:
                    messages.error(request, "Age must be at most 150 years old.")
                    return render(request, 'patient/registration.html', {'hospitals': hospitals})
            except ValueError:
                messages.error(request, "Invalid Date of Birth format!")
                return render(request, 'patient/registration.html', {'hospitals': hospitals})
        else:
            messages.error(request, "Date of Birth is required!")
            return render(request, 'patient/registration.html', {'hospitals': hospitals})

        hospital_obj = None
        if hospital_id:
            try:
                hospital_obj = hospitl_table.objects.get(id=hospital_id)
            except (hospitl_table.DoesNotExist, ValueError):
                messages.error(request, "Selected hospital does not exist!")
                return render(request, 'patient/registration.html', {'hospitals': hospitals})

        # Create Django User
        user = User.objects.create_user(username=username, password=password, email=email)
        
        # Add User to patient Group
        group, _ = Group.objects.get_or_create(name='patient')
        user.groups.add(group)

        # Create user_table Profile
        u_tab = user_table.objects.create(
            LOGIN=user,
            name=full_name,
            email=email,
            phone=phone,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )

        # Create patient_table entry
        patient_table.objects.create(
            LOGIN=user,
            USER=u_tab,
            HOSPITAL=hospital_obj,
            name=full_name,
            dob=dob_date,
            blood_group=blood_group,
            address=address
        )

        messages.success(request, "Registration successful! Please login.")
        return redirect('/myapp/loginpage/')

    return render(request, 'patient/registration.html', {'hospitals': hospitals})

def patient_blood_request(request):
    hospitals = hospitl_table.objects.all()
    patient_profile = None
    patient_age = None
    if request.user.is_authenticated:
        try:
            patient_profile = patient_table.objects.get(LOGIN=request.user)
            if patient_profile.dob:
                today = datetime.date.today()
                dob_date = patient_profile.dob
                patient_age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
        except patient_table.DoesNotExist:
            # Check if they are a donor
            try:
                donor_profile = donor_table.objects.get(LOGIN=request.user)
                class TempPatientProfile:
                    def __init__(self, donor):
                        self.name = donor.USER.name
                        self.dob = donor.dob
                        self.blood_group = donor.blood_group
                        self.address = donor.address
                        self.USER = donor.USER
                patient_profile = TempPatientProfile(donor_profile)
                if patient_profile.dob:
                    dob_val = patient_profile.dob
                    if isinstance(dob_val, str):
                        try:
                            dob_date = datetime.datetime.strptime(dob_val, "%Y-%m-%d").date()
                        except ValueError:
                            dob_date = None
                    else:
                        dob_date = dob_val
                    
                    if dob_date:
                        today = datetime.date.today()
                        patient_age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
            except donor_table.DoesNotExist:
                pass

    patient_loc = 'Kozhikode, Kerala'
    patient_bg = None
    if patient_profile:
        if hasattr(patient_profile, 'address') and patient_profile.address:
            patient_loc = patient_profile.address
        if hasattr(patient_profile, 'blood_group') and patient_profile.blood_group:
            patient_bg = patient_profile.blood_group

    if request.method == 'POST':
        if not request.user.is_authenticated:
            messages.error(request, "Please login to submit a request.")
            return redirect('/myapp/loginpage/')
            
        patient_name = request.POST.get('patient_name')
        age = request.POST.get('age')
        blood_group = request.POST.get('blood_group')
        units_required = request.POST.get('units_required')
        hospital_id = request.POST.get('hospital')
        location = request.POST.get('location')
        required_date_str = request.POST.get('required_date')
        description = request.POST.get('description')
        document = request.FILES.get('document')

        # Form Validation
        if not (patient_name and age and blood_group and units_required and location and required_date_str and description):
            messages.error(request, "All fields are required!")
            return render(request, 'patient/blood_request.html', {
                'hospitals': hospitals,
                'patient_profile': patient_profile,
                'patient_age': patient_age,
                'patient_location': patient_loc,
            })

        # Age validation
        try:
            age_int = int(age)
            if age_int <= 0 or age_int > 150:
                messages.error(request, "Please enter a valid age (1-150)!")
                return render(request, 'patient/blood_request.html', {
                    'hospitals': hospitals,
                    'patient_profile': patient_profile,
                    'patient_age': patient_age,
                    'patient_location': patient_loc,
                })
        except ValueError:
            messages.error(request, "Age must be a valid number!")
            return render(request, 'patient/blood_request.html', {
                'hospitals': hospitals,
                'patient_profile': patient_profile,
                'patient_age': patient_age,
                'patient_location': patient_loc,
            })

        # Required Date validation (must not be in the past)
        try:
            req_date = datetime.datetime.strptime(required_date_str, "%Y-%m-%d").date()
            if req_date < datetime.date.today():
                messages.error(request, "Required date cannot be in the past!")
                return render(request, 'patient/blood_request.html', {
                    'hospitals': hospitals,
                    'patient_profile': patient_profile,
                    'patient_age': patient_age,
                    'patient_location': patient_loc,
                })
        except ValueError:
            messages.error(request, "Invalid required date format!")
            return render(request, 'patient/blood_request.html', {
                'hospitals': hospitals,
                'patient_profile': patient_profile,
                'patient_age': patient_age,
                'patient_location': patient_loc,
            })

        # Hospital resolution
        hospital_obj = None
        if hospital_id:
            try:
                hospital_obj = hospitl_table.objects.get(id=hospital_id)
            except (hospitl_table.DoesNotExist, ValueError):
                pass
        if not hospital_obj:
            hospital_obj = hospitl_table.objects.first()

        if not hospital_obj:
            messages.error(request, "No hospital is currently available in the system.")
            return render(request, 'patient/blood_request.html', {
                'hospitals': hospitals,
                'patient_profile': patient_profile,
                'patient_age': patient_age,
                'patient_location': patient_loc,
            })

        # Optional Document validation
        if document:
            if document.size > 5 * 1024 * 1024:
                messages.error(request, "File size must not exceed 5 MB!")
                return render(request, 'patient/blood_request.html', {
                    'hospitals': hospitals,
                    'patient_profile': patient_profile,
                    'patient_age': patient_age,
                    'patient_location': patient_loc,
                })
            
            import os
            ext = os.path.splitext(document.name)[1].lower()
            if ext not in ['.jpg', '.jpeg', '.png', '.pdf']:
                messages.error(request, "Supported file formats are JPG, PNG, or PDF!")
                return render(request, 'patient/blood_request.html', {
                    'hospitals': hospitals,
                    'patient_profile': patient_profile,
                    'patient_age': patient_age,
                    'patient_location': patient_loc,
                })

        # Get patient profile
        try:
            p_profile = patient_table.objects.get(LOGIN=request.user)
            # Ensure name, blood group, address match if updated
            if p_profile.name != patient_name and patient_name:
                p_profile.name = patient_name
            if blood_group:
                p_profile.blood_group = blood_group
            if location:
                p_profile.address = location
            p_profile.save()
            patient_profile = p_profile
        except patient_table.DoesNotExist:
            # If not a patient, check if they are a donor
            try:
                donor_profile = donor_table.objects.get(LOGIN=request.user)
                # Create patient profile for them
                patient_profile = patient_table.objects.create(
                    LOGIN=request.user,
                    USER=donor_profile.USER,
                    HOSPITAL=hospital_obj,
                    name=donor_profile.USER.name or patient_name,
                    dob=donor_profile.dob,
                    blood_group=blood_group or donor_profile.blood_group,
                    address=location or donor_profile.address
                )
                # Add to patient group
                group, _ = Group.objects.get_or_create(name='patient')
                request.user.groups.add(group)
            except donor_table.DoesNotExist:
                messages.error(request, "Only registered patients or donors can raise blood requests.")
                return render(request, 'patient/blood_request.html', {
                    'hospitals': hospitals,
                    'patient_profile': patient_profile,
                    'patient_age': patient_age,
                    'patient_location': patient_loc,
                })

        # Save to database
        blood_requests_table.objects.create(
            PATIENT=patient_profile,
            HOSPITAL=hospital_obj,
            blood_group=blood_group,
            units_required=units_required,
            location=location,
            description=description,
            request_status='PENDING',
            emergency='yes',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            verified_at='',
            patient_name=patient_name,
            age=age_int,
            required_date=req_date,
            document=document
        )

        # Automatically register patient as a donor if not already exists, or sync profile
        if not donor_table.objects.filter(LOGIN=request.user).exists():
            donor_table.objects.create(
                LOGIN=request.user,
                USER=patient_profile.USER,
                dob=patient_profile.dob if patient_profile.dob else datetime.date(2000, 1, 1),
                blood_group=patient_profile.blood_group,
                address=patient_profile.address,
                eligibility_status='eligible'
            )
            # Add User to donor Group
            group, _ = Group.objects.get_or_create(name='donor')
            request.user.groups.add(group)
        else:
            # Sync donor blood group and address if newly specified
            donor_obj = donor_table.objects.get(LOGIN=request.user)
            if blood_group and not donor_obj.blood_group:
                donor_obj.blood_group = blood_group
                donor_obj.save()

        messages.success(request, "Blood request submitted successfully!")
        try:
            u_profile = user_table.objects.get(LOGIN=request.user)
            if u_profile.role == 'donor':
                return redirect('/myapp/donor_home/')
        except Exception:
            pass
        return redirect('/myapp/patient_home/')

    return render(request, 'patient/blood_request.html', {
        'hospitals': hospitals,
        'patient_profile': patient_profile,
        'patient_age': patient_age,
        'patient_location': patient_loc,
    })

def patient_upload_docement(request):
    return render(request,'patient/upload_document.html')
###########################donor###################

def donor_home(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')
        
    check_and_update_timeouts()

    # Get donor profile
    donor_profile = None
    try:
        donor_profile = donor_table.objects.get(LOGIN=request.user)
    except donor_table.DoesNotExist:
        pass

    donor_loc = donor_profile.address if (donor_profile and donor_profile.address) else 'Kozhikode, Kerala'
    donor_bg = donor_profile.blood_group if donor_profile else None

    # Get patient profile (if any) and own requests
    my_requests = []
    patient_profile = None
    patient_age = None
    latest_request_response = None
    accepted_responses = []
    accepted_count = 0
    try:
        patient_profile = patient_table.objects.filter(LOGIN=request.user).first()
        if patient_profile:
            raw_requests = blood_requests_table.objects.filter(PATIENT=patient_profile).order_by('-id')
            for req in raw_requests:
                req.is_creator = True
                req.is_my_donation = False
                req_accepted = donor_response_table.objects.filter(BLOOD_REQUEST=req, response_status__in=['ACCEPTED', 'ASSIGNED']).order_by('-id')
                req.accepted_responses = list(req_accepted)
                req.accepted_count = req_accepted.count()
                req.latest_response = req_accepted.first()
                req.assigned_donor = req_accepted.filter(response_status='ASSIGNED').first()
                req_hosp_loc = req.HOSPITAL.address if req.HOSPITAL else ''
                req.distance_km = calculate_distance_km(donor_loc, req_hosp_loc)
                req.distance_str = format_distance_str(req.distance_km)
                my_requests.append(req)
            if patient_profile.dob:
                today = datetime.date.today()
                dob_date = patient_profile.dob
                patient_age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
    except Exception:
        pass


    if my_requests:
        accepted_responses = my_requests[0].accepted_responses
        accepted_count = my_requests[0].accepted_count
        latest_request_response = my_requests[0].latest_response

    # Get all verified and normal requests (Verified Requests - UI format 13)
    verified_requests = blood_requests_table.objects.filter(request_status__in=['APPROVED', 'PENDING']).order_by('-id')
    if donor_profile:
        verified_requests = verified_requests.filter(blood_group=donor_profile.blood_group)
    if patient_profile:
        verified_requests = verified_requests.exclude(PATIENT=patient_profile)

    # Exclude requests that this donor has already confirmed/accepted to donate for
    if donor_profile:
        already_accepted_ids = donor_response_table.objects.filter(
            DONOR=donor_profile,
            response_status__in=['ACCEPTED', 'ASSIGNED']
        ).values_list('BLOOD_REQUEST_id', flat=True)
        verified_requests = verified_requests.exclude(id__in=already_accepted_ids)

    # Rank verified requests by distance from donor location
    verified_requests = rank_blood_requests_by_distance(verified_requests, donor_loc)

    # Donation history
    donations = []
    if donor_profile:
        donations = donation_history_table.objects.filter(DONOR=donor_profile).order_by('-donation_date')

    next_eligible_date = None
    if donor_profile and donor_profile.last_donation_date:
        next_eligible_date = donor_profile.last_donation_date + datetime.timedelta(days=90)

    # Build dynamic notifications
    notifications = []
    
    # Fetch all approved emergency requests created by hospitals
    hospital_emergencies = blood_requests_table.objects.filter(
        emergency='yes',
        request_status='APPROVED',
        PATIENT__LOGIN__username='hospital_emergency'
    ).order_by('-id')

    for req in hospital_emergencies:
        req_date_str = f" (Required by: {req.required_date})" if req.required_date else ""
        notifications.append({
            'title': '🚨 Hospital Emergency Request',
            'message': f"Emergency: {req.blood_group} blood ({req.units_required} units) required at {req.HOSPITAL.hospital_name}{req_date_str}.",
            'time': f"Published on {req.created_at}",
            'icon': 'bi-exclamation-triangle-fill',
            'class': 'bg-red-light',
            'is_emergency': True
        })
    
    # 1. Active blood requests from others (matching blood group in city/district)
    matched_query = blood_requests_table.objects.filter(request_status='APPROVED')
    if donor_profile:
        matched_query = matched_query.filter(blood_group=donor_profile.blood_group)
    if patient_profile:
        matched_query = matched_query.exclude(PATIENT=patient_profile)
        
    for req in matched_query.order_by('-id')[:5]:
        req_date_str = f" (Required by: {req.required_date})" if req.required_date else ""
        notifications.append({
            'title': 'Urgent Blood Requirement Matched',
            'message': f"An urgent request for blood group {req.blood_group} ({req.units_required}) has been submitted at {req.HOSPITAL.hospital_name}{req_date_str}.",
            'time': f"Published on {req.created_at}",
            'icon': 'bi-droplet-fill',
            'class': 'bg-red-light'
        })

    # 2. General notifications (donation completions)
    for donation in donations[:3]:
        notifications.append({
            'title': 'Donation Successfully Completed',
            'message': f"Thank you for donating {donation.units_donated} units of {donation.blood_group} at {donation.BLOOD_BANK.blood_bank_name}.",
            'time': f"Donated on {donation.donation_date}",
            'icon': 'bi-check-circle-fill',
            'class': 'bg-green-light'
        })

    # Check if this user has any active blood requests that are not completed/rejected/timed out
    has_active_request = False
    if patient_profile:
        has_active_request = blood_requests_table.objects.filter(
            PATIENT=patient_profile
        ).exclude(request_status__in=['COMPLETED', 'REJECTED', 'TIMED OUT']).exists()

    hospitals = hospitl_table.objects.all()
    nearest_hospitals = get_nearest_hospitals(donor_loc, limit=6)
    nearest_bloodbanks = get_nearest_blood_banks(donor_loc, blood_group=donor_bg, limit=6)
    all_bloodbanks = blood_banks_table.objects.all().order_by('blood_bank_name')
    my_appointments = []
    if donor_profile and donor_profile.USER:
        my_appointments = appointment_table.objects.filter(USER=donor_profile.USER).order_by('-appointment_date', '-id')
    today_date = datetime.date.today().strftime('%Y-%m-%d')

    context = {
        'profile': donor_profile,
        'user_table': donor_profile.USER if donor_profile else None,
        'role': 'donor',
        'my_requests': my_requests,
        'verified_requests': verified_requests,
        'donations': donations,
        'donor_profile': donor_profile,
        'patient_profile': patient_profile,
        'patient_age': patient_age,
        'notifications': notifications,
        'latest_request_response': latest_request_response,
        'next_eligible_date': next_eligible_date,
        'accepted_responses': accepted_responses,
        'accepted_count': accepted_count,
        'has_active_request': has_active_request,
        'latest_emergency': hospital_emergencies.first(),
        'hospitals': hospitals,
        'nearest_hospitals': nearest_hospitals,
        'nearest_bloodbanks': nearest_bloodbanks,
        'all_bloodbanks': all_bloodbanks,
        'my_appointments': my_appointments,
        'today_date': today_date,
        'user_location': donor_loc,
    }
    return render(request,'donor/donor_home.html', context)


def request_appointment(request):
    if not request.user.is_authenticated:
        if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
            return JsonResponse({'status': 'error', 'message': 'Please login to request an appointment.'}, status=401)
        return redirect('/myapp/loginpage/')

    if request.method == 'POST':
        blood_bank_id = request.POST.get('blood_bank_id')
        appointment_date = request.POST.get('appointment_date')
        time_slot = request.POST.get('time_slot')
        notes = request.POST.get('notes', '').strip()
        purpose = request.POST.get('purpose', 'Voluntary Blood Donation').strip() or 'Voluntary Blood Donation'

        if not blood_bank_id or not appointment_date or not time_slot:
            msg = 'Please fill in all required fields (Blood Bank, Date, and Time Slot).'
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
                return JsonResponse({'status': 'error', 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('/myapp/donor_home/?tab=appointments')

        # Check date not in past
        today_str = datetime.date.today().strftime('%Y-%m-%d')
        if str(appointment_date) < today_str:
            msg = 'Appointment date cannot be in the past.'
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
                return JsonResponse({'status': 'error', 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('/myapp/donor_home/?tab=appointments')

        # Find user_table for current user
        user_profile = user_table.objects.filter(LOGIN=request.user).first()
        if not user_profile:
            donor_prof = donor_table.objects.filter(LOGIN=request.user).first()
            if donor_prof:
                user_profile = donor_prof.USER

        if not user_profile:
            msg = 'User profile not found. Please contact support.'
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
                return JsonResponse({'status': 'error', 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('/myapp/donor_home/?tab=appointments')

        try:
            blood_bank = blood_banks_table.objects.get(id=blood_bank_id)
        except blood_banks_table.DoesNotExist:
            msg = 'Selected blood bank not found.'
            if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
                return JsonResponse({'status': 'error', 'message': msg}, status=404)
            messages.error(request, msg)
            return redirect('/myapp/donor_home/?tab=appointments')

        appt = appointment_table.objects.create(
            USER=user_profile,
            BLOOD_BANK=blood_bank,
            appointment_date=appointment_date,
            time_slot=time_slot,
            purpose=purpose,
            notes=notes,
            status='PENDING'
        )

        success_msg = 'You will be notified after the blood bank confirms this.'
        if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.POST.get('is_ajax'):
            return JsonResponse({
                'status': 'success',
                'message': success_msg,
                'appointment_id': appt.id,
                'blood_bank': blood_bank.blood_bank_name,
                'date': str(appt.appointment_date),
                'slot': appt.time_slot
            })

        messages.success(request, success_msg)
        return redirect('/myapp/donor_home/?tab=appointments')

    return redirect('/myapp/donor_home/?tab=appointments')


def cancel_appointment(request, appointment_id):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    try:
        user_profile = user_table.objects.filter(LOGIN=request.user).first()
        appt = appointment_table.objects.get(id=appointment_id, USER=user_profile)
        if appt.status in ['PENDING', 'APPROVED']:
            appt.status = 'CANCELLED'
            appt.save()
            messages.success(request, 'Appointment cancelled successfully.')
        else:
            messages.info(request, f'Appointment is already {appt.status.lower()}.')
    except Exception as e:
        messages.error(request, f'Failed to cancel appointment: {str(e)}')

    return redirect('/myapp/donor_home/?tab=appointments')


def donor_registration(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name', '').strip()
        dob = request.POST.get('dob')
        blood_group = request.POST.get('blood_group')
        gender = request.POST.get('gender')
        phone = request.POST.get('phone', '').strip()
        email = request.POST.get('email', '').strip()
        address = request.POST.get('address', '').strip()
        last_donation_str = request.POST.get('last_donation')
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validation
        if not username:
            messages.error(request, "Username is required!")
            return render(request, 'donor/registration.html')

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'donor/registration.html')

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "Username is already taken!")
            return render(request, 'donor/registration.html')

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "Email is already registered!")
            return render(request, 'donor/registration.html')

        # Email format validation
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            messages.error(request, "Please enter a valid email address!")
            return render(request, 'donor/registration.html')

        # Phone number validation (exactly 10 digits)
        if not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must be exactly 10 digits!")
            return render(request, 'donor/registration.html')

        # Date of birth validation (above 18 and max 150)
        if dob:
            try:
                dob_date = datetime.datetime.strptime(dob, "%Y-%m-%d").date()
                today = datetime.date.today()
                age = today.year - dob_date.year - ((today.month, today.day) < (dob_date.month, dob_date.day))
                if age < 18:
                    messages.error(request, "You must be at least 18 years old to register as a donor.")
                    return render(request, 'donor/registration.html')
                if age > 150:
                    messages.error(request, "Age must be at most 150 years old.")
                    return render(request, 'donor/registration.html')
            except ValueError:
                messages.error(request, "Invalid Date of Birth format!")
                return render(request, 'donor/registration.html')
        else:
            messages.error(request, "Date of Birth is required!")
            return render(request, 'donor/registration.html')

        # Last donation date validation
        last_donation_date = None
        eligibility = 'eligible'
        if last_donation_str:
            try:
                last_donation_date = datetime.datetime.strptime(last_donation_str, "%Y-%m-%d").date()
                if last_donation_date > datetime.date.today():
                    messages.error(request, "Last donation date cannot be in the future!")
                    return render(request, 'donor/registration.html')
                
                days_since_donation = (datetime.date.today() - last_donation_date).days
                if days_since_donation < 90:
                    eligibility = 'ineligible'
            except ValueError:
                messages.error(request, "Invalid last donation date format.")
                return render(request, 'donor/registration.html')

        # Create Django User
        user = User.objects.create_user(username=username, password=password, email=email)
        
        # Add User to donor Group
        group, _ = Group.objects.get_or_create(name='donor')
        user.groups.add(group)

        # Create user_table Profile
        u_tab = user_table.objects.create(
            LOGIN=user,
            name=full_name,
            email=email,
            phone=phone,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )

        # Create donor_table entry
        donor_table.objects.create(
            LOGIN=user,
            USER=u_tab,
            dob=dob_date,
            blood_group=blood_group,
            address=address,
            last_donation_date=last_donation_date,
            eligibility_status=eligibility
        )

        messages.success(request, "Registration successful! Please login.")
        return redirect('/myapp/loginpage/')

    return render(request, 'donor/registration.html')


#########################bloodbank##################

def bloodbank_home(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')
        
    check_and_update_timeouts()

    try:
        bloodbank_profile = blood_banks_table.objects.get(LOGIN=request.user)
    except blood_banks_table.DoesNotExist:
        # If user is admin or other user type, fallback to first blood bank for preview, or redirect
        bloodbank_profile = blood_banks_table.objects.first()
        if not bloodbank_profile:
            messages.error(request, "Blood Bank profile not found.")
            return redirect('/myapp/loginpage/')

    # Auto-initialize inventory for all 8 blood groups
    blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
    
    for bg in blood_groups:
        blood_inventory_table.objects.get_or_create(
            BLOOD_BANK=bloodbank_profile,
            blood_group=bg,
            defaults={
                'units_available': '0',
                'last_updated': timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
            }
        )

    # Handle POST actions
    if request.method == "POST":
        action = request.POST.get('action')
        
        if action == "update_inventory":
            for bg in blood_groups:
                units = request.POST.get(f'units_{bg}', '0')
                try:
                    val = int(units)
                    if val < 0:
                        val = 0
                except ValueError:
                    val = 0
                blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile, blood_group=bg).update(
                    units_available=str(val),
                    last_updated=timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                )
            messages.success(request, "Inventory updated successfully!")
            return redirect('/myapp/bloodbank_home/')
            
        elif action == "add_donation":
            donor_id = request.POST.get('donor_id')
            blood_group = request.POST.get('blood_group')
            units_str = request.POST.get('units_donated', '1')
            
            try:
                donor_obj = donor_table.objects.get(id=donor_id)
                donation_history_table.objects.create(
                    DONOR=donor_obj,
                    BLOOD_BANK=bloodbank_profile,
                    donation_date=datetime.date.today(),
                    blood_group=blood_group,
                    units_donated=units_str,
                    donation_type='Whole Blood'
                )
                
                # Update inventory
                inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile, blood_group=blood_group).first()
                if inv_item:
                    try:
                        current = int(inv_item.units_available)
                    except ValueError:
                        current = 0
                    try:
                        added = int(units_str)
                    except ValueError:
                        added = 0
                    inv_item.units_available = str(current + added)
                    inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                    inv_item.save()
                    
                messages.success(request, f"Donation of {units_str} units of {blood_group} recorded successfully!")
            except Exception as e:
                messages.error(request, f"Failed to record donation: {str(e)}")
            return redirect('/myapp/bloodbank_home/')
            
        elif action in ["fulfill_request", "supply_blood", "supply_low_donor_blood"]:
            request_id = request.POST.get('request_id')
            try:
                req = blood_requests_table.objects.get(id=request_id)
                # Parse units needed
                units_req = parse_units_required(req.units_required)

                # Check voluntary donor responses
                accepted_donors_count = donor_response_table.objects.filter(
                    BLOOD_REQUEST=req,
                    response_status__in=['ACCEPTED', 'ASSIGNED']
                ).count()
                is_low_donor = (accepted_donors_count < units_req)

                # Optional custom units to supply
                units_to_supply_param = request.POST.get('units_to_supply')
                if units_to_supply_param:
                    try:
                        target_units = int(units_to_supply_param)
                        if target_units <= 0:
                            target_units = units_req
                    except ValueError:
                        target_units = units_req
                else:
                    target_units = units_req
                
                # Check inventory
                inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile, blood_group=req.blood_group).first()
                if not inv_item:
                    messages.error(request, f"No inventory record found for blood group {req.blood_group}.")
                    return redirect('/myapp/bloodbank_home/')
                    
                try:
                    avail = int(inv_item.units_available)
                except ValueError:
                    avail = 0
                    
                if avail <= 0:
                    messages.error(request, f"Insufficient stock of {req.blood_group}! No units available in blood bank inventory to supply.")
                    return redirect('/myapp/bloodbank_home/')
                    
                if avail >= target_units:
                    # Fully allocated / reserved target units
                    allocated_units = target_units
                    inv_item.units_available = str(avail - allocated_units)
                    inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                    inv_item.save()
                    
                    reason_note = (
                        f"Supplied {allocated_units} unit(s) from blood bank inventory ({accepted_donors_count}/{units_req} donors available) for patient {req.patient_name} at {req.HOSPITAL.hospital_name}."
                        if is_low_donor else
                        f"Temporarily reserved {allocated_units} unit(s) for patient {req.patient_name} at {req.HOSPITAL.hospital_name}."
                    )

                    blood_allocation_table.objects.create(
                        BLOOD_REQUEST=req,
                        BLOOD_BANK=bloodbank_profile,
                        blood_group=req.blood_group,
                        units_allocated=allocated_units,
                        status='RESERVED',
                        notes=reason_note
                    )
                    
                    # Record transfusion details as draft for the allocated units
                    for u in range(1, allocated_units + 1):
                        transfusion_table.objects.create(
                            BLOOD_REQUEST=req,
                            donor_id=f"BB-{bloodbank_profile.id:03d}",
                            blood_bag_id=f"BB-BAG-{req.id:04d}-{u:02d}",
                            quantity="1 Unit",
                            transfusion_date=datetime.date.today(),
                            staff_name=bloodbank_profile.contact_person if bloodbank_profile.contact_person else bloodbank_profile.blood_bank_name,
                            clinical_notes=f"Draft: Fulfilled by {bloodbank_profile.blood_bank_name} ({req.blood_group})"
                        )

                    req.request_status = 'DISPATCHED'
                    req.save()
                    if is_low_donor:
                        messages.success(request, f"Blood request REQ{req.id:04d} supplied successfully from blood bank inventory! {allocated_units} unit(s) deducted/reserved and recorded as draft in transfusion records.")
                    else:
                        messages.success(request, f"Blood request REQ{req.id:04d} fulfilled! {allocated_units} unit(s) temporarily deducted/reserved from inventory and recorded as draft in transfusion records. If unused, units will be restored.")
                else:
                    # Partially allocated / reserved
                    allocated_units = avail
                    inv_item.units_available = '0'
                    inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                    inv_item.save()
                    
                    reason_note = (
                        f"Partially supplied {allocated_units} unit(s) from blood bank inventory ({accepted_donors_count}/{units_req} donors) for patient {req.patient_name}."
                        if is_low_donor else
                        f"Partially reserved {allocated_units} unit(s) for patient {req.patient_name}."
                    )

                    blood_allocation_table.objects.create(
                        BLOOD_REQUEST=req,
                        BLOOD_BANK=bloodbank_profile,
                        blood_group=req.blood_group,
                        units_allocated=allocated_units,
                        status='RESERVED',
                        notes=reason_note
                    )

                    # Record transfusion details as draft for the partially allocated units
                    for u in range(1, allocated_units + 1):
                        transfusion_table.objects.create(
                            BLOOD_REQUEST=req,
                            donor_id=f"BB-{bloodbank_profile.id:03d}",
                            blood_bag_id=f"BB-BAG-{req.id:04d}-{u:02d}",
                            quantity="1 Unit",
                            transfusion_date=datetime.date.today(),
                            staff_name=bloodbank_profile.contact_person if bloodbank_profile.contact_person else bloodbank_profile.blood_bank_name,
                            clinical_notes=f"Draft: Partially fulfilled by {bloodbank_profile.blood_bank_name} ({req.blood_group})"
                        )
                    
                    req.request_status = 'DISPATCHED'
                    req.save()
                    if is_low_donor:
                        messages.success(request, f"Blood request REQ{req.id:04d} partially supplied! {allocated_units} unit(s) reserved from inventory, dispatched and recorded as draft in transfusion records.")
                    else:
                        messages.success(request, f"Blood request REQ{req.id:04d} partially fulfilled! {allocated_units} unit(s) reserved, dispatched and recorded as draft in transfusion records.")
            except Exception as e:
                messages.error(request, f"Failed to fulfill request: {str(e)}")
            return redirect('/myapp/bloodbank_home/')

        elif action == "return_unused_blood":
            allocation_id = request.POST.get('allocation_id')
            request_id = request.POST.get('request_id')
            try:
                alloc = None
                if allocation_id:
                    alloc = blood_allocation_table.objects.filter(id=allocation_id, BLOOD_BANK=bloodbank_profile, status='RESERVED').first()
                elif request_id:
                    alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST_id=request_id, BLOOD_BANK=bloodbank_profile, status='RESERVED').first()

                if alloc:
                    inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile, blood_group=alloc.blood_group).first()
                    if inv_item:
                        try:
                            avail = int(inv_item.units_available)
                        except ValueError:
                            avail = 0
                        inv_item.units_available = str(avail + alloc.units_allocated)
                        inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                        inv_item.save()
                    
                    alloc.status = 'RETURNED'
                    alloc.notes = f"Returned {alloc.units_allocated} unused unit(s) back to inventory on {datetime.date.today()}."
                    alloc.save()
                    
                    # Reopen request if not completed
                    req = alloc.BLOOD_REQUEST
                    if req.request_status == 'DISPATCHED':
                        req.request_status = 'APPROVED'
                        req.save()

                    # Remove transfusion details for this request as blood was returned
                    transfusion_table.objects.filter(BLOOD_REQUEST=req).delete()
                    
                    messages.success(request, f"{alloc.units_allocated} unit(s) of {alloc.blood_group} successfully restored back to blood bank inventory and transfusion details removed!")
                else:
                    if request_id:
                        req = blood_requests_table.objects.filter(id=request_id).first()
                        if req:
                            transfusion_table.objects.filter(BLOOD_REQUEST=req).delete()
                            if req.request_status == 'DISPATCHED':
                                req.request_status = 'APPROVED'
                                req.save()
                            messages.success(request, "Transfusion details removed and request reopened.")
            except Exception as e:
                messages.error(request, f"Failed to return blood to inventory: {str(e)}")
            return redirect('/myapp/bloodbank_home/')

        elif action in ["approve_appointment", "confirm_appointment"]:
            appointment_id = request.POST.get('appointment_id')
            try:
                appt = appointment_table.objects.get(id=appointment_id, BLOOD_BANK=bloodbank_profile)
                appt.status = 'APPROVED'
                appt.save()
                messages.success(request, f"Appointment #{appt.id} for {appt.USER.name} confirmed successfully!")
            except Exception as e:
                messages.error(request, f"Failed to confirm appointment: {str(e)}")
            return redirect('/myapp/bloodbank_home/')

        elif action == "reject_appointment":
            appointment_id = request.POST.get('appointment_id')
            try:
                appt = appointment_table.objects.get(id=appointment_id, BLOOD_BANK=bloodbank_profile)
                appt.status = 'REJECTED'
                appt.save()
                messages.info(request, f"Appointment #{appt.id} for {appt.USER.name} rejected.")
            except Exception as e:
                messages.error(request, f"Failed to reject appointment: {str(e)}")
            return redirect('/myapp/bloodbank_home/')

    # Get data for templates
    inventory_qs = blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile)
    inventory_dict = {item.blood_group: item for item in inventory_qs}
    latest_update = "Never"
    from django.db.models import Max
    try:
        latest_update_val = inventory_qs.aggregate(Max('last_updated'))['last_updated__max']
        if latest_update_val:
            latest_update = latest_update_val
    except Exception:
        pass
    
    active_allocations = blood_allocation_table.objects.filter(BLOOD_BANK=bloodbank_profile, status='RESERVED').order_by('-id')
    reserved_by_bg = {}
    for alloc in active_allocations:
        reserved_by_bg[alloc.blood_group] = reserved_by_bg.get(alloc.blood_group, 0) + alloc.units_allocated

    total_units = 0
    total_reserved_units = 0
    low_stock_alerts = 0
    for bg, item in inventory_dict.items():
        try:
            val = int(item.units_available)
        except ValueError:
            val = 0
        res = reserved_by_bg.get(bg, 0)
        item.reserved = res
        item.total_stock = val + res
        total_units += val
        total_reserved_units += res
        if val < 5:  # Define low stock alert limit as < 5 units
            low_stock_alerts += 1
            item.low_stock = True
        else:
            item.low_stock = False

    # Recent supply logs (limit to 10)
    received_logs = donation_history_table.objects.filter(BLOOD_BANK=bloodbank_profile).order_by('-id')[:5]
    dispatched_logs = blood_requests_table.objects.filter(request_status='COMPLETED', HOSPITAL__isnull=False).order_by('-id')[:5]
    
    # Combined supply logs
    recent_logs = []
    for log in received_logs:
        recent_logs.append({
            'type': 'Received',
            'units': log.units_donated,
            'blood_group': log.blood_group,
            'source': log.DONOR.USER.name,
            'time': log.donation_date.strftime('%Y-%m-%d'),
            'icon': 'bi-arrow-down-left-circle-fill text-success',
        })
    for log in dispatched_logs:
        recent_logs.append({
            'type': 'Dispatched',
            'units': log.units_required,
            'blood_group': log.blood_group,
            'source': log.HOSPITAL.hospital_name if log.HOSPITAL else 'Hospital',
            'time': log.verified_at or log.created_at,
            'icon': 'bi-arrow-up-right-circle-fill text-danger',
        })
    
    # Sort recent logs by time (simplistic sort since it's strings/dates)
    recent_logs = sorted(recent_logs, key=lambda x: x['time'], reverse=True)[:10]

    # Donors list for new donation dropdown
    donors = donor_table.objects.all()

    # View requests (Pending/Approved in system)
    all_requests = list(blood_requests_table.objects.all().order_by('-id'))
    pending_requests = list(blood_requests_table.objects.filter(request_status='APPROVED').order_by('-id')) # those approved by hospital that need blood bank fulfillment
    
    bb_loc = bloodbank_profile.address if (bloodbank_profile and bloodbank_profile.address) else (bloodbank_profile.blood_bank_name if bloodbank_profile else 'Kozhikode, Kerala')
    all_requests = rank_blood_requests_by_distance(all_requests, bb_loc)
    pending_requests = rank_blood_requests_by_distance(pending_requests, bb_loc)

    for req in pending_requests:
        req_units_int = parse_units_required(req.units_required)
        accepted_count = donor_response_table.objects.filter(
            BLOOD_REQUEST=req,
            response_status__in=['ACCEPTED', 'ASSIGNED']
        ).count()
        compatible_count = donor_table.objects.filter(
            blood_group=req.blood_group,
            eligibility_status='eligible'
        ).count()

        bb_item = blood_inventory_table.objects.filter(BLOOD_BANK=bloodbank_profile, blood_group=req.blood_group).first()
        avail_bb_stock = 0
        if bb_item and bb_item.units_available:
            try:
                avail_bb_stock = int(bb_item.units_available)
            except (ValueError, TypeError):
                avail_bb_stock = 0

        req.accepted_donor_count = accepted_count
        req.required_units_count = req_units_int
        req.shortfall_units = max(0, req_units_int - accepted_count)
        req.compatible_donor_count = compatible_count
        req.bb_stock = avail_bb_stock
        req.bb_can_supply = (avail_bb_stock > 0)
        req.is_low_donor_availability = (accepted_count < req_units_int) or (compatible_count < req_units_int)

    low_donor_requests = [r for r in pending_requests if r.is_low_donor_availability]
    low_donor_requests_count = len(low_donor_requests)

    nearby_hospitals = get_nearest_hospitals(bb_loc, limit=6)
    nearby_donors = get_nearest_donors(bb_loc, limit=12)

    # Accepted donors list
    accepted_donors = donor_response_table.objects.all().order_by('-id')

    # Donation history records
    donations = donation_history_table.objects.filter(BLOOD_BANK=bloodbank_profile).order_by('-id')

    # Transfusion records
    transfusions = list(transfusion_table.objects.all().order_by('-id'))
    for tf in transfusions:
        is_bb = (
            tf.donor_id.startswith('BB-') or
            tf.blood_bag_id.startswith('BB-BAG-') or
            blood_allocation_table.objects.filter(BLOOD_REQUEST=tf.BLOOD_REQUEST, BLOOD_BANK__isnull=False).exists()
        )
        tf.is_blood_bank_fulfilled = is_bb
        can_return = (
            is_bb and
            (tf.BLOOD_REQUEST.request_status in ['DISPATCHED', 'APPROVED'] or
             blood_allocation_table.objects.filter(BLOOD_REQUEST=tf.BLOOD_REQUEST, status='RESERVED').exists())
        )
        tf.can_return_to_bb = can_return
        is_draft = (tf.BLOOD_REQUEST.request_status != 'COMPLETED') or tf.clinical_notes.startswith('Draft') or ('draft' in tf.clinical_notes.lower())
        tf.is_draft = is_draft

    # Notifications (hospital emergency requests & blood supply alerts)
    notifications = []
    
    # Notify blood bank about requests needing fulfillment
    for r in low_donor_requests:
        notifications.append({
            'title': '🩸 Blood Request Supply Needed',
            'message': f"Request REQ{r.id:04d} ({r.blood_group}, {r.units_required}) at {r.HOSPITAL.hospital_name} requires units ({r.accepted_donor_count}/{r.units_required} donors available). Blood bank supply recommended.",
            'time': f"Required by: {r.required_date or 'Immediate'}",
            'icon': 'bi-droplet-half',
            'class': 'bg-yellow-light',
            'is_emergency': False
        })

    hospital_emergencies = blood_requests_table.objects.filter(
        emergency='yes',
        request_status='APPROVED',
        PATIENT__LOGIN__username='hospital_emergency'
    ).order_by('-id')

    for req in hospital_emergencies:
        notifications.append({
            'title': '🚨 Hospital Emergency Request',
            'message': f"Emergency: {req.blood_group} blood ({req.units_required} units) required at {req.HOSPITAL.hospital_name}.",
            'time': f"Published on {req.created_at}",
            'icon': 'bi-exclamation-triangle-fill',
            'class': 'bg-red-light',
            'is_emergency': True
        })

    context = {
        'profile': bloodbank_profile,
        'user_table': bloodbank_profile.LOGIN,
        'inventory': inventory_dict,
        'total_units': total_units,
        'total_reserved_units': total_reserved_units,
        'active_allocations': active_allocations,
        'low_stock_alerts': low_stock_alerts,
        'recent_logs': recent_logs,
        'donors': donors,
        'all_requests': all_requests,
        'pending_requests': pending_requests,
        'low_donor_requests': low_donor_requests,
        'low_donor_requests_count': low_donor_requests_count,
        'accepted_donors': accepted_donors,
        'donations': donations,
        'transfusions': transfusions,
        'latest_update': latest_update,
        'notifications': notifications,
        'nearby_hospitals': nearby_hospitals,
        'nearby_donors': nearby_donors,
        'incoming_appointments': appointment_table.objects.filter(BLOOD_BANK=bloodbank_profile).order_by('-appointment_date', '-id'),
        'user_location': bb_loc,
    }
    return render(request, 'bloodbank/bloodbank_home.html', context)

def bloodbank_registration(request):
    if request.method == 'POST':
        bloodbank_name = request.POST.get('bloodbank_name', '').strip()
        license_number = request.POST.get('license_number', '').strip()
        contact_person = request.POST.get('contact_person', '').strip()
        address = request.POST.get('address', '').strip()
        phone = request.POST.get('phone', '').strip()
        email = request.POST.get('email', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validation
        if not username:
            messages.error(request, "Username is required!")
            return render(request, 'bloodbank/registration.html')

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'bloodbank/registration.html')

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "Username is already taken!")
            return render(request, 'bloodbank/registration.html')

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "Email is already registered!")
            return render(request, 'bloodbank/registration.html')

        # Email format validation
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            messages.error(request, "Please enter a valid email address!")
            return render(request, 'bloodbank/registration.html')

        # Phone number validation (exactly 10 digits)
        if not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must be exactly 10 digits!")
            return render(request, 'bloodbank/registration.html')

        # Create Django User
        user = User.objects.create_user(username=username, password=password, email=email)
        
        # Add User to bloodbank Group
        group, _ = Group.objects.get_or_create(name='bloodbank')
        user.groups.add(group)

        # Create user_table profile
        u_tab = user_table.objects.create(
            LOGIN=user,
            name=bloodbank_name,
            email=email,
            phone=phone,
            role='bloodbank',
            status='active',
            created_at=datetime.date.today()
        )

        # Create blood_banks_table entry
        blood_banks_table.objects.create(
            LOGIN=user,
            blood_bank_name=bloodbank_name,
            license_number=license_number,
            address=address,
            contact_person=contact_person,
            phone=phone,
            email=email,
            status='active'
        )

        messages.success(request, "Registration successful! Please login.")
        return redirect('/myapp/loginpage/')

    return render(request, 'bloodbank/registration.html')

#######################hospital########################

def hospital_home(request):
    return redirect('/myapp/hospital_dashboard/')

def hospital_registration(request):
    if request.method == 'POST':
        hospital_name = request.POST.get('hospital_name', '').strip()
        license_number = request.POST.get('license_number', '').strip()
        address = request.POST.get('address', '').strip()
        contact_person = request.POST.get('contact_person', '').strip()
        phone = request.POST.get('phone', '').strip()
        email = request.POST.get('email', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validation
        if not username:
            messages.error(request, "Username is required!")
            return render(request, 'hospital/registration.html')

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'hospital/registration.html')

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "Username is already taken!")
            return render(request, 'hospital/registration.html')

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "Email is already registered!")
            return render(request, 'hospital/registration.html')

        # Email format validation
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            messages.error(request, "Please enter a valid email address!")
            return render(request, 'hospital/registration.html')

        # Phone number validation (exactly 10 digits)
        if not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must be exactly 10 digits!")
            return render(request, 'hospital/registration.html')

        # Create Django User
        user = User.objects.create_user(username=username, password=password, email=email)
        
        # Add User to hospital Group
        group, _ = Group.objects.get_or_create(name='hospital')
        user.groups.add(group)

        # Create user_table Profile
        u_tab = user_table.objects.create(
            LOGIN=user,
            name=hospital_name,
            email=email,
            phone=phone,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )

        has_blood_bank = request.POST.get('has_blood_bank', 'no')

        # Create hospitl_table entry
        hospitl_table.objects.create(
            LOGIN=user,
            USER=u_tab,
            hospital_name=hospital_name,
            license_number=license_number,
            address=address,
            contact_person=contact_person,
            phone=phone,
            email=email,
            status='active',
            has_blood_bank=has_blood_bank
        )

        messages.success(request, "Registration successful! Please login.")
        return redirect('/myapp/loginpage/')

    return render(request, 'hospital/registration.html')


def hospital_dashboard(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')
        
    check_and_update_timeouts()
        
    try:
        hospital_profile = hospitl_table.objects.get(LOGIN=request.user)
    except Exception:
        hospital_profile = hospitl_table.objects.first()

    if not hospital_profile:
        messages.error(request, "Hospital profile not found.")
        return redirect('/myapp/loginpage/')

    # Check/Create associated blood bank if has_blood_bank is 'yes'
    bb_profile = None
    if hospital_profile.has_blood_bank == 'yes':
        bb_profile, _ = blood_banks_table.objects.get_or_create(
            LOGIN=request.user,
            defaults={
                'blood_bank_name': f"{hospital_profile.hospital_name} Blood Bank",
                'license_number': hospital_profile.license_number,
                'address': hospital_profile.address,
                'contact_person': hospital_profile.contact_person,
                'phone': hospital_profile.phone,
                'email': hospital_profile.email,
                'status': 'active'
            }
        )
        # Initialize inventory
        blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        for bg in blood_groups:
            blood_inventory_table.objects.get_or_create(
                BLOOD_BANK=bb_profile,
                blood_group=bg,
                defaults={
                    'units_available': '0',
                    'last_updated': timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                }
            )

    # Handle POST to update inventory or assign donor
    if request.method == "POST":
        action = request.POST.get('action')
        if action == "update_hospital_inventory" and bb_profile:
            blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
            for bg in blood_groups:
                units = request.POST.get(f'units_{bg}', '0')
                try:
                    val = int(units)
                    if val < 0:
                        val = 0
                except ValueError:
                    val = 0
                blood_inventory_table.objects.filter(BLOOD_BANK=bb_profile, blood_group=bg).update(
                    units_available=str(val),
                    last_updated=timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                )
            messages.success(request, "Hospital Blood Bank Inventory updated successfully!")
            return redirect('/myapp/hospital_dashboard/')

        elif action == "assign_donor":
            response_id = request.POST.get('response_id')
            try:
                resp = donor_response_table.objects.get(id=response_id, BLOOD_REQUEST__HOSPITAL=hospital_profile)
                resp.response_status = 'ASSIGNED'
                resp.save()
                # Ensure the blood request remains APPROVED (active) and NOT completed upon donor assignment.
                # Request is only marked COMPLETED after transfusion details are recorded in hospital_save_transfusion.
                if resp.BLOOD_REQUEST and resp.BLOOD_REQUEST.request_status != 'COMPLETED':
                    resp.BLOOD_REQUEST.request_status = 'APPROVED'
                    resp.BLOOD_REQUEST.save()
                messages.success(request, f"Donor {resp.DONOR.USER.name} assigned successfully! All contact and clinical details are verified.")
            except Exception as e:
                messages.error(request, f"Failed to assign donor: {str(e)}")
            return redirect('/myapp/hospital_dashboard/')

    # Fetch inventory if has_blood_bank is 'yes'
    hospital_inventory = {}
    hospital_inventory_list = []
    latest_update = "Never"
    if bb_profile:
        inv_qs = blood_inventory_table.objects.filter(BLOOD_BANK=bb_profile)
        hospital_inventory = {item.blood_group: item for item in inv_qs}
        try:
            latest_update_val = inv_qs.aggregate(Max('last_updated'))['last_updated__max']
            if latest_update_val:
                latest_update = latest_update_val
        except Exception:
            pass
        
        blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        total_bb_units = 0
        low_stock_bb_alerts = 0
        for bg in blood_groups:
            inv_item = hospital_inventory.get(bg)
            units = 0
            if inv_item and inv_item.units_available:
                try:
                    units = int(inv_item.units_available)
                except (ValueError, TypeError):
                    units = 0
            total_bb_units += units
            is_low = (units < 5)
            if is_low:
                low_stock_bb_alerts += 1
            hospital_inventory_list.append({
                'blood_group': bg,
                'units_available': str(units),
                'low_stock': is_low,
                'last_updated': inv_item.last_updated if inv_item else None
            })
    else:
        total_bb_units = 0
        low_stock_bb_alerts = 0

    hospital_loc = hospital_profile.address if (hospital_profile and hospital_profile.address) else (hospital_profile.hospital_name if hospital_profile else 'Kozhikode, Kerala')
    
    requests_q = blood_requests_table.objects.filter(HOSPITAL=hospital_profile).order_by('-id')

    total_requests = requests_q.count()
    pending_count = requests_q.filter(request_status='PENDING').count()
    approved_count = requests_q.filter(request_status='APPROVED').count()
    rejected_count = requests_q.filter(request_status='REJECTED').count()
    completed_count = requests_q.filter(request_status='COMPLETED').count()

    all_requests = list(requests_q)
    all_requests = rank_blood_requests_by_distance(all_requests, hospital_loc)
    view_requests = [r for r in all_requests if r.request_status not in ['APPROVED', 'DISPATCHED']]
    recent_requests = all_requests[:10]
    pending_requests = [r for r in all_requests if r.request_status == 'PENDING']

    for r in all_requests:
        r_units = parse_units_required(r.units_required)
        acc = donor_response_table.objects.filter(
            BLOOD_REQUEST=r,
            response_status__in=['ACCEPTED', 'ASSIGNED']
        ).count()
        r.accepted_donor_count = acc
        r.required_units_count = r_units
        r.shortfall_units = max(0, r_units - acc)
        r.is_low_donor_availability = (acc < r_units)

    nearby_donors = get_nearest_donors(hospital_loc, limit=12)
    nearby_bloodbanks = get_nearest_blood_banks(hospital_loc, limit=6)

    # Calculate today's activity stats
    today_str = datetime.date.today().strftime('%Y-%m-%d')
    new_requests_today = requests_q.filter(created_at__startswith=today_str).count()
    
    # Approved requests count for today (verified or created today)
    approved_requests_today = requests_q.filter(request_status='APPROVED').filter(
        Q(verified_at__startswith=today_str) | Q(created_at__startswith=today_str)
    ).count()
    if approved_requests_today == 0:
        approved_requests_today = requests_q.filter(request_status='APPROVED', created_at=today_str).count()

    fulfilled_today = requests_q.filter(request_status='COMPLETED').count()

    # Accepted donors
    accepted_donors = donor_response_table.objects.filter(BLOOD_REQUEST__HOSPITAL=hospital_profile).order_by('-id')
    today_date = datetime.date.today()
    today_str = today_date.strftime('%Y-%m-%d')
    for resp in accepted_donors:
        if resp.DONOR and resp.DONOR.dob:
            try:
                resp.donor_age = today_date.year - resp.DONOR.dob.year - ((today_date.month, today_date.day) < (resp.DONOR.dob.month, resp.DONOR.dob.day))
            except Exception:
                resp.donor_age = "N/A"
        else:
            resp.donor_age = "N/A"

        # Ensure responded_on displays the date the donor accepted
        if not resp.response_time or resp.response_time == '15 mins':
            if resp.BLOOD_REQUEST and resp.BLOOD_REQUEST.created_at and resp.BLOOD_REQUEST.created_at != '15 mins':
                resp.response_time = str(resp.BLOOD_REQUEST.created_at)
            else:
                resp.response_time = today_str
            try:
                donor_response_table.objects.filter(id=resp.id).update(response_time=resp.response_time)
            except Exception:
                pass
        elif ' ' in str(resp.response_time) and '-' in str(resp.response_time):
            parts = str(resp.response_time).strip().split(' ')
            if len(parts[0]) == 10 and parts[0].count('-') == 2:
                resp.response_time = parts[0]

    pending_assignment_count = accepted_donors.filter(response_status='ACCEPTED').count()
    assigned_donors_count = accepted_donors.filter(response_status='ASSIGNED').count()

    # Transfusion Records - eligible includes APPROVED and DISPATCHED (fulfilled by blood bank)
    transfusion_eligible = list(requests_q.filter(request_status__in=['APPROVED', 'DISPATCHED']))
    for req_item in transfusion_eligible:
        req_units_int = parse_units_required(req_item.units_required)
        acc = donor_response_table.objects.filter(
            BLOOD_REQUEST=req_item,
            response_status__in=['ACCEPTED', 'ASSIGNED']
        ).count()
        req_item.accepted_donor_count = acc
        req_item.required_units_count = req_units_int
        req_item.shortfall_units = max(0, req_units_int - acc)
        req_item.is_low_donor_availability = (acc < req_units_int)

        req_item.is_blood_bank_fulfilled = (
            req_item.request_status == 'DISPATCHED' or
            blood_allocation_table.objects.filter(BLOOD_REQUEST=req_item, BLOOD_BANK__isnull=False).exists()
        )
        tx_drafts = list(transfusion_table.objects.filter(BLOOD_REQUEST=req_item).order_by('id'))
        for tx in tx_drafts:
            tx.is_draft = (tx.BLOOD_REQUEST.request_status != 'COMPLETED') or tx.clinical_notes.startswith('Draft') or ('draft' in tx.clinical_notes.lower())
        req_item.draft_transfusions = tx_drafts
        req_item.has_drafts = len(tx_drafts) > 0

    low_donor_requests_count = sum(1 for r in transfusion_eligible if r.is_low_donor_availability and not r.is_blood_bank_fulfilled)

    transfusion_records = list(transfusion_table.objects.filter(BLOOD_REQUEST__HOSPITAL=hospital_profile).order_by('-id'))
    for tx in transfusion_records:
        is_bb = (
            tx.donor_id.startswith('BB-') or
            tx.blood_bag_id.startswith('BB-BAG-') or
            blood_allocation_table.objects.filter(BLOOD_REQUEST=tx.BLOOD_REQUEST, BLOOD_BANK__isnull=False).exists()
        )
        tx.is_blood_bank_fulfilled = is_bb
        can_return = (
            is_bb and
            (tx.BLOOD_REQUEST.request_status in ['DISPATCHED', 'APPROVED'] or
             blood_allocation_table.objects.filter(BLOOD_REQUEST=tx.BLOOD_REQUEST, status='RESERVED').exists())
        )
        tx.can_return_to_bb = can_return
        is_draft = (tx.BLOOD_REQUEST.request_status != 'COMPLETED') or tx.clinical_notes.startswith('Draft') or ('draft' in tx.clinical_notes.lower())
        tx.is_draft = is_draft

    # Emergency requests (Request History)
    emergency_requests = requests_q.filter(emergency='yes').order_by('-id')

    # Notifications
    notifications = []
    
    # Fetch all approved emergency requests created by other hospitals
    hospital_emergencies = blood_requests_table.objects.filter(
        emergency='yes',
        request_status='APPROVED',
        PATIENT__LOGIN__username='hospital_emergency'
    ).exclude(HOSPITAL=hospital_profile).order_by('-id')

    for req in hospital_emergencies:
        notifications.append({
            'title': '🚨 Hospital Emergency Request',
            'message': f"Emergency: {req.blood_group} blood ({req.units_required} units) required at {req.HOSPITAL.hospital_name}.",
            'time': f"Published on {req.created_at}",
            'icon': 'bi-exclamation-triangle-fill',
            'class': 'bg-red-light',
            'is_emergency': True
        })
        
    # Notify hospital when a request is pending verification
    for req in pending_requests:
        notifications.append({
            'title': 'New Request Awaiting Verification',
            'message': f"Request REQ{req.id:04d} for {req.blood_group} ({req.units_required}) requires your review.",
            'time': f"Received on {req.created_at}",
            'icon': 'bi-shield-exclamation',
            'class': 'bg-blue-light'
        })
        
    # Notify hospital when a donor accepts a request
    for resp in accepted_donors[:10]:
        notifications.append({
            'title': 'Donor Accepted Request',
            'message': f"Donor {resp.DONOR.USER.name} accepted request REQ{resp.BLOOD_REQUEST.id:04d} ({resp.BLOOD_REQUEST.blood_group}).",
            'time': f"Accepted",
            'icon': 'bi-check-circle-fill',
            'class': 'bg-green-light'
        })

    # Hospitals list for emergency dropdown
    hospitals = hospitl_table.objects.all()

    context = {
        'profile': hospital_profile,
        'user_table': hospital_profile.USER,
        'total_requests': total_requests,
        'pending_count': pending_count,
        'approved_count': approved_count,
        'rejected_count': rejected_count,
        'completed_count': completed_count,
        'recent_requests': recent_requests,
        'all_requests': all_requests,
        'view_requests': view_requests,
        'new_requests_today': new_requests_today,
        'approved_requests_today': approved_requests_today,
        'fulfilled_today': fulfilled_today,
        'donors_accepted': accepted_donors.count(),
        
        'pending_requests': pending_requests,
        'accepted_donors_list': accepted_donors,
        'pending_assignment_count': pending_assignment_count,
        'assigned_donors_count': assigned_donors_count,
        'transfusion_eligible': transfusion_eligible,
        'transfusion_records': transfusion_records,
        'low_donor_requests_count': low_donor_requests_count,
        'emergency_requests': emergency_requests,
        'hospitals': hospitals,
        'notifications': notifications,
        'role': 'hospital',
        'hospital_inventory': hospital_inventory,
        'hospital_inventory_list': hospital_inventory_list,
        'total_bb_units': total_bb_units,
        'low_stock_bb_alerts': low_stock_bb_alerts,
        'latest_update': latest_update,
        'nearby_donors': nearby_donors,
        'nearby_bloodbanks': nearby_bloodbanks,
        'user_location': hospital_loc,
    }
    return render(request, 'hospital/dashboard.html', context)


def hospital_approve_request(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        remarks = request.POST.get('remarks', '')
        try:
            req = blood_requests_table.objects.get(id=request_id)
            req.request_status = 'APPROVED'
            req.verified_at = datetime.date.today().strftime('%Y-%m-%d')
            if remarks:
                req.description = f"{req.description} | Hospital Remarks: {remarks}"
            req.save()
            messages.success(request, f"Request REQ{req.id:04d} approved! It has been removed from View Requests and is now available in Transfusion Records.")
        except Exception as e:
            messages.error(request, "Failed to approve request.")

    return redirect('/myapp/hospital_dashboard/')


def hospital_reject_request(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        remarks = request.POST.get('remarks', '')
        try:
            req = blood_requests_table.objects.get(id=request_id)
            req.request_status = 'REJECTED'
            req.verified_at = datetime.date.today().strftime('%Y-%m-%d')
            if remarks:
                req.description = f"{req.description} | Hospital Remarks: {remarks}"
            req.save()
            messages.success(request, "Request rejected successfully.")
        except Exception as e:
            messages.error(request, "Failed to reject request.")

    return redirect('/myapp/hospital_dashboard/')


def hospital_create_emergency(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        patient_name = request.POST.get('patient_name')
        age = request.POST.get('age')
        blood_group = request.POST.get('blood_group')
        units_required = request.POST.get('units_required')
        hospital_id = request.POST.get('hospital')
        location = request.POST.get('location')
        description = request.POST.get('description')
        document = request.FILES.get('document')

        # Find or create emergency patient placeholder
        try:
            emergency_user, created = User.objects.get_or_create(
                username='hospital_emergency',
                defaults={'email': 'hospital_emergency@lifedrop.org'}
            )
            if created:
                emergency_user.set_password('lifedrop_emergency')
                emergency_user.save()
                group, _ = Group.objects.get_or_create(name='patient')
                emergency_user.groups.add(group)
                
                u_tab = user_table.objects.create(
                    LOGIN=emergency_user,
                    name='Hospital Emergency Placeholder',
                    email='hospital_emergency@lifedrop.org',
                    phone=0,
                    role='patient',
                    status='active',
                    created_at=datetime.date.today()
                )
                patient_profile = patient_table.objects.create(
                    LOGIN=emergency_user,
                    USER=u_tab,
                    name='Hospital Emergency Placeholder',
                    dob=datetime.date(2000, 1, 1),
                    blood_group='O+',
                    address='System',
                    is_first_login=False
                )
            else:
                patient_profile = patient_table.objects.get(LOGIN=emergency_user)
        except Exception as e:
            messages.error(request, "Error creating emergency placeholder patient profile.")
            return redirect('/myapp/hospital_dashboard/')

        try:
            hospital_obj = hospitl_table.objects.get(id=hospital_id)
        except Exception:
            messages.error(request, "Selected hospital is invalid.")
            return redirect('/myapp/hospital_dashboard/')

        # Create emergency request
        parsed_age = None
        if age:
            try:
                parsed_age = int(age)
                if parsed_age < 1 or parsed_age > 150:
                    messages.error(request, "Patient age must be between 1 and 150 years.")
                    return redirect('/myapp/hospital_dashboard/')
            except ValueError:
                messages.error(request, "Invalid age provided.")
                return redirect('/myapp/hospital_dashboard/')

        try:
            required_date_str = request.POST.get('required_date')
            if required_date_str:
                try:
                    req_date = datetime.datetime.strptime(required_date_str, "%Y-%m-%d").date()
                except Exception:
                    req_date = datetime.date.today()
            else:
                req_date = datetime.date.today()

            req = blood_requests_table.objects.create(
                PATIENT=patient_profile,
                HOSPITAL=hospital_obj,
                blood_group=blood_group,
                units_required=units_required,
                location=location,
                description=description,
                request_status='APPROVED',
                emergency='yes',
                created_at=datetime.date.today().strftime('%Y-%m-%d'),
                verified_at=datetime.date.today().strftime('%Y-%m-%d'),
                patient_name=patient_name,
                age=parsed_age,
                required_date=req_date,
                document=document
            )
            messages.success(request, "Emergency request created and published successfully!")
        except Exception as e:
            messages.error(request, "Failed to create emergency request.")

    return redirect('/myapp/hospital_dashboard/')


def hospital_save_transfusion(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        donor_ids = request.POST.getlist('donor_id')
        blood_bag_ids = request.POST.getlist('blood_bag_id')
        quantities = request.POST.getlist('quantity')
        staff_name = request.POST.get('staff_name')
        clinical_notes = request.POST.get('clinical_notes')
        action_type = request.POST.get('action_type', 'fulfill')

        try:
            req = blood_requests_table.objects.get(id=request_id)
            from myapp.models import transfusion_table
            
            existing_txs = list(transfusion_table.objects.filter(BLOOD_REQUEST=req).order_by('id'))
            valid_rows = []
            for donor_id, blood_bag_id, quantity in zip(donor_ids, blood_bag_ids, quantities):
                if donor_id and donor_id.strip() and blood_bag_id and blood_bag_id.strip() and quantity and quantity.strip():
                    valid_rows.append((donor_id.strip(), blood_bag_id.strip(), quantity.strip()))
            
            saved_count = len(valid_rows)

            if action_type == 'save':
                draft_notes = clinical_notes.strip() if clinical_notes else 'Draft transfusion details'
                if not draft_notes.lower().startswith('draft'):
                    draft_notes = f"Draft: {draft_notes}"

                if existing_txs:
                    for i, (d_id, b_id, qty) in enumerate(valid_rows):
                        if i < len(existing_txs):
                            tx = existing_txs[i]
                            tx.donor_id = d_id
                            tx.blood_bag_id = b_id
                            tx.quantity = qty
                            tx.transfusion_date = datetime.date.today()
                            tx.staff_name = staff_name if staff_name else 'Hospital Staff'
                            tx.clinical_notes = draft_notes
                            tx.save()
                        else:
                            transfusion_table.objects.create(
                                BLOOD_REQUEST=req,
                                donor_id=d_id,
                                blood_bag_id=b_id,
                                quantity=qty,
                                transfusion_date=datetime.date.today(),
                                staff_name=staff_name if staff_name else 'Hospital Staff',
                                clinical_notes=draft_notes
                            )
                    if len(valid_rows) < len(existing_txs):
                        for tx in existing_txs[len(valid_rows):]:
                            tx.delete()
                else:
                    for d_id, b_id, qty in valid_rows:
                        transfusion_table.objects.create(
                            BLOOD_REQUEST=req,
                            donor_id=d_id,
                            blood_bag_id=b_id,
                            quantity=qty,
                            transfusion_date=datetime.date.today(),
                            staff_name=staff_name if staff_name else 'Hospital Staff',
                            clinical_notes=draft_notes
                        )

                if saved_count > 0:
                    messages.success(request, f"Transfusion details saved as draft for {saved_count} unit(s). Request REQ{req.id:04d} remains active.")
                else:
                    messages.error(request, "Failed to save transfusion draft: At least one donor record is required.")
            else:
                # Fulfill request
                final_notes = clinical_notes.strip() if clinical_notes else ''
                if final_notes.lower().startswith('draft:'):
                    final_notes = final_notes[6:].strip()
                elif final_notes.lower().startswith('draft'):
                    final_notes = final_notes[5:].strip()
                if not final_notes:
                    final_notes = 'Transfusion completed successfully.'

                if existing_txs:
                    if valid_rows:
                        for i, (d_id, b_id, qty) in enumerate(valid_rows):
                            if i < len(existing_txs):
                                tx = existing_txs[i]
                                tx.donor_id = d_id
                                tx.blood_bag_id = b_id
                                tx.quantity = qty
                                tx.transfusion_date = datetime.date.today()
                                tx.staff_name = staff_name if staff_name else 'Hospital Staff'
                                tx.clinical_notes = final_notes
                                tx.save()
                            else:
                                transfusion_table.objects.create(
                                    BLOOD_REQUEST=req,
                                    donor_id=d_id,
                                    blood_bag_id=b_id,
                                    quantity=qty,
                                    transfusion_date=datetime.date.today(),
                                    staff_name=staff_name if staff_name else 'Hospital Staff',
                                    clinical_notes=final_notes
                                )
                        if len(valid_rows) < len(existing_txs):
                            for tx in existing_txs[len(valid_rows):]:
                                tx.delete()
                    else:
                        for tx in existing_txs:
                            tx_notes = tx.clinical_notes or ''
                            if tx_notes.lower().startswith('draft:'):
                                tx_notes = tx_notes[6:].strip()
                            elif tx_notes.lower().startswith('draft'):
                                tx_notes = tx_notes[5:].strip()
                            tx.clinical_notes = tx_notes if tx_notes else final_notes
                            if staff_name:
                                tx.staff_name = staff_name
                            tx.transfusion_date = datetime.date.today()
                            tx.save()
                        saved_count = len(existing_txs)
                else:
                    if valid_rows:
                        for d_id, b_id, qty in valid_rows:
                            transfusion_table.objects.create(
                                BLOOD_REQUEST=req,
                                donor_id=d_id,
                                blood_bag_id=b_id,
                                quantity=qty,
                                transfusion_date=datetime.date.today(),
                                staff_name=staff_name if staff_name else 'Hospital Staff',
                                clinical_notes=final_notes
                            )
                    else:
                        if staff_name and staff_name.strip():
                            transfusion_table.objects.create(
                                BLOOD_REQUEST=req,
                                donor_id='ASSIGNED_DONOR',
                                blood_bag_id=f"BAG-{req.id:04d}",
                                quantity=req.units_required,
                                transfusion_date=datetime.date.today(),
                                staff_name=staff_name.strip(),
                                clinical_notes=final_notes
                            )
                            saved_count = 1

                # Mark request as COMPLETED (Fulfilled)
                req.request_status = 'COMPLETED'
                req.save()
                
                # Mark any linked RESERVED allocations as USED (permanently consumed)
                blood_allocation_table.objects.filter(BLOOD_REQUEST=req, status='RESERVED').update(
                    status='USED',
                    notes='Blood confirmed used and transfused to patient.'
                )
                
                if saved_count > 0:
                    messages.success(request, f"Transfusion details recorded for {saved_count} unit(s) and request REQ{req.id:04d} successfully marked as Fulfilled!")
                else:
                    messages.success(request, f"Blood request REQ{req.id:04d} successfully marked as Fulfilled!")
        except Exception as e:
            messages.error(request, f"Failed to record transfusion: {str(e)}")

    return redirect('/myapp/hospital_dashboard/')


def hospital_return_blood(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')
    
    if request.method == "POST":
        request_id = request.POST.get('request_id')
        transfusion_id = request.POST.get('transfusion_id')
        reason = request.POST.get('reason', 'Not required / unused by patient')
        try:
            req = blood_requests_table.objects.get(id=request_id)
            if transfusion_id:
                try:
                    tx = transfusion_table.objects.get(id=transfusion_id, BLOOD_REQUEST=req)
                    bag_id = tx.blood_bag_id
                    tx.delete()
                    
                    # Restore 1 unit to inventory
                    alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=req, status__in=['RESERVED', 'USED']).first()
                    if alloc:
                        inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=alloc.BLOOD_BANK, blood_group=alloc.blood_group).first()
                        if inv_item:
                            try:
                                avail = int(inv_item.units_available)
                            except ValueError:
                                avail = 0
                            inv_item.units_available = str(avail + 1)
                            inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                            inv_item.save()
                        if alloc.units_allocated > 1:
                            alloc.units_allocated -= 1
                            alloc.save()
                        else:
                            alloc.status = 'RETURNED'
                            alloc.notes = f"Returned unit by hospital ({req.HOSPITAL.hospital_name}). Reason: {reason}"
                            alloc.save()
                    
                    if not transfusion_table.objects.filter(BLOOD_REQUEST=req).exists():
                        req.request_status = 'APPROVED'
                        req.save()

                    messages.success(request, f"Unit {bag_id} successfully returned to blood bank inventory.")
                    return redirect('/myapp/hospital_dashboard/')
                except transfusion_table.DoesNotExist:
                    pass

            allocations = blood_allocation_table.objects.filter(BLOOD_REQUEST=req, status__in=['RESERVED', 'USED'])
            returned_units = 0
            for alloc in allocations:
                inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=alloc.BLOOD_BANK, blood_group=alloc.blood_group).first()
                if inv_item:
                    try:
                        avail = int(inv_item.units_available)
                    except ValueError:
                        avail = 0
                    inv_item.units_available = str(avail + alloc.units_allocated)
                    inv_item.last_updated = timezone.localtime(timezone.now()).strftime('%Y-%m-%d %H:%M:%S')
                    inv_item.save()
                returned_units += alloc.units_allocated
                alloc.status = 'RETURNED'
                alloc.notes = f"Returned by hospital ({req.HOSPITAL.hospital_name}). Reason: {reason}"
                alloc.save()
            
            # Remove transfusion details for this request
            transfusion_table.objects.filter(BLOOD_REQUEST=req).delete()
            
            # Reset request status back to APPROVED so it can be handled if needed
            req.request_status = 'APPROVED'
            req.save()
            if returned_units > 0:
                messages.success(request, f"{returned_units} unit(s) of unused blood returned to blood bank inventory and transfusion details removed.")
            else:
                messages.success(request, "Transfusion details removed and request returned to blood bank.")
        except Exception as e:
            messages.error(request, f"Failed to return blood: {str(e)}")
            
    return redirect('/myapp/hospital_dashboard/')


def forgot_password(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        
        try:
            user = User.objects.get(username=username, email=email)
            # Store verified user ID in session
            request.session['reset_user_id'] = user.id
            return redirect('reset_password')
        except User.DoesNotExist:
            messages.error(request, "Account details do not match or user does not exist!")
            return render(request, 'forgot_password.html')
            
    return render(request, 'forgot_password.html')


def reset_password(request):
    user_id = request.session.get('reset_user_id')
    if not user_id:
        return redirect('forgot_password')
        
    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return redirect('forgot_password')
        
    if request.method == "POST":
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return render(request, 'reset_password.html')
            
        user.set_password(password)
        user.save()
        
        # Clear session key
        del request.session['reset_user_id']
        
        messages.success(request, "Password updated successfully! Please login.")
        return redirect('login')
        
    return render(request, 'reset_password.html')


def edit_profile(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        blood_group = request.POST.get('blood_group')
        address = request.POST.get('address')
        username = request.POST.get('username')

        # Basic validations
        if phone and not re.match(r'^\d{10}$', phone):
            messages.error(request, "Phone number must be exactly 10 digits!")
            if request.user.groups.filter(name="patient").exists():
                return redirect('/myapp/patient_home/')
            elif request.user.groups.filter(name="hospital").exists():
                return redirect('/myapp/hospital_dashboard/')
            else:
                return redirect('/myapp/donor_home/')

        if email and not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            messages.error(request, "Please enter a valid email address!")
            if request.user.groups.filter(name="patient").exists():
                return redirect('/myapp/patient_home/')
            elif request.user.groups.filter(name="hospital").exists():
                return redirect('/myapp/hospital_dashboard/')
            else:
                return redirect('/myapp/donor_home/')

        # Check username uniqueness if modified
        if username:
            username = username.strip()
            if username and username.lower() != request.user.username.lower():
                if User.objects.filter(username__iexact=username).exclude(id=request.user.id).exists():
                    messages.error(request, "Username is already taken!")
                    if request.user.groups.filter(name="patient").exists():
                        return redirect('/myapp/patient_home/')
                    elif request.user.groups.filter(name="hospital").exists():
                        return redirect('/myapp/hospital_dashboard/')
                    else:
                        return redirect('/myapp/donor_home/')
                user = request.user
                user.username = username
                user.save()

        # Check email uniqueness if modified
        if email and email != request.user.email:
            if User.objects.filter(email__iexact=email).exclude(id=request.user.id).exists():
                messages.error(request, "Email is already taken!")
                if request.user.groups.filter(name="patient").exists():
                    return redirect('/myapp/patient_home/')
                elif request.user.groups.filter(name="hospital").exists():
                    return redirect('/myapp/hospital_dashboard/')
                else:
                    return redirect('/myapp/donor_home/')

        # Update User
        user = request.user
        if email:
            user.email = email
            user.save()

        # Update user_table Profile
        try:
            u_tab = user_table.objects.get(LOGIN=user)
            if full_name:
                u_tab.name = full_name
            if email:
                u_tab.email = email
            if phone:
                u_tab.phone = int(phone)
            u_tab.save()
        except user_table.DoesNotExist:
            pass

        # Update donor table entry (if exists) for blood_group, address, last_donation_date, eligibility_status
        try:
            donor = donor_table.objects.get(LOGIN=user)
            if blood_group:
                donor.blood_group = blood_group
            if address:
                donor.address = address
            
            last_donation_str = request.POST.get('last_donation')
            if last_donation_str is not None:
                if last_donation_str == '':
                    donor.last_donation_date = None
                    donor.eligibility_status = 'eligible'
                else:
                    try:
                        last_donation_date = datetime.datetime.strptime(last_donation_str, "%Y-%m-%d").date()
                        if last_donation_date <= datetime.date.today():
                            donor.last_donation_date = last_donation_date
                            days_since = (datetime.date.today() - last_donation_date).days
                            if days_since < 90:
                                donor.eligibility_status = 'ineligible'
                            else:
                                donor.eligibility_status = 'eligible'
                    except ValueError:
                        pass
            donor.save()
        except donor_table.DoesNotExist:
            pass

        # Update patient table entry (if exists) for name, blood_group, address
        try:
            patient = patient_table.objects.get(LOGIN=user)
            if full_name:
                patient.name = full_name
            if blood_group:
                patient.blood_group = blood_group
            if address:
                patient.address = address
            patient.save()
        except patient_table.DoesNotExist:
            pass

        # Update specific hospital table if applicable
        if user.groups.filter(name="hospital").exists():
            try:
                hosp = hospitl_table.objects.get(LOGIN=user)
                if full_name:
                    hosp.hospital_name = full_name
                contact_person = request.POST.get('contact_person')
                if contact_person:
                    hosp.contact_person = contact_person
                if phone:
                    hosp.phone = int(phone)
                if email:
                    hosp.email = email
                if address:
                    hosp.address = address
                hosp.save()
            except hospitl_table.DoesNotExist:
                pass
            messages.success(request, "Profile updated successfully!")
            return redirect('/myapp/hospital_dashboard/')

        messages.success(request, "Profile updated successfully!")
        if user.groups.filter(name="patient").exists() and not user.groups.filter(name="donor").exists():
            return redirect('/myapp/patient_home/')
        elif user.groups.filter(name="donor").exists() and not user.groups.filter(name="patient").exists():
            return redirect('/myapp/donor_home/')
        else:
            try:
                u_profile = user_table.objects.get(LOGIN=user)
                if u_profile.role == 'donor':
                    return redirect('/myapp/donor_home/')
            except Exception:
                pass
            return redirect('/myapp/patient_home/')

    if request.user.groups.filter(name="patient").exists():
        return redirect('/myapp/patient_home/')
    elif request.user.groups.filter(name="hospital").exists():
        return redirect('/myapp/hospital_dashboard/')
    else:
        return redirect('/myapp/donor_home/')


def accept_blood_request(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    check_and_update_timeouts()

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        try:
            req = blood_requests_table.objects.get(id=request_id)
            
            # Check if this user has any active blood requests that are not completed/rejected/timed out
            patient_profile = patient_table.objects.filter(LOGIN=request.user).first()
            if patient_profile:
                has_active_request = blood_requests_table.objects.filter(
                    PATIENT=patient_profile
                ).exclude(request_status__in=['COMPLETED', 'REJECTED', 'TIMED OUT']).exists()
                
                if has_active_request:
                    messages.error(request, "Failed to accept request. You cannot accept other blood requests until your own active request is completed.")
                    if request.user.groups.filter(name="patient").exists():
                        return redirect('/myapp/patient_home/')
                    else:
                        return redirect('/myapp/donor_home/')

            # Check if donor profile exists for this user
            from myapp.models import donor_table
            donor = donor_table.objects.filter(LOGIN=request.user).first()
            
            # If no donor profile exists but they are a patient, auto-create a donor profile for them!
            if not donor and request.user.groups.filter(name="patient").exists():
                try:
                    patient_profile = patient_table.objects.get(LOGIN=request.user)
                    donor = donor_table.objects.create(
                        LOGIN=request.user,
                        USER=patient_profile.USER,
                        dob=patient_profile.dob if patient_profile.dob else datetime.date(2000, 1, 1),
                        blood_group=patient_profile.blood_group,
                        address=patient_profile.address,
                        eligibility_status='eligible'
                    )
                    # Add User to donor Group
                    from django.contrib.auth.models import Group
                    group, _ = Group.objects.get_or_create(name='donor')
                    request.user.groups.add(group)
                except patient_table.DoesNotExist:
                    pass
            
            if not donor:
                messages.error(request, "Failed to accept request. Please ensure you are registered as a donor.")
            elif donor.eligibility_status != 'eligible':
                messages.error(request, "Failed to accept request. You are currently not eligible to donate.")
            elif req.PATIENT.LOGIN == request.user:
                messages.error(request, "You cannot accept your own blood request!")
            else:
                today_str = datetime.date.today().strftime('%Y-%m-%d')
                response, created = donor_response_table.objects.get_or_create(
                    BLOOD_REQUEST=req,
                    DONOR=donor,
                    defaults={
                        'response_status': 'ACCEPTED',
                        'response_time': today_str
                    }
                )
                if not created:
                    response.response_status = 'ACCEPTED'
                    response.response_time = today_str
                    response.save()
                messages.success(request, "Request accepted! The hospital and patient have been notified.")
                if request.user.groups.filter(name="patient").exists():
                    return redirect('/myapp/patient_home/?tab=verified')
                else:
                    return redirect('/myapp/donor_home/?tab=verified')
        except Exception as e:
            messages.error(request, f"Failed to accept request: {str(e)}")

    if request.user.groups.filter(name="patient").exists():
        return redirect('/myapp/patient_home/')
    else:
        return redirect('/myapp/donor_home/')


def delete_blood_request(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        try:
            patient_profile = patient_table.objects.filter(LOGIN=request.user).first()
            if not patient_profile:
                messages.error(request, "Patient profile not found. You do not have permission to delete this request.")
            else:
                req = blood_requests_table.objects.get(id=request_id, PATIENT=patient_profile)
                if req.request_status == 'PENDING':
                    req_id_str = f"REQ-10{req.id}" if req.id < 100 else f"REQ-{req.id}"
                    if req.document:
                        try:
                            req.document.delete(save=False)
                        except Exception:
                            pass
                    req.delete()
                    messages.success(request, f"Blood request ({req_id_str}) was successfully cancelled and deleted.")
                else:
                    messages.error(request, "Cannot delete request once it has been verified or processed by the medical facility.")
        except blood_requests_table.DoesNotExist:
            messages.error(request, "Blood request not found or you do not have permission to delete it.")
        except Exception as e:
            messages.error(request, f"Failed to delete request: {str(e)}")

    referer = request.META.get('HTTP_REFERER', '')
    if 'patient_home' in referer:
        return redirect('/myapp/patient_home/?tab=myrequests')
    elif 'donor_home' in referer:
        return redirect('/myapp/donor_home/?tab=myrequests')
    elif request.user.groups.filter(name="patient").exists() and not request.user.groups.filter(name="donor").exists():
        return redirect('/myapp/patient_home/?tab=myrequests')
    else:
        return redirect('/myapp/donor_home/?tab=myrequests')


def complete_blood_request(request):
    if not request.user.is_authenticated:
        return redirect('/myapp/loginpage/')

    # Only hospitals or administrators are authorized to mark requests as fulfilled/completed
    if not (request.user.groups.filter(name='hospital').exists() or request.user.is_superuser):
        messages.error(request, "Access denied. Only hospitals can mark a blood request as fulfilled.")
        referer = request.META.get('HTTP_REFERER', '')
        if 'patient_home' in referer:
            return redirect('/myapp/patient_home/?tab=myrequests')
        elif 'donor_home' in referer:
            return redirect('/myapp/donor_home/?tab=myrequests')
        elif request.user.groups.filter(name="patient").exists() and not request.user.groups.filter(name="donor").exists():
            return redirect('/myapp/patient_home/?tab=myrequests')
        else:
            return redirect('/myapp/donor_home/?tab=myrequests')

    if request.method == "POST":
        request_id = request.POST.get('request_id')
        try:
            req = blood_requests_table.objects.get(id=request_id)
            req.request_status = 'COMPLETED'
            req.save()

            # Mark any linked RESERVED allocations as USED
            from myapp.models import blood_allocation_table, transfusion_table
            blood_allocation_table.objects.filter(BLOOD_REQUEST=req, status='RESERVED').update(
                status='USED',
                notes='Blood confirmed used and transfused to patient.'
            )

            # Ensure a transfusion record exists
            if not transfusion_table.objects.filter(BLOOD_REQUEST=req).exists():
                transfusion_table.objects.create(
                    BLOOD_REQUEST=req,
                    donor_id='FULFILLED',
                    blood_bag_id=f"BAG-{req.id:04d}",
                    quantity=req.units_required,
                    transfusion_date=datetime.date.today(),
                    staff_name=request.user.username,
                    clinical_notes='Transfusion completed and request marked fulfilled by medical facility.'
                )

            req_id_str = f"REQ-10{req.id}" if req.id < 100 else f"REQ-{req.id}"
            messages.success(request, f"Blood request ({req_id_str}) was successfully marked as completed and fulfilled.")
        except blood_requests_table.DoesNotExist:
            messages.error(request, "Blood request not found or you do not have permission to update it.")
        except Exception as e:
            messages.error(request, f"Failed to complete request: {str(e)}")

    referer = request.META.get('HTTP_REFERER', '')
    if 'hospital_dashboard' in referer:
        return redirect('/myapp/hospital_dashboard/')
    elif request.user.groups.filter(name='hospital').exists():
        return redirect('/myapp/hospital_dashboard/')
    elif 'patient_home' in referer:
        return redirect('/myapp/patient_home/?tab=myrequests')
    elif 'donor_home' in referer:
        return redirect('/myapp/donor_home/?tab=myrequests')
    elif request.user.groups.filter(name="patient").exists() and not request.user.groups.filter(name="donor").exists():
        return redirect('/myapp/patient_home/?tab=myrequests')
    else:
        return redirect('/myapp/donor_home/?tab=myrequests')


