import math
import re

# Comprehensive coordinates mapping for Kerala districts, towns, landmarks, and major Indian cities
LOCATION_COORDINATES = {
    # Kerala Districts & Major Cities
    'thiruvananthapuram': (8.5241, 76.9366),
    'trivandrum': (8.5241, 76.9366),
    'kollam': (8.8932, 76.6141),
    'quilon': (8.8932, 76.6141),
    'pathanamthitta': (9.2648, 76.7870),
    'alappuzha': (9.4981, 76.3388),
    'alleppey': (9.4981, 76.3388),
    'kottayam': (9.5916, 76.5222),
    'idukki': (9.8494, 76.9806),
    'painavu': (9.8494, 76.9806),
    'munnar': (10.0889, 77.0595),
    'thodupuzha': (9.8959, 76.7184),
    'ernakulam': (9.9816, 76.2999),
    'kochi': (9.9312, 76.2673),
    'cochin': (9.9312, 76.2673),
    'aluva': (10.1076, 76.3516),
    'kaloor': (9.9984, 76.2994),
    'kakkanad': (10.0159, 76.3419),
    'angamaly': (10.1960, 76.3860),
    'thrissur': (10.5276, 76.2144),
    'trichur': (10.5276, 76.2144),
    'guruvayur': (10.5946, 76.0418),
    'chalakkudy': (10.3070, 76.3330),
    'palakkad': (10.7867, 76.6548),
    'palghat': (10.7867, 76.6548),
    'ottapalam': (10.7739, 76.3789),
    'malappuram': (11.0510, 76.0711),
    'manjeri': (11.1215, 76.1211),
    'perinthalmanna': (10.9760, 76.2254),
    'tirur': (10.9160, 75.9234),
    'kozhikode': (11.2588, 75.7804),
    'calicut': (11.2588, 75.7804),
    'medical college kozhikode': (11.2723, 75.8368),
    'vadakara': (11.6089, 75.5917),
    'koyilandy': (11.4357, 75.6961),
    'wayanad': (11.6854, 76.1320),
    'kalpetta': (11.6103, 76.0827),
    'sulthan bathery': (11.6629, 76.2570),
    'mananthavady': (11.8026, 76.0034),
    'kannur': (11.8745, 75.3704),
    'cannapore': (11.8745, 75.3704),
    'thalassery': (11.7491, 75.4890),
    'payyanur': (12.1006, 75.2030),
    'kasaragod': (12.4996, 74.9869),
    'kanhangad': (12.3082, 75.0911),

    # Major Indian Metro Cities
    'bangalore': (12.9716, 77.5946),
    'bengaluru': (12.9716, 77.5946),
    'chennai': (13.0827, 80.2707),
    'madras': (13.0827, 80.2707),
    'coimbatore': (11.0168, 76.9558),
    'mangalore': (12.9141, 74.8560),
    'mangaluru': (12.9141, 74.8560),
    'mumbai': (19.0760, 72.8777),
    'delhi': (28.7041, 77.1025),
    'new delhi': (28.6139, 77.2090),
    'hyderabad': (17.3850, 78.4867),
    'kolkata': (22.5726, 88.3639),
    'pune': (18.5204, 73.8567),
}

# Default centroid (Kerala center - Thrissur)
DEFAULT_COORDINATES = (10.5276, 76.2144)

# Blood compatibility matrix
# Recipient -> Compatible Donors (who can donate to this recipient)
COMPATIBLE_DONORS_FOR_RECIPIENT = {
    'O-': ['O-'],
    'O+': ['O+', 'O-'],
    'A-': ['A-', 'O-'],
    'A+': ['A+', 'A-', 'O+', 'O-'],
    'B-': ['B-', 'O-'],
    'B+': ['B+', 'B-', 'O+', 'O-'],
    'AB-': ['AB-', 'A-', 'B-', 'O-'],
    'AB+': ['AB+', 'AB-', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-'],
}

# Donor -> Compatible Recipients (who can receive from this donor)
COMPATIBLE_RECIPIENTS_FOR_DONOR = {
    'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
    'O+': ['O+', 'A+', 'B+', 'AB+'],
    'A-': ['A-', 'A+', 'AB-', 'AB+'],
    'A+': ['A+', 'AB+'],
    'B-': ['B-', 'B+', 'AB-', 'AB+'],
    'B+': ['B+', 'AB+'],
    'AB-': ['AB-', 'AB+'],
    'AB+': ['AB+'],
}


def normalize_blood_group(bg):
    if not bg:
        return ''
    return bg.strip().upper().replace(' ', '')


def is_blood_compatible(donor_bg, recipient_bg, strict=False):
    """
    Checks if a donor's blood group is compatible with the recipient.
    If strict is True, requires exact match. Otherwise, applies medical compatibility.
    """
    d_norm = normalize_blood_group(donor_bg)
    r_norm = normalize_blood_group(recipient_bg)
    if not d_norm or not r_norm:
        return True
    if strict:
        return d_norm == r_norm
    allowed_donors = COMPATIBLE_DONORS_FOR_RECIPIENT.get(r_norm, [r_norm])
    return d_norm in allowed_donors


def get_compatible_donor_groups(recipient_bg):
    """Returns list of donor blood groups compatible with the recipient."""
    r_norm = normalize_blood_group(recipient_bg)
    return COMPATIBLE_DONORS_FOR_RECIPIENT.get(r_norm, [r_norm] if r_norm else [])


def get_coordinates_from_location(location_str):
    """
    Extracts latitude and longitude from location text or address.
    Searches known cities, districts, and landmarks using substring matching.
    """
    if not location_str:
        return DEFAULT_COORDINATES

    text = location_str.lower().strip()

    # Check direct match
    if text in LOCATION_COORDINATES:
        return LOCATION_COORDINATES[text]

    # Check substrings and tokens
    # Sort keys by length descending to match more specific tokens first (e.g. 'sulthan bathery' before 'bathery')
    sorted_keys = sorted(LOCATION_COORDINATES.keys(), key=len, reverse=True)
    for key in sorted_keys:
        if re.search(r'\b' + re.escape(key) + r'\b', text) or key in text:
            return LOCATION_COORDINATES[key]

    # Fallback: hash deterministically around Kerala bounds to provide smooth consistent relative offsets
    hash_val = sum(ord(c) for c in text)
    lat_offset = ((hash_val % 100) - 50) * 0.015
    lon_offset = (((hash_val // 100) % 100) - 50) * 0.015
    return (DEFAULT_COORDINATES[0] + lat_offset, DEFAULT_COORDINATES[1] + lon_offset)


def haversine_distance(*args):
    """
    Calculates the great-circle distance between two points on the Earth (in km)
    using the Haversine formula.
    Supports either haversine_distance(coord1, coord2) where coord = (lat, lon)
    or haversine_distance(lat1, lon1, lat2, lon2).
    """
    if len(args) == 2:
        lat1, lon1 = args[0]
        lat2, lon2 = args[1]
    elif len(args) == 4:
        lat1, lon1, lat2, lon2 = args
    else:
        raise ValueError("haversine_distance expects either 2 coordinate tuples or 4 numeric arguments (lat1, lon1, lat2, lon2)")

    # Radius of earth in kilometers
    R = 6371.0

    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))

    distance = R * c
    return round(distance, 1)


def calculate_distance_km(loc1, loc2):
    """
    Calculates distance in km between two location strings or (lat, lon) coordinate tuples.
    """
    coord1 = loc1 if isinstance(loc1, (tuple, list)) and len(loc1) == 2 else get_coordinates_from_location(str(loc1 or ''))
    coord2 = loc2 if isinstance(loc2, (tuple, list)) and len(loc2) == 2 else get_coordinates_from_location(str(loc2 or ''))
    return haversine_distance(coord1, coord2)


def format_distance_str(distance_km):
    if distance_km is None:
        return 'Nearby'
    if distance_km < 1.0:
        return f"{int(distance_km * 1000)} m away"
    return f"{distance_km:.1f} km away"


def get_nearest_hospitals(location_str, limit=10):
    """
    Finds nearest active hospitals to a given location string.
    """
    from myapp.models import hospitl_table
    hospitals = list(hospitl_table.objects.filter(status='active'))
    if not hospitals:
        hospitals = list(hospitl_table.objects.all())

    user_coord = get_coordinates_from_location(location_str)
    ranked = []

    for h in hospitals:
        h_coord = get_coordinates_from_location(h.address or h.hospital_name)
        dist = haversine_distance(user_coord, h_coord)
        ranked.append({
            'hospital': h,
            'id': h.id,
            'hospital_name': h.hospital_name,
            'address': h.address,
            'phone': h.phone,
            'email': h.email,
            'has_blood_bank': h.has_blood_bank,
            'distance_km': dist,
            'distance_str': format_distance_str(dist),
        })

    ranked.sort(key=lambda x: x['distance_km'])
    return ranked[:limit]


def get_nearest_blood_banks(location_str, blood_group=None, limit=10):
    """
    Finds nearest active blood banks to a given location string, optionally checking blood inventory stock.
    """
    from myapp.models import blood_banks_table, blood_inventory_table
    bbs = list(blood_banks_table.objects.filter(status='active'))
    if not bbs:
        bbs = list(blood_banks_table.objects.all())

    user_coord = get_coordinates_from_location(location_str)
    ranked = []

    for bb in bbs:
        bb_coord = get_coordinates_from_location(bb.address or bb.blood_bank_name)
        dist = haversine_distance(user_coord, bb_coord)
        
        stock_units = 0
        stock_status = 'Unknown'
        if blood_group:
            bg_norm = normalize_blood_group(blood_group)
            inv = blood_inventory_table.objects.filter(BLOOD_BANK=bb, blood_group=bg_norm).first()
            if inv:
                try:
                    stock_units = int(inv.units_available)
                except ValueError:
                    stock_units = 0
                stock_status = f"{stock_units} Units Available" if stock_units > 0 else "Out of Stock"

        ranked.append({
            'blood_bank': bb,
            'id': bb.id,
            'blood_bank_name': bb.blood_bank_name,
            'address': bb.address,
            'phone': bb.phone,
            'email': bb.email,
            'distance_km': dist,
            'distance_str': format_distance_str(dist),
            'stock_units': stock_units,
            'stock_status': stock_status,
        })

    ranked.sort(key=lambda x: x['distance_km'])
    return ranked[:limit]


def get_nearest_donors(location_str, blood_group=None, limit=15, strict_blood_group=False):
    """
    Finds nearest eligible donors to a given location string with blood group compatibility.
    """
    from myapp.models import donor_table
    donors_qs = donor_table.objects.filter(eligibility_status='eligible')
    
    if blood_group:
        if strict_blood_group:
            donors_qs = donors_qs.filter(blood_group=normalize_blood_group(blood_group))
        else:
            compatible_bgs = get_compatible_donor_groups(blood_group)
            donors_qs = donors_qs.filter(blood_group__in=compatible_bgs)

    donors = list(donors_qs)
    user_coord = get_coordinates_from_location(location_str)
    ranked = []

    for d in donors:
        d_coord = get_coordinates_from_location(d.address)
        dist = haversine_distance(user_coord, d_coord)
        ranked.append({
            'donor': d,
            'id': d.id,
            'name': d.USER.name if d.USER else 'Donor',
            'blood_group': d.blood_group,
            'address': d.address,
            'phone': d.USER.phone if d.USER else None,
            'distance_km': dist,
            'distance_str': format_distance_str(dist),
            'is_compatible': is_blood_compatible(d.blood_group, blood_group) if blood_group else True,
        })

    ranked.sort(key=lambda x: x['distance_km'])
    return ranked[:limit]


def rank_blood_requests_by_distance(requests_qs_or_list, user_location_str):
    """
    Takes a queryset or list of blood requests, computes proximity distance to user_location_str,
    and returns a sorted list of requests with distance_km and distance_str attributes attached.
    """
    user_coord = get_coordinates_from_location(user_location_str)
    ranked = []

    for req in requests_qs_or_list:
        # Determine request coordinates: prefer patient request location, fallback to hospital address
        req_location = req.location or (req.HOSPITAL.address if req.HOSPITAL else '')
        req_coord = get_coordinates_from_location(req_location)
        dist = haversine_distance(user_coord, req_coord)
        
        req.distance_km = dist
        req.distance_str = format_distance_str(dist)
        ranked.append(req)

    ranked.sort(key=lambda r: getattr(r, 'distance_km', 999999.0))
    return ranked
