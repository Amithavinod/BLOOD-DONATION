from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class user_table(models.Model):
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.TextField()
    email=models.TextField()
    phone=models.BigIntegerField()
    role = models.TextField()
    status = models.TextField()
    created_at = models.DateField()


class donor_table(models.Model):
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    dob=models.DateField()
    blood_group = models.TextField()
    address = models.TextField()
    last_donation_date = models.DateField(null=True, blank=True)
    eligibility_status = models.TextField()

class hospitl_table(models.Model):
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    hospital_name=models.TextField()
    license_number=models.TextField()
    address=models.TextField()
    contact_person=models.TextField()
    phone=models.BigIntegerField()
    email=models.TextField()
    status=models.TextField()
    has_blood_bank = models.TextField(default='no')


class patient_table(models.Model):
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    HOSPITAL=models.ForeignKey(hospitl_table,on_delete=models.CASCADE, null=True, blank=True)
    name=models.TextField()
    dob=models.DateField(null=True, blank=True)
    blood_group=models.TextField()
    address=models.TextField()
    is_first_login=models.BooleanField(default=True)

class blood_banks_table(models.Model):
    LOGIN=models.ForeignKey(User,on_delete=models.CASCADE)
    blood_bank_name=models.TextField()
    license_number=models.TextField()
    address=models.TextField()
    contact_person=models.TextField()
    phone=models.BigIntegerField()
    email=models.TextField()
    status=models.TextField()

class blood_requests_table(models.Model):
    PATIENT=models.ForeignKey(patient_table,on_delete=models.CASCADE)
    HOSPITAL=models.ForeignKey(hospitl_table,on_delete=models.CASCADE)
    blood_group=models.TextField()
    units_required=models.TextField()
    location=models.TextField()
    description=models.TextField()
    request_status=models.TextField()
    emergency=models.TextField()
    created_at=models.TextField()
    verified_at=models.TextField()
    patient_name = models.TextField(null=True, blank=True)
    age = models.IntegerField(null=True, blank=True)
    required_date = models.DateField(null=True, blank=True)
    document = models.FileField(upload_to='documents/', null=True, blank=True)

class donor_response_table(models.Model):
    BLOOD_REQUEST=models.ForeignKey(blood_requests_table,on_delete=models.CASCADE)
    DONOR=models.ForeignKey(donor_table,on_delete=models.CASCADE)
    response_status=models.TextField()
    response_time=models.TextField()

class blood_inventory_table(models.Model):
    BLOOD_BANK=models.ForeignKey(blood_banks_table,on_delete=models.CASCADE)
    blood_group=models.TextField()
    units_available=models.TextField()
    last_updated=models.TextField()

class donation_history_table(models.Model):
    DONOR=models.ForeignKey(donor_table,on_delete=models.CASCADE)
    BLOOD_BANK=models.ForeignKey(blood_banks_table,on_delete=models.CASCADE)
    donation_date=models.DateField()
    blood_group=models.TextField()
    units_donated=models.TextField()
    donation_type=models.TextField()

class admin_table(models.Model):
    USER=models.ForeignKey(user_table,on_delete=models.CASCADE)
    designation=models.TextField()


class transfusion_table(models.Model):
    BLOOD_REQUEST=models.ForeignKey(blood_requests_table,on_delete=models.CASCADE)
    donor_id=models.TextField()
    blood_bag_id=models.TextField()
    quantity=models.TextField()
    transfusion_date=models.DateField()
    staff_name=models.TextField()
    clinical_notes=models.TextField()


class blood_allocation_table(models.Model):
    BLOOD_REQUEST = models.ForeignKey(blood_requests_table, on_delete=models.CASCADE)
    BLOOD_BANK = models.ForeignKey(blood_banks_table, on_delete=models.CASCADE)
    blood_group = models.TextField()
    units_allocated = models.IntegerField(default=0)
    status = models.TextField(default='RESERVED')  # 'RESERVED', 'USED', 'RETURNED'
    allocated_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    notes = models.TextField(blank=True, default='')


class appointment_table(models.Model):
    USER = models.ForeignKey(user_table, on_delete=models.CASCADE)
    BLOOD_BANK = models.ForeignKey(blood_banks_table, on_delete=models.CASCADE)
    appointment_date = models.DateField()
    time_slot = models.TextField()
    purpose = models.TextField(default='Voluntary Blood Donation')
    status = models.TextField(default='PENDING')  # PENDING, APPROVED, REJECTED, COMPLETED, CANCELLED
    notes = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

























