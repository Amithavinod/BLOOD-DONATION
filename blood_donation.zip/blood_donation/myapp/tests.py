from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from myapp.models import hospitl_table, user_table, patient_table, blood_requests_table, donor_table, blood_banks_table, blood_inventory_table, donor_response_table
import datetime
from django.core.files.uploadedfile import SimpleUploadedFile

# Monkeypatch Django's BaseContext.__copy__ to fix Python 3.14 compatibility bug
from django.template.context import BaseContext
def base_context_copy(self):
    duplicate = self.__class__.__new__(self.__class__)
    duplicate.__dict__.update(self.__dict__)
    duplicate.dicts = self.dicts[:]
    return duplicate
BaseContext.__copy__ = base_context_copy

class DonorRegistrationValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.url = '/myapp/donor_registration/'

    def test_valid_registration(self):
        response = self.client.post(self.url, {
            'full_name': 'Test Donor',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'valid_donor@test.com',
            'address': '123 Test St',
            'last_donation': '2026-04-01',
            'username': 'testdonor1',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertRedirects(response, '/myapp/loginpage/')
        self.assertTrue(User.objects.filter(username='testdonor1').exists())

    def test_underage_registration_fails(self):
        dob_under_18 = (datetime.date.today() - datetime.timedelta(days=365 * 10)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Young Donor',
            'dob': dob_under_18,
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'young@test.com',
            'address': '123 Test St',
            'last_donation': '',
            'username': 'youngdonor',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "You must be at least 18 years old")
        self.assertFalse(User.objects.filter(username='youngdonor').exists())

    def test_over_150_age_donor_registration_fails(self):
        dob_over_150 = (datetime.date.today() - datetime.timedelta(days=365 * 152)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Ancient Donor',
            'dob': dob_over_150,
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'ancient@test.com',
            'address': '123 Test St',
            'last_donation': '',
            'username': 'ancientdonor',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Age must be at most 150 years old")
        self.assertFalse(User.objects.filter(username='ancientdonor').exists())

    def test_invalid_phone_fails(self):
        response = self.client.post(self.url, {
            'full_name': 'Phone Test',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '987654321', # 9 digits
            'email': 'phone@test.com',
            'address': '123 Test St',
            'last_donation': '',
            'username': 'phonetest',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Phone number must be exactly 10 digits")
        self.assertFalse(User.objects.filter(username='phonetest').exists())

    def test_invalid_email_fails(self):
        response = self.client.post(self.url, {
            'full_name': 'Email Test',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'invalidemail', # invalid format
            'address': '123 Test St',
            'last_donation': '',
            'username': 'emailtest',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid email address")
        self.assertFalse(User.objects.filter(username='emailtest').exists())

    def test_recent_last_donation_success_ineligible(self):
        recent_date = (datetime.date.today() - datetime.timedelta(days=30)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Recent Donor',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'recent@test.com',
            'address': '123 Test St',
            'last_donation': recent_date,
            'username': 'recentdonor',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 302)
        donor = donor_table.objects.get(USER__LOGIN__username='recentdonor')
        self.assertEqual(donor.eligibility_status, 'ineligible')

    def test_future_last_donation_fails(self):
        future_date = (datetime.date.today() + datetime.timedelta(days=5)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Future Donor',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'future@test.com',
            'address': '123 Test St',
            'last_donation': future_date,
            'username': 'futuredonor',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Last donation date cannot be in the future")
        self.assertFalse(User.objects.filter(username='futuredonor').exists())


class PatientRegistrationValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.url = '/myapp/patient_registration/'
        
        # Create a test hospital for Patient registration
        h_user = User.objects.create_user(username='testhosp', password='Password@123', email='testhosp@gmail.com')
        group, _ = Group.objects.get_or_create(name='hospital')
        h_user.groups.add(group)
        
        h_user_tab = user_table.objects.create(
            LOGIN=h_user,
            name='Test Hospital',
            email='testhosp@gmail.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        
        self.hospital = hospitl_table.objects.create(
            LOGIN=h_user,
            USER=h_user_tab,
            hospital_name='Test Hospital',
            license_number='LIC123',
            address='123 Hospital Rd',
            contact_person='Dr. Test',
            phone=9876543210,
            email='testhosp@gmail.com',
            status='active'
        )

    def test_valid_patient_registration(self):
        response = self.client.post(self.url, {
            'full_name': 'Test Patient',
            'dob': '2000-01-01',
            'gender': 'Male',
            'blood_group': 'O+',
            'phone': '9876543210',
            'email': 'patient@test.com',
            'address': '123 Test Rd',
            'hospital': self.hospital.id,
            'username': 'testpatient',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertRedirects(response, '/myapp/loginpage/')
        self.assertTrue(User.objects.filter(username='testpatient').exists())
        # Check patient dob is stored
        patient = patient_table.objects.get(LOGIN__username='testpatient')
        self.assertEqual(patient.dob, datetime.date(2000, 1, 1))

    def test_underage_patient_registration_fails(self):
        dob_under_18 = (datetime.date.today() - datetime.timedelta(days=365 * 10)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Young Patient',
            'dob': dob_under_18,
            'gender': 'Male',
            'blood_group': 'O+',
            'phone': '9876543210',
            'email': 'youngpatient@test.com',
            'address': '123 Test Rd',
            'hospital': self.hospital.id,
            'username': 'youngpatient',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "You must be at least 18 years old")
        self.assertFalse(User.objects.filter(username='youngpatient').exists())

    def test_over_150_age_patient_registration_fails(self):
        dob_over_150 = (datetime.date.today() - datetime.timedelta(days=365 * 152)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'full_name': 'Ancient Patient',
            'dob': dob_over_150,
            'gender': 'Male',
            'blood_group': 'O+',
            'phone': '9876543210',
            'email': 'ancientpatient@test.com',
            'address': '123 Test Rd',
            'hospital': self.hospital.id,
            'username': 'ancientpatient',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Age must be at most 150 years old")
        self.assertFalse(User.objects.filter(username='ancientpatient').exists())

    def test_invalid_phone_fails(self):
        response = self.client.post(self.url, {
            'full_name': 'Patient Phone Test',
            'dob': '2000-01-01',
            'gender': 'Male',
            'blood_group': 'O+',
            'phone': '987654321', # 9 digits
            'email': 'patientphone@test.com',
            'address': '123 Test Rd',
            'hospital': self.hospital.id,
            'username': 'patientphone',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Phone number must be exactly 10 digits")

    def test_invalid_email_fails(self):
        response = self.client.post(self.url, {
            'full_name': 'Patient Email Test',
            'dob': '2000-01-01',
            'gender': 'Male',
            'blood_group': 'O+',
            'phone': '9876543210',
            'email': 'invalidemail',
            'address': '123 Test Rd',
            'hospital': self.hospital.id,
            'username': 'patientemail',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid email address")


class HospitalRegistrationValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.url = '/myapp/hospital_registration/'

    def test_valid_hospital_registration(self):
        response = self.client.post(self.url, {
            'hospital_name': 'City General Hospital',
            'license_number': 'LIC7890',
            'address': '789 City Rd',
            'contact_person': 'Dr. Alice',
            'phone': '9876543210',
            'email': 'cityhosp@test.com',
            'username': 'cityhosp',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertRedirects(response, '/myapp/loginpage/')
        self.assertTrue(User.objects.filter(username='cityhosp').exists())

    def test_invalid_phone_fails(self):
        response = self.client.post(self.url, {
            'hospital_name': 'City General Hospital',
            'license_number': 'LIC7890',
            'address': '789 City Rd',
            'contact_person': 'Dr. Alice',
            'phone': '98765432', # 8 digits
            'email': 'cityhosp@test.com',
            'username': 'cityhosp',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Phone number must be exactly 10 digits")

    def test_invalid_email_fails(self):
        response = self.client.post(self.url, {
            'hospital_name': 'City General Hospital',
            'license_number': 'LIC7890',
            'address': '789 City Rd',
            'contact_person': 'Dr. Alice',
            'phone': '9876543210',
            'email': 'invalidemail',
            'username': 'cityhosp',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid email address")


class BloodBankRegistrationValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.url = '/myapp/bloodbank_registration/'

    def test_valid_bloodbank_registration(self):
        response = self.client.post(self.url, {
            'bloodbank_name': 'Central Blood Bank',
            'license_number': 'LIC999',
            'contact_person': 'John Bank',
            'address': '999 Bank Rd',
            'phone': '9876543210',
            'email': 'centralbank@test.com',
            'username': 'centralbank',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertRedirects(response, '/myapp/loginpage/')
        self.assertTrue(User.objects.filter(username='centralbank').exists())

    def test_invalid_phone_fails(self):
        response = self.client.post(self.url, {
            'bloodbank_name': 'Central Blood Bank',
            'license_number': 'LIC999',
            'contact_person': 'John Bank',
            'address': '999 Bank Rd',
            'phone': '98765432101', # 11 digits
            'email': 'centralbank@test.com',
            'username': 'centralbank',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Phone number must be exactly 10 digits")

    def test_invalid_email_fails(self):
        response = self.client.post(self.url, {
            'bloodbank_name': 'Central Blood Bank',
            'license_number': 'LIC999',
            'contact_person': 'John Bank',
            'address': '999 Bank Rd',
            'phone': '9876543210',
            'email': 'invalidemail',
            'username': 'centralbank',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid email address")


class PatientBloodRequestValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.url = '/myapp/patient_blood_request/'
        
        # Create a test hospital
        h_user = User.objects.create_user(username='testhosp2', password='Password@123', email='testhosp2@gmail.com')
        group_h, _ = Group.objects.get_or_create(name='hospital')
        h_user.groups.add(group_h)
        h_user_tab = user_table.objects.create(
            LOGIN=h_user,
            name='Test Hospital 2',
            email='testhosp2@gmail.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=h_user,
            USER=h_user_tab,
            hospital_name='Test Hospital 2',
            license_number='LIC777',
            address='777 Hosp St',
            contact_person='Dr. Bob',
            phone=9876543210,
            email='testhosp2@gmail.com',
            status='active'
        )

        # Create a test patient and force login
        self.p_user = User.objects.create_user(username='testpatient2', password='Password@123', email='p2@gmail.com')
        group_p, _ = Group.objects.get_or_create(name='patient')
        self.p_user.groups.add(group_p)
        self.p_user_tab = user_table.objects.create(
            LOGIN=self.p_user,
            name='Test Patient 2',
            email='p2@gmail.com',
            phone=9876543210,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        self.patient = patient_table.objects.create(
            LOGIN=self.p_user,
            USER=self.p_user_tab,
            HOSPITAL=self.hospital,
            name='Test Patient 2',
            blood_group='O+',
            address='Test Address'
        )
        self.client.force_login(self.p_user)

    def test_valid_blood_request(self):
        # Optional document can be added, let's test upload too
        document = SimpleUploadedFile("prescription.png", b"file_content", content_type="image/png")
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Relative Patient',
            'age': '45',
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Emergency surgery requirement.',
            'document': document
        })
        self.assertRedirects(response, '/myapp/patient_home/')
        self.assertTrue(blood_requests_table.objects.filter(patient_name='Relative Patient').exists())

    def test_past_date_fails(self):
        yesterday = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Relative Patient',
            'age': '45',
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': yesterday,
            'description': 'Emergency surgery requirement.'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Required date cannot be in the past")
        self.assertFalse(blood_requests_table.objects.filter(patient_name='Relative Patient').exists())

    def test_invalid_age_fails(self):
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Relative Patient',
            'age': '-5', # negative
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Emergency surgery requirement.'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid age")

    def test_age_over_150_fails(self):
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Relative Patient',
            'age': '151',
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Emergency surgery requirement.'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Please enter a valid age")
        self.assertFalse(blood_requests_table.objects.filter(patient_name='Relative Patient', age=151).exists())

    def test_valid_age_150_succeeds(self):
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Centenarian Patient',
            'age': '150',
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Blood request for elder patient.'
        })
        self.assertRedirects(response, '/myapp/patient_home/')
        self.assertTrue(blood_requests_table.objects.filter(patient_name='Centenarian Patient', age=150).exists())

    def test_invalid_file_type_fails(self):
        document = SimpleUploadedFile("prescription.txt", b"file_content", content_type="text/plain")
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'Relative Patient',
            'age': '45',
            'blood_group': 'O+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Emergency surgery requirement.',
            'document': document
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Supported file formats are JPG, PNG, or PDF")

    def test_get_request_passes_profile_and_age(self):
        # Set patient DOB to exactly 30 years ago
        today = datetime.date.today()
        try:
            self.patient.dob = today.replace(year=today.year - 30)
        except ValueError:
            self.patient.dob = today.replace(year=today.year - 30, day=28)
        self.patient.save()
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertIn('patient_profile', response.context)
        self.assertEqual(response.context['patient_age'], 30)

    def test_request_blood_for_minor_succeeds(self):
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        response = self.client.post(self.url, {
            'patient_name': 'My Little Child',
            'age': '6', # age under 18
            'blood_group': 'O+',
            'units_required': '1 Unit',
            'hospital': self.hospital.id,
            'location': 'Kozhikode',
            'required_date': tomorrow,
            'description': 'Child needs blood for minor surgery.'
        })
        self.assertRedirects(response, '/myapp/patient_home/')
        self.assertTrue(blood_requests_table.objects.filter(patient_name='My Little Child', age=6).exists())


class PatientLoginRedirectionAndProfileEditTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Set up group and hospital
        self.hospital_group, _ = Group.objects.get_or_create(name='hospital')
        self.patient_group, _ = Group.objects.get_or_create(name='patient')
        
        self.h_user = User.objects.create_user(username='testhosp3', password='Password@123', email='testhosp3@gmail.com')
        self.h_user.groups.add(self.hospital_group)
        self.h_user_tab = user_table.objects.create(
            LOGIN=self.h_user,
            name='Test Hospital 3',
            email='testhosp3@gmail.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=self.h_user,
            USER=self.h_user_tab,
            hospital_name='Test Hospital 3',
            license_number='LIC888',
            address='888 Hosp Rd',
            contact_person='Dr. Charlie',
            phone=9876543210,
            email='testhosp3@gmail.com',
            status='active'
        )

        # Create patient
        self.p_user = User.objects.create_user(username='testpatient3', password='Password@123', email='p3@gmail.com')
        self.p_user.groups.add(self.patient_group)
        self.p_user_tab = user_table.objects.create(
            LOGIN=self.p_user,
            name='Original Name',
            email='p3@gmail.com',
            phone=9876543210,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        self.patient = patient_table.objects.create(
            LOGIN=self.p_user,
            USER=self.p_user_tab,
            HOSPITAL=self.hospital,
            name='Original Name',
            blood_group='O+',
            address='Original Address',
            is_first_login=True
        )

    def test_first_and_second_login_redirection(self):
        # First login redirect
        response = self.client.post('/myapp/login_get/', {
            'username': 'testpatient3',
            'password': 'Password@123'
        })
        self.assertRedirects(response, '/myapp/patient_blood_request/')
        
        # Check database is_first_login is now False
        self.patient.refresh_from_db()
        self.assertFalse(self.patient.is_first_login)

        # Logout and login again (second login)
        self.client.logout()
        response2 = self.client.post('/myapp/login_get/', {
            'username': 'testpatient3',
            'password': 'Password@123'
        })
        self.assertRedirects(response2, '/myapp/patient_home/')

    def test_edit_profile(self):
        self.client.force_login(self.p_user)
        # Edit profile POST request
        response = self.client.post('/myapp/edit_profile/', {
            'full_name': 'Updated Name',
            'email': 'updated@gmail.com',
            'phone': '8888888888',
            'blood_group': 'B+',
            'address': 'Updated Address'
        })
        self.assertRedirects(response, '/myapp/patient_home/')

        # Verify DB updates
        self.p_user.refresh_from_db()
        self.p_user_tab.refresh_from_db()
        self.patient.refresh_from_db()

        self.assertEqual(self.p_user.email, 'updated@gmail.com')
        self.assertEqual(self.p_user_tab.name, 'Updated Name')
        self.assertEqual(self.p_user_tab.phone, 8888888888)
        self.assertEqual(self.patient.name, 'Updated Name')
        self.assertEqual(self.patient.blood_group, 'B+')
        self.assertEqual(self.patient.address, 'Updated Address')

    def test_accept_blood_request(self):
        from myapp.models import blood_requests_table, donor_table, donor_response_table
        
        # Create a donor user & profile
        d_user = User.objects.create_user(username='testdonor3', password='Password@123', email='d3@gmail.com')
        group_d, _ = Group.objects.get_or_create(name='donor')
        d_user.groups.add(group_d)
        d_user_tab = user_table.objects.create(
            LOGIN=d_user,
            name='Test Donor 3',
            email='d3@gmail.com',
            phone=9876543210,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )
        donor = donor_table.objects.create(
            LOGIN=d_user,
            USER=d_user_tab,
            dob='2000-01-01',
            blood_group='O+',
            address='Donor address',
            eligibility_status='eligible'
        )
        
        # Create a blood request
        req = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='2 Units',
            location='Kozhikode',
            description='Need blood',
            request_status='APPROVED',
            emergency='yes',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            verified_at=datetime.date.today().strftime('%Y-%m-%d')
        )
        
        # Log in as donor and accept request
        self.client.force_login(d_user)
        response = self.client.post('/myapp/accept_blood_request/', {
            'request_id': req.id
        })
        self.assertRedirects(response, '/myapp/donor_home/?tab=verified')
        
        # Verify response recorded in DB
        self.assertTrue(donor_response_table.objects.filter(BLOOD_REQUEST=req, DONOR=donor).exists())

        # Verify request is hidden from verified_requests and NOT placed in my_requests
        donor_home_res = self.client.get('/myapp/donor_home/')
        self.assertNotIn(req, donor_home_res.context['verified_requests'])
        self.assertNotIn(req, donor_home_res.context['my_requests'])

    def test_patient_becomes_donor_after_first_request(self):
        from myapp.models import donor_table
        
        # Verify user is not a donor initially
        self.assertFalse(donor_table.objects.filter(LOGIN=self.p_user).exists())
        self.assertFalse(self.p_user.groups.filter(name='donor').exists())

        # Submit a blood request
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        self.client.force_login(self.p_user)
        response = self.client.post('/myapp/patient_blood_request/', {
            'patient_name': 'My Relative',
            'age': '30',
            'blood_group': 'O+',
            'units_required': '1 Unit',
            'hospital': self.hospital.id,
            'location': 'City',
            'required_date': tomorrow,
            'description': 'Need blood urgently'
        })
        self.assertRedirects(response, '/myapp/patient_home/')
        
        # Verify patient has now become a donor
        self.assertTrue(donor_table.objects.filter(LOGIN=self.p_user).exists())
        self.assertTrue(self.p_user.groups.filter(name='donor').exists())

        donor = donor_table.objects.get(LOGIN=self.p_user)
        self.assertEqual(donor.blood_group, 'O+')
        self.assertEqual(donor.eligibility_status, 'eligible')

    def test_patient_can_accept_blood_request(self):
        from myapp.models import blood_requests_table, donor_table, donor_response_table
        
        # Create another patient's blood request
        other_p_user = User.objects.create_user(username='otherpatient', password='Password@123', email='other@gmail.com')
        other_p_user_tab = user_table.objects.create(
            LOGIN=other_p_user,
            name='Other Patient',
            email='other@gmail.com',
            phone=9876543210,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        other_patient = patient_table.objects.create(
            LOGIN=other_p_user,
            USER=other_p_user_tab,
            HOSPITAL=self.hospital,
            name='Other Patient',
            blood_group='O+',
            address='Other Address'
        )
        
        req = blood_requests_table.objects.create(
            PATIENT=other_patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='2 Units',
            location='Kozhikode',
            description='Need blood',
            request_status='APPROVED',
            emergency='yes',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            verified_at=datetime.date.today().strftime('%Y-%m-%d')
        )
        
        # Patient 3 is logged in. They have not made any requests, so they are not a donor yet.
        self.client.force_login(self.p_user)
        self.assertFalse(donor_table.objects.filter(LOGIN=self.p_user).exists())

        # Accept other patient's request
        response = self.client.post('/myapp/accept_blood_request/', {
            'request_id': req.id
        })
        self.assertRedirects(response, '/myapp/patient_home/?tab=verified')
        
        # Verify donor profile was automatically created and response is recorded
        self.assertTrue(donor_table.objects.filter(LOGIN=self.p_user).exists())
        donor = donor_table.objects.get(LOGIN=self.p_user)
        self.assertTrue(donor_response_table.objects.filter(BLOOD_REQUEST=req, DONOR=donor).exists())

        # Verify request is hidden from verified_requests and NOT placed in my_requests in patient_home
        pat_home_res = self.client.get('/myapp/patient_home/')
        self.assertNotIn(req, pat_home_res.context['verified_requests'])
        self.assertNotIn(req, pat_home_res.context['my_requests'])

    def test_patient_cannot_accept_own_blood_request(self):
        from myapp.models import blood_requests_table, donor_table, donor_response_table
        
        # Patient 3 creates a request, automatically becomes a donor
        tomorrow = (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        self.client.force_login(self.p_user)
        self.client.post('/myapp/patient_blood_request/', {
            'patient_name': 'Self',
            'age': '30',
            'blood_group': 'O+',
            'units_required': '1 Unit',
            'hospital': self.hospital.id,
            'location': 'City',
            'required_date': tomorrow,
            'description': 'Need blood'
        })
        
        req = blood_requests_table.objects.filter(PATIENT=self.patient).first()
        req.request_status = 'APPROVED'
        req.save()
        
        # Try to accept own request
        response = self.client.post('/myapp/accept_blood_request/', {
            'request_id': req.id
        })
        
        # Verify request redirect and that it was NOT accepted
        self.assertRedirects(response, '/myapp/patient_home/')
        donor = donor_table.objects.get(LOGIN=self.p_user)
        self.assertFalse(donor_response_table.objects.filter(BLOOD_REQUEST=req, DONOR=donor).exists())


class HospitalDashboardAndActionsTests(TestCase):
    def setUp(self):
        from django.contrib.auth.models import User, Group
        from myapp.models import hospitl_table, patient_table, user_table, blood_requests_table

        # Setup hospital user
        self.h_user = User.objects.create_user(username='testhospital', password='Password@123', email='h@gmail.com')
        group_h, _ = Group.objects.get_or_create(name='hospital')
        self.h_user.groups.add(group_h)
        self.h_user_tab = user_table.objects.create(
            LOGIN=self.h_user,
            name='Test Hospital',
            email='h@gmail.com',
            phone=9999999999,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=self.h_user,
            USER=self.h_user_tab,
            hospital_name='Test Hospital',
            license_number='LIC123456',
            address='Hospital Road',
            contact_person='Dr. Smith',
            phone=9999999999,
            email='h@gmail.com',
            status='active'
        )

        # Setup patient user
        self.p_user = User.objects.create_user(username='testpatient', password='Password@123', email='p@gmail.com')
        group_p, _ = Group.objects.get_or_create(name='patient')
        self.p_user.groups.add(group_p)
        self.p_user_tab = user_table.objects.create(
            LOGIN=self.p_user,
            name='Test Patient',
            email='p@gmail.com',
            phone=8888888888,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        self.patient = patient_table.objects.create(
            LOGIN=self.p_user,
            USER=self.p_user_tab,
            name='Test Patient',
            dob='2000-01-01',
            blood_group='O+',
            address='Patient address',
            is_first_login=False
        )

        # Pending Request
        self.req = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='2 Units',
            location='Ward A',
            description='Needs blood urgently',
            request_status='PENDING',
            emergency='no',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            verified_at=''
        )

    def test_hospital_dashboard_view(self):
        self.client.force_login(self.h_user)
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('pending_requests', response.context)
        self.assertIn('all_requests', response.context)
        self.assertIn('transfusion_records', response.context)
        self.assertIn('new_requests_today', response.context)
        self.assertIn('approved_requests_today', response.context)
        self.assertIn('fulfilled_today', response.context)
        self.assertIn('donors_accepted', response.context)
        self.assertIn('completed_count', response.context)
        self.assertContains(response, "Today's Activity")
        self.assertContains(response, "New Requests")
        self.assertContains(response, "Approved Requests")
        self.assertContains(response, "Requests Fulfilled")
        self.assertContains(response, "Total Donors Accepted")
        self.assertContains(response, "All Requests")
        # Ensure question mark icon and topbar notification icon are removed from top navbar
        self.assertNotContains(response, 'class="btn-header-action"><i class="bi bi-question-circle"></i>')
        self.assertNotContains(response, 'class="btn-header-action" onclick="switchTab(\'notifications\')">')

    def test_hospital_approve_request(self):
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_approve_request/', {
            'request_id': self.req.id,
            'remarks': 'Approved by Dr. Smith'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'APPROVED')
        self.assertIn('Approved by Dr. Smith', self.req.description)

    def test_hospital_reject_request(self):
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_reject_request/', {
            'request_id': self.req.id,
            'remarks': 'Incorrect detail'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'REJECTED')
        self.assertIn('Incorrect detail', self.req.description)

    def test_hospital_create_emergency_request(self):
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_create_emergency/', {
            'patient_name': 'Emergency Patient',
            'age': '35',
            'gender': 'Male',
            'blood_group': 'B+',
            'units_required': '3 Units',
            'hospital': self.hospital.id,
            'location': 'ICU',
            'description': 'Accident emergency'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        from myapp.models import blood_requests_table
        new_req = blood_requests_table.objects.filter(patient_name='Emergency Patient').first()
        self.assertIsNotNone(new_req)
        self.assertEqual(new_req.request_status, 'APPROVED')
        self.assertEqual(new_req.emergency, 'yes')
        self.assertEqual(new_req.age, 35)

    def test_hospital_create_emergency_invalid_age_fails(self):
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_create_emergency/', {
            'patient_name': 'Emergency Patient Over Age',
            'age': '151',
            'gender': 'Male',
            'blood_group': 'B+',
            'units_required': '3 Units',
            'hospital': self.hospital.id,
            'location': 'ICU',
            'description': 'Accident emergency'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        from myapp.models import blood_requests_table
        self.assertFalse(blood_requests_table.objects.filter(patient_name='Emergency Patient Over Age').exists())

    def test_hospital_save_transfusion(self):
        # Set request as APPROVED first
        self.req.request_status = 'APPROVED'
        self.req.save()

        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.req.id,
            'donor_id': 'DONOR100',
            'blood_bag_id': 'BAG100',
            'quantity': '300 ml',
            'staff_name': 'Nurse Stella',
            'clinical_notes': 'Successful transfusion'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        
        # Verify status set to COMPLETED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'COMPLETED')
        
        # Verify transfusion log
        from myapp.models import transfusion_table
        tx = transfusion_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertIsNotNone(tx)
        self.assertEqual(tx.donor_id, 'DONOR100')
        self.assertEqual(tx.staff_name, 'Nurse Stella')

    def test_hospital_edit_profile(self):
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/edit_profile/', {
            'full_name': 'Updated Hospital Name',
            'contact_person': 'Dr. John',
            'phone': '7777777777',
            'email': 'updated@hospital.com',
            'address': 'New Hospital Address'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        
        self.hospital.refresh_from_db()
        self.assertEqual(self.hospital.hospital_name, 'Updated Hospital Name')
        self.assertEqual(self.hospital.contact_person, 'Dr. John')
        self.assertEqual(self.hospital.phone, 7777777777)
        self.assertEqual(self.hospital.email, 'updated@hospital.com')
        self.assertEqual(self.hospital.address, 'New Hospital Address')


class BloodBankDashboardAndActionsTests(TestCase):
    def setUp(self):
        from myapp.models import blood_banks_table, donor_table
        # Setup bloodbank user
        self.bb_user = User.objects.create_user(username='testbloodbank', password='Password@123', email='bb@gmail.com')
        group_bb, _ = Group.objects.get_or_create(name='bloodbank')
        self.bb_user.groups.add(group_bb)
        self.bb_user_tab = user_table.objects.create(
            LOGIN=self.bb_user,
            name='Test Blood Bank',
            email='bb@gmail.com',
            phone=9999999999,
            role='bloodbank',
            status='active',
            created_at=datetime.date.today()
        )
        self.bloodbank = blood_banks_table.objects.create(
            LOGIN=self.bb_user,
            blood_bank_name='Test Blood Bank',
            license_number='LIC-BB-123',
            address='Blood Street',
            contact_person='Dr. Hema',
            phone=9999999999,
            email='bb@gmail.com',
            status='active'
        )

        # Setup patient and request to test fulfillment
        self.h_user = User.objects.create_user(username='bb_hosp', password='Password@123', email='bbh@gmail.com')
        group_h, _ = Group.objects.get_or_create(name='hospital')
        self.h_user.groups.add(group_h)
        self.h_user_tab = user_table.objects.create(
            LOGIN=self.h_user,
            name='BB Hospital',
            email='bbh@gmail.com',
            phone=9999999999,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=self.h_user,
            USER=self.h_user_tab,
            hospital_name='BB Hospital',
            license_number='LIC-H-123',
            address='Hospital Street',
            contact_person='Dr. Alice',
            phone=9999999999,
            email='bbh@gmail.com',
            status='active'
        )

        self.p_user = User.objects.create_user(username='bb_patient', password='Password@123', email='bbp@gmail.com')
        group_p, _ = Group.objects.get_or_create(name='patient')
        self.p_user.groups.add(group_p)
        self.p_user_tab = user_table.objects.create(
            LOGIN=self.p_user,
            name='BB Patient',
            email='bbp@gmail.com',
            phone=8888888888,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        self.patient = patient_table.objects.create(
            LOGIN=self.p_user,
            USER=self.p_user_tab,
            name='BB Patient',
            dob='2000-01-01',
            blood_group='O+',
            address='Patient address',
            is_first_login=False
        )

        self.req = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='2 Units',
            location='Ward B',
            description='Needs blood urgently',
            request_status='APPROVED',
            emergency='no',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            verified_at=datetime.date.today().strftime('%Y-%m-%d')
        )

        # Setup inventory
        from myapp.models import blood_inventory_table
        blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
        for bg in blood_groups:
            blood_inventory_table.objects.create(
                BLOOD_BANK=self.bloodbank,
                blood_group=bg,
                units_available='0',
                last_updated=datetime.date.today().strftime('%Y-%m-%d')
            )

    def test_bloodbank_dashboard_view(self):
        self.client.force_login(self.bb_user)
        response = self.client.get('/myapp/bloodbank_home/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('inventory', response.context)
        self.assertIn('total_units', response.context)
        self.assertIn('low_stock_alerts', response.context)
        self.assertNotContains(response, 'Sorted by Proximity')
        self.assertNotContains(response, 'Real-Time Feed')
        self.assertNotContains(response, 'bi-question-circle')
        
        # Verify A+ inventory is initialized to 0
        from myapp.models import blood_inventory_table
        item = blood_inventory_table.objects.filter(BLOOD_BANK=self.bloodbank, blood_group='A+').first()
        self.assertIsNotNone(item)
        self.assertEqual(item.units_available, '0')

    def test_update_inventory(self):
        self.client.force_login(self.bb_user)
        response = self.client.post('/myapp/bloodbank_home/', {
            'action': 'update_inventory',
            'units_A+': '15',
            'units_O+': '8'
        })
        self.assertRedirects(response, '/myapp/bloodbank_home/')
        
        from myapp.models import blood_inventory_table
        item_ap = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='A+')
        self.assertEqual(item_ap.units_available, '15')
        item_op = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        self.assertEqual(item_op.units_available, '8')

    def test_fulfill_request_success_and_deduction(self):
        from myapp.models import blood_inventory_table, blood_allocation_table
        
        # Set O+ stock to 10 units first
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '10'
        inv_item.save()

        self.client.force_login(self.bb_user)
        response = self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        self.assertRedirects(response, '/myapp/bloodbank_home/')
        
        # Verify status is DISPATCHED (temporarily allocated/reserved)
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'DISPATCHED')
        
        # Verify units_required remains unchanged (2 Units)
        self.assertEqual(self.req.units_required, '2 Units')
        
        # Verify inventory was temporarily deducted (10 - 2 = 8 units)
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '8')

        # Verify allocation record created with status RESERVED
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req, BLOOD_BANK=self.bloodbank).first()
        self.assertIsNotNone(alloc)
        self.assertEqual(alloc.status, 'RESERVED')
        self.assertEqual(alloc.units_allocated, 2)

        # Verify transfusion records created for the fulfilled units
        from myapp.models import transfusion_table
        txs = transfusion_table.objects.filter(BLOOD_REQUEST=self.req)
        self.assertEqual(txs.count(), 2)
        for tx in txs:
            self.assertEqual(tx.donor_id, f"BB-{self.bloodbank.id:03d}")
            self.assertEqual(tx.quantity, '1 Unit')
            self.assertTrue(tx.blood_bag_id.startswith(f"BB-BAG-{self.req.id:04d}"))

    def test_fulfill_request_partial_fulfillment(self):
        from myapp.models import blood_inventory_table, blood_allocation_table
        
        # Set O+ stock to 1 unit (needs 2)
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '1'
        inv_item.save()

        self.client.force_login(self.bb_user)
        response = self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        self.assertRedirects(response, '/myapp/bloodbank_home/')
        
        # Verify status is DISPATCHED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'DISPATCHED')
        
        # Verify units_required is NOT reduced from no. of units required
        self.assertEqual(self.req.units_required, '2 Units')
        
        # Verify inventory was deducted to 0
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '0')

        # Verify allocation record
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req, BLOOD_BANK=self.bloodbank).first()
        self.assertIsNotNone(alloc)
        self.assertEqual(alloc.units_allocated, 1)
        self.assertEqual(alloc.status, 'RESERVED')

        # Verify 1 transfusion record created for partial fulfillment
        from myapp.models import transfusion_table
        txs = transfusion_table.objects.filter(BLOOD_REQUEST=self.req)
        self.assertEqual(txs.count(), 1)

    def test_bloodbank_return_unused_blood_restores_inventory(self):
        from myapp.models import blood_inventory_table, blood_allocation_table, transfusion_table
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '5'
        inv_item.save()

        # Fulfill request (reserves 2 units, available becomes 3)
        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '3')
        self.assertEqual(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).count(), 2)

        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req, status='RESERVED').first()
        self.assertIsNotNone(alloc)

        # Now return unused blood
        response = self.client.post('/myapp/bloodbank_home/', {
            'action': 'return_unused_blood',
            'allocation_id': alloc.id
        })
        self.assertRedirects(response, '/myapp/bloodbank_home/')

        # Inventory must be restored back to 5
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '5')

        # Allocation status is RETURNED
        alloc.refresh_from_db()
        self.assertEqual(alloc.status, 'RETURNED')

        # Request status reopened to APPROVED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'APPROVED')

        # Transfusion records must be removed
        self.assertEqual(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).count(), 0)

    def test_hospital_return_unused_blood_restores_inventory(self):
        from myapp.models import blood_inventory_table, blood_allocation_table, transfusion_table
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '6'
        inv_item.save()

        # Fulfill request
        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '4')
        self.assertEqual(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).count(), 2)

        # Hospital returns blood
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_return_blood/', {
            'request_id': self.req.id,
            'reason': 'Patient condition stabilized, transfusion not required'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Inventory restored
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '6')

        # Allocation returned
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertEqual(alloc.status, 'RETURNED')

        # Transfusion records must be removed
        self.assertEqual(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).count(), 0)

    def test_hospital_transfusion_marks_allocation_used_without_restoring(self):
        from myapp.models import blood_inventory_table, blood_allocation_table
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '6'
        inv_item.save()

        # Fulfill request
        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '4')

        # Hospital performs transfusion
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.req.id,
            'action_type': 'fulfill',
            'donor_id': ['DONOR1'],
            'blood_bag_id': ['BAG1'],
            'quantity': ['350 ml'],
            'staff_name': 'Dr. Test'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Allocation marked USED
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertEqual(alloc.status, 'USED')

        # Inventory remains 4 (permanently used)
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '4')

    def test_timeout_auto_restores_reserved_inventory(self):
        from myapp.models import blood_inventory_table, blood_allocation_table
        from myapp.views import check_and_update_timeouts

        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '5'
        inv_item.save()

        # Fulfill request
        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '3')

        # Expire request
        self.req.required_date = datetime.date.today() - datetime.timedelta(days=1)
        self.req.save()

        check_and_update_timeouts()

        # Inventory restored back to 5
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '5')

        # Allocation status is RETURNED
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertEqual(alloc.status, 'RETURNED')
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'TIMED OUT')

    def test_fulfill_request_zero_stock_fails(self):
        from myapp.models import blood_inventory_table
        
        # Set O+ stock to 0 units
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '0'
        inv_item.save()

        self.client.force_login(self.bb_user)
        response = self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        self.assertRedirects(response, '/myapp/bloodbank_home/')
        
        # Verify status is still APPROVED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'APPROVED')
        
        # Verify units_required is unchanged (2 Units)
        self.assertEqual(self.req.units_required, '2 Units')
        
        # Verify stock remains 0
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '0')

    def test_bloodbank_realtime_clock_elements(self):
        self.client.force_login(self.bb_user)
        response = self.client.get('/myapp/bloodbank_home/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'bb-realtime-clock')
        self.assertContains(response, 'bb-realtime-date')
        self.assertNotContains(response, 'bb-metric-clock')
        self.assertNotContains(response, 'bb-metric-date')
        self.assertNotContains(response, 'Real-Time Sync')
        self.assertNotContains(response, 'Real-Time Clock')
        self.assertContains(response, 'modal-live-clock')
        self.assertContains(response, 'updateRealTimeClock')

    def test_transfusion_records_draft_and_return_label_filtering(self):
        from myapp.models import blood_inventory_table, transfusion_table
        
        # Set stock and fulfill request from blood bank
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '10'
        inv_item.save()

        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })

        # Create a non-blood-bank transfusion record (e.g. voluntary donor)
        donor_req = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='1 Unit',
            location='Ward C',
            description='Donor blood',
            request_status='COMPLETED',
            emergency='no',
            created_at='2026-09-20',
            verified_at='2026-09-20'
        )
        transfusion_table.objects.create(
            BLOOD_REQUEST=donor_req,
            donor_id='DONOR999',
            blood_bag_id='DONOR-BAG-999',
            quantity='350 ml',
            transfusion_date=datetime.date.today(),
            staff_name='Nurse Joy',
            clinical_notes='Completed voluntary donor transfusion'
        )

        # Check hospital dashboard
        self.client.force_login(self.h_user)
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)

        tx_records = response.context['transfusion_records']
        # Find blood bank fulfilled record
        bb_tx = [t for t in tx_records if t.BLOOD_REQUEST_id == self.req.id][0]
        self.assertTrue(bb_tx.is_draft)
        self.assertTrue(bb_tx.can_return_to_bb)

        # Find donor fulfilled record
        donor_tx = [t for t in tx_records if t.BLOOD_REQUEST_id == donor_req.id][0]
        self.assertFalse(donor_tx.is_draft)
        self.assertFalse(donor_tx.can_return_to_bb)

        # Response HTML contains Return to Blood Bank only for the blood bank fulfilled request
        self.assertContains(response, 'Draft')
        self.assertContains(response, 'Return to Blood Bank')

    def test_record_transfusion_details_saved_as_draft_and_fulfillment(self):
        from myapp.models import blood_inventory_table, transfusion_table, blood_allocation_table

        # 1. Set stock and fulfill request from blood bank (2 units)
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '10'
        inv_item.save()

        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })

        # Verify 2 draft records created
        drafts = transfusion_table.objects.filter(BLOOD_REQUEST=self.req).order_by('id')
        self.assertEqual(drafts.count(), 2)
        tx_ids = [d.id for d in drafts]
        for d in drafts:
            self.assertEqual(d.donor_id, f"BB-{self.bloodbank.id:03d}")
            self.assertEqual(d.quantity, '1 Unit')
            self.assertTrue(d.clinical_notes.startswith('Draft:'))

        # 2. Hospital views dashboard
        self.client.force_login(self.h_user)
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)

        # Verify draft_transfusions attached in context
        eligible = response.context['transfusion_eligible']
        req_item = [r for r in eligible if r.id == self.req.id][0]
        self.assertTrue(req_item.has_drafts)
        self.assertEqual(len(req_item.draft_transfusions), 2)

        # Verify HTML contains draft details elements
        self.assertNotContains(response, 'Saved Draft Transfusion Details')
        self.assertContains(response, f'tx-drafts-data-{self.req.id}')
        self.assertContains(response, 'Saved as Draft')

        # 3. Hospital saves updated draft transfusion details (action_type='save')
        response = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.req.id,
            'action_type': 'save',
            'donor_id': [f"BB-{self.bloodbank.id:03d}", f"BB-{self.bloodbank.id:03d}"],
            'blood_bag_id': [f"BB-BAG-{self.req.id:04d}-01", f"BB-BAG-{self.req.id:04d}-02"],
            'quantity': ['1 Unit', '1 Unit'],
            'staff_name': 'dr john',
            'clinical_notes': 'Transfusion draft verified by hospital'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Verify records updated in-place without duplicating
        updated_drafts = transfusion_table.objects.filter(BLOOD_REQUEST=self.req).order_by('id')
        self.assertEqual(updated_drafts.count(), 2)
        self.assertEqual([d.id for d in updated_drafts], tx_ids)
        for d in updated_drafts:
            self.assertEqual(d.staff_name, 'dr john')
            self.assertTrue(d.clinical_notes.startswith('Draft:'))

        # Request still active (DISPATCHED)
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'DISPATCHED')

        # 4. Hospital marks request as fulfilled (action_type='fulfill')
        response = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.req.id,
            'action_type': 'fulfill',
            'donor_id': [f"BB-{self.bloodbank.id:03d}", f"BB-{self.bloodbank.id:03d}"],
            'blood_bag_id': [f"BB-BAG-{self.req.id:04d}-01", f"BB-BAG-{self.req.id:04d}-02"],
            'quantity': ['1 Unit', '1 Unit'],
            'staff_name': 'dr john',
            'clinical_notes': 'Transfusion completed successfully.'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Request now COMPLETED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'COMPLETED')

        # Allocations marked USED
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertEqual(alloc.status, 'USED')

        # Transfusion records finalized, still 2 (no duplicates!)
        final_txs = transfusion_table.objects.filter(BLOOD_REQUEST=self.req).order_by('id')
        self.assertEqual(final_txs.count(), 2)
        self.assertEqual([d.id for d in final_txs], tx_ids)
        for d in final_txs:
            self.assertEqual(d.clinical_notes, 'Transfusion completed successfully.')

        # In hospital dashboard, now status is Saved (not draft)
        resp2 = self.client.get('/myapp/hospital_dashboard/')
        tx_logs = resp2.context['transfusion_records']
        for tx in tx_logs:
            if tx.BLOOD_REQUEST_id == self.req.id:
                self.assertFalse(tx.is_draft)

    def test_return_individual_donated_unit_to_blood_bank(self):
        from myapp.models import blood_inventory_table, transfusion_table, blood_allocation_table

        # Stock 10 units, fulfill 2 units
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '10'
        inv_item.save()

        self.client.force_login(self.bb_user)
        self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })

        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '8')

        drafts = list(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).order_by('id'))
        self.assertEqual(len(drafts), 2)

        # Hospital returns 1st unit
        self.client.force_login(self.h_user)
        response = self.client.post('/myapp/hospital_return_blood/', {
            'request_id': self.req.id,
            'transfusion_id': drafts[0].id
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Inventory increased by 1 (8 -> 9)
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '9')

        # Only 1 transfusion record remains
        remaining = list(transfusion_table.objects.filter(BLOOD_REQUEST=self.req))
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0].id, drafts[1].id)

        # Now return remaining units
        response2 = self.client.post('/myapp/hospital_return_blood/', {
            'request_id': self.req.id
        })
        self.assertRedirects(response2, '/myapp/hospital_dashboard/')

        # Inventory restored back to 10
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '10')

        # Transfusion records completely removed
        self.assertEqual(transfusion_table.objects.filter(BLOOD_REQUEST=self.req).count(), 0)

        # Request status reset to APPROVED
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'APPROVED')

    def test_low_donor_availability_detection_and_bloodbank_supply(self):
        from myapp.models import blood_inventory_table, transfusion_table, blood_allocation_table

        # 1. Setup inventory
        inv_item = blood_inventory_table.objects.get(BLOOD_BANK=self.bloodbank, blood_group='O+')
        inv_item.units_available = '10'
        inv_item.save()

        # 2. Check blood bank view: 0 voluntary donors accepted for self.req (which needs 2 Units)
        self.client.force_login(self.bb_user)
        bb_res = self.client.get('/myapp/bloodbank_home/')
        self.assertEqual(bb_res.status_code, 200)

        # Verify low_donor_requests_count in context
        self.assertGreaterEqual(bb_res.context['low_donor_requests_count'], 1)
        pending = bb_res.context['pending_requests']
        req_in_pending = [r for r in pending if r.id == self.req.id][0]
        self.assertTrue(req_in_pending.is_low_donor_availability)
        self.assertEqual(req_in_pending.accepted_donor_count, 0)
        self.assertEqual(req_in_pending.required_units_count, 2)

        # Verify HTML contains 0/2 donor availability, 6 units bank stock, and Supply Blood button
        self.assertContains(bb_res, '0/2')
        self.assertContains(bb_res, '6')
        self.assertContains(bb_res, 'Supply Blood')
        self.assertNotContains(bb_res, 'Supply Blood (Blood Bank)')
        self.assertContains(bb_res, 'Requests')
        self.assertNotContains(bb_res, 'Low Donor Availability')

        # 3. Blood bank supplies blood
        supply_res = self.client.post('/myapp/bloodbank_home/', {
            'action': 'fulfill_request',
            'request_id': self.req.id
        })
        self.assertRedirects(supply_res, '/myapp/bloodbank_home/')

        # 4. Verify request dispatched and stock deducted
        self.req.refresh_from_db()
        self.assertEqual(self.req.request_status, 'DISPATCHED')

        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '8')

        # 5. Verify allocation created with low donor availability notes
        alloc = blood_allocation_table.objects.filter(BLOOD_REQUEST=self.req).first()
        self.assertIsNotNone(alloc)
        self.assertEqual(alloc.units_allocated, 2)
        self.assertEqual(alloc.status, 'RESERVED')
        self.assertIn('blood bank inventory', alloc.notes.lower())

        # 6. Verify draft transfusion records created
        drafts = transfusion_table.objects.filter(BLOOD_REQUEST=self.req)
        self.assertEqual(drafts.count(), 2)
        for d in drafts:
            self.assertTrue(d.clinical_notes.startswith('Draft:'))
            self.assertNotIn('Low Donor Availability', d.clinical_notes)

        # 7. Verify hospital dashboard shows fulfilled by blood bank
        self.client.force_login(self.h_user)
        hosp_res = self.client.get('/myapp/hospital_dashboard/')
        self.assertNotContains(hosp_res, 'Supplied by Blood Bank')
        self.assertTrue(any(r.id == self.req.id for r in hosp_res.context['transfusion_eligible']))

    def test_low_donor_availability_filter_and_metric_card(self):
        from myapp.models import donor_response_table, donor_table

        # Request 1: self.req (needs 2 Units, 0 accepted donors) -> Low donor availability
        # Request 2: req_sufficient (needs 1 Unit, 1 accepted donor) -> Sufficient
        d_user = User.objects.create_user(username='d_sufficient_user', password='Password@123', email='dsuff@gmail.com')
        d_group, _ = Group.objects.get_or_create(name='donor')
        d_user.groups.add(d_group)
        d_utab = user_table.objects.create(LOGIN=d_user, name='Suff Donor', email='dsuff@gmail.com', phone=9876543201, role='donor', status='active', created_at=datetime.date.today())
        donor_obj = donor_table.objects.create(LOGIN=d_user, USER=d_utab, dob=datetime.date(1995, 1, 1), blood_group='A+', address='Calicut', eligibility_status='eligible')

        req_suff = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='A+',
            units_required='1 Unit',
            location='Ward A',
            description='Surgery',
            request_status='APPROVED',
            emergency='no',
            created_at='2026-09-24',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        donor_response_table.objects.create(
            BLOOD_REQUEST=req_suff,
            DONOR=donor_obj,
            response_status='ACCEPTED',
            response_time='2026-09-24'
        )

        self.client.force_login(self.bb_user)
        bb_res = self.client.get('/myapp/bloodbank_home/')
        self.assertEqual(bb_res.status_code, 200)

        # Context checks
        self.assertEqual(bb_res.context['low_donor_requests_count'], 1)
        pending = bb_res.context['pending_requests']
        low_items = [r for r in pending if r.is_low_donor_availability]
        suff_items = [r for r in pending if not r.is_low_donor_availability]
        self.assertEqual(len(low_items), 1)
        self.assertEqual(low_items[0].id, self.req.id)
        self.assertEqual(len(suff_items), 1)
        self.assertEqual(suff_items[0].id, req_suff.id)

        # Verify HTML elements
        self.assertNotContains(bb_res, 'id="bb-filter-low"')
        self.assertContains(bb_res, 'bb-filter-all')
        self.assertContains(bb_res, 'data-is-low="true"')
        self.assertContains(bb_res, 'data-is-low="false"')
        self.assertContains(bb_res, '1/1')



class HospitalBloodBankRegistrationAndInventoryTests(TestCase):
    def test_hospital_registration_with_blood_bank(self):
        from myapp.models import hospitl_table
        response = self.client.post('/myapp/hospital_registration/', {
            'hospital_name': 'Test Hospital BB',
            'license_number': 'LIC-HOSP-BB',
            'address': 'Hospital Street 2',
            'contact_person': 'Dr. Bob',
            'phone': '1234567890',
            'email': 'hosp_bb@gmail.com',
            'username': 'hosp_bb',
            'password': 'Password@123',
            'confirm_password': 'Password@123',
            'has_blood_bank': 'yes'
        })
        self.assertRedirects(response, '/myapp/loginpage/')
        
        # Verify hospitl_table entry has has_blood_bank as 'yes'
        profile = hospitl_table.objects.get(hospital_name='Test Hospital BB')
        self.assertEqual(profile.has_blood_bank, 'yes')

    def test_hospital_dashboard_inventory_view_and_update(self):
        from myapp.models import hospitl_table, blood_banks_table, blood_inventory_table
        
        # Create hospital user
        user = User.objects.create_user(username='hosp_bb_user', password='Password@123', email='hosp_bb2@gmail.com')
        group, _ = Group.objects.get_or_create(name='hospital')
        user.groups.add(group)
        
        u_tab = user_table.objects.create(
            LOGIN=user,
            name='Test Hospital BB 2',
            email='hosp_bb2@gmail.com',
            phone=1234567890,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        
        profile = hospitl_table.objects.create(
            LOGIN=user,
            USER=u_tab,
            hospital_name='Test Hospital BB 2',
            license_number='LIC-HOSP-BB2',
            address='Hospital Street 2',
            contact_person='Dr. Bob',
            phone=1234567890,
            email='hosp_bb2@gmail.com',
            status='active',
            has_blood_bank='yes'
        )

        self.client.force_login(user)
        # GET request to dashboard should auto-initialize blood bank and inventory
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)
        
        bb_profile = blood_banks_table.objects.filter(LOGIN=user).first()
        self.assertIsNotNone(bb_profile)
        self.assertEqual(bb_profile.blood_bank_name, 'Test Hospital BB 2 Blood Bank')
        
        inv_item = blood_inventory_table.objects.filter(BLOOD_BANK=bb_profile, blood_group='A+').first()
        self.assertIsNotNone(inv_item)
        self.assertEqual(inv_item.units_available, '0')

        # POST request to update inventory
        response = self.client.post('/myapp/hospital_dashboard/', {
            'action': 'update_hospital_inventory',
            'units_A+': '8',
            'units_O+': '14'
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')
        
        inv_item.refresh_from_db()
        self.assertEqual(inv_item.units_available, '8')
        
        inv_op = blood_inventory_table.objects.filter(BLOOD_BANK=bb_profile, blood_group='O+').first()
        self.assertEqual(inv_op.units_available, '14')

        # Check real-time clock and sync components in hospital dashboard
        response_after = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response_after.status_code, 200)
        self.assertContains(response_after, 'hospital-bb-realtime-clock')
        self.assertContains(response_after, 'hospital-bb-realtime-date')
        self.assertContains(response_after, 'hospital-overview-bb-clock')
        self.assertContains(response_after, 'hospital-bb-metric-clock')
        self.assertContains(response_after, 'hospital-live-clock')
        self.assertContains(response_after, 'updateHospitalRealTimeClock')

    def test_hospital_without_bloodbank_no_realtime_clock(self):
        from myapp.models import hospitl_table
        user_no_bb = User.objects.create_user(username='hosp_no_bb', password='Password@123', email='no_bb@gmail.com')
        group, _ = Group.objects.get_or_create(name='hospital')
        user_no_bb.groups.add(group)
        
        u_tab = user_table.objects.create(
            LOGIN=user_no_bb,
            name='Hospital No BB',
            email='no_bb@gmail.com',
            phone=1234567890,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        profile = hospitl_table.objects.create(
            LOGIN=user_no_bb,
            USER=u_tab,
            hospital_name='Hospital No BB',
            license_number='LIC-NO-BB',
            address='Hospital Street',
            contact_person='Dr. None',
            phone=1234567890,
            email='no_bb@gmail.com',
            status='active',
            has_blood_bank='no'
        )

        self.client.force_login(user_no_bb)
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'id="hospital-bb-realtime-clock"')
        self.assertNotContains(response, 'id="tab-panel-inventory"')



class PatientDonorProfileEqualityAndBloodRequestTests(TestCase):
    def setUp(self):
        self.client = Client()
        
        # Setup hospital
        self.h_user = User.objects.create_user(username='test_hosp_eq', password='Password@123', email='test_hosp_eq@gmail.com')
        h_group, _ = Group.objects.get_or_create(name='hospital')
        self.h_user.groups.add(h_group)
        self.h_utab = user_table.objects.create(
            LOGIN=self.h_user,
            name='Equality Test Hospital',
            email='test_hosp_eq@gmail.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=self.h_user,
            USER=self.h_utab,
            hospital_name='Equality Test Hospital',
            license_number='LIC-EQ-123',
            address='Calicut, Kerala',
            contact_person='Dr. Smith',
            phone=9876543210,
            email='test_hosp_eq@gmail.com',
            status='active'
        )

    def test_donor_creates_blood_request_and_syncs_profiles(self):
        # 1. Register donor
        d_user = User.objects.create_user(username='active_donor_1', password='Password@123', email='active_donor1@gmail.com')
        d_group, _ = Group.objects.get_or_create(name='donor')
        d_user.groups.add(d_group)
        d_utab = user_table.objects.create(
            LOGIN=d_user,
            name='Alice Donor',
            email='active_donor1@gmail.com',
            phone=9876543211,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )
        d_profile = donor_table.objects.create(
            LOGIN=d_user,
            USER=d_utab,
            dob=datetime.date(1995, 5, 15),
            blood_group='B+',
            address='Beach Road, Calicut',
            eligibility_status='eligible'
        )

        self.client.force_login(d_user)

        # GET donor_home contains hospitals and modal triggers
        response = self.client.get('/myapp/donor_home/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('hospitals', response.context)
        self.assertContains(response, 'createBloodRequestModal')

        # Submit blood request as donor
        response = self.client.post('/myapp/patient_blood_request/', {
            'patient_name': 'Alice Donor',
            'age': '30',
            'blood_group': 'B+',
            'units_required': '2 Units',
            'hospital': self.hospital.id,
            'location': 'Beach Road, Calicut',
            'required_date': (datetime.date.today() + datetime.timedelta(days=2)).strftime('%Y-%m-%d'),
            'description': 'Urgent requirement for surgical procedure'
        })
        self.assertRedirects(response, '/myapp/donor_home/')

        # Verify blood request was created
        req = blood_requests_table.objects.filter(blood_group='B+', units_required='2 Units').first()
        self.assertIsNotNone(req)
        self.assertEqual(req.patient_name, 'Alice Donor')
        self.assertEqual(req.request_status, 'PENDING')

        # Verify patient profile was automatically created and synced
        p_profile = patient_table.objects.filter(LOGIN=d_user).first()
        self.assertIsNotNone(p_profile)
        self.assertEqual(p_profile.blood_group, d_profile.blood_group)
        self.assertEqual(p_profile.address, d_profile.address)

    def test_patient_creates_blood_request_and_syncs_profiles(self):
        # 1. Register patient
        p_user = User.objects.create_user(username='active_patient_1', password='Password@123', email='active_patient1@gmail.com')
        p_group, _ = Group.objects.get_or_create(name='patient')
        p_user.groups.add(p_group)
        p_utab = user_table.objects.create(
            LOGIN=p_user,
            name='Bob Patient',
            email='active_patient1@gmail.com',
            phone=9876543212,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        p_profile = patient_table.objects.create(
            LOGIN=p_user,
            USER=p_utab,
            HOSPITAL=self.hospital,
            name='Bob Patient',
            dob=datetime.date(1998, 8, 20),
            blood_group='O+',
            address='Main Street, Calicut'
        )

        self.client.force_login(p_user)

        # GET patient_home contains hospitals and modal triggers
        response = self.client.get('/myapp/patient_home/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('hospitals', response.context)
        self.assertContains(response, 'createBloodRequestModal')

        # Submit blood request as patient
        response = self.client.post('/myapp/patient_blood_request/', {
            'patient_name': 'Bob Patient',
            'age': '27',
            'blood_group': 'O+',
            'units_required': '3 Units',
            'hospital': self.hospital.id,
            'location': 'Main Street, Calicut',
            'required_date': (datetime.date.today() + datetime.timedelta(days=1)).strftime('%Y-%m-%d'),
            'description': 'Accident trauma transfusion needed'
        })
        self.assertRedirects(response, '/myapp/patient_home/')

        # Verify blood request was created
        req = blood_requests_table.objects.filter(blood_group='O+', units_required='3 Units').first()
        self.assertIsNotNone(req)
        self.assertEqual(req.patient_name, 'Bob Patient')
        self.assertEqual(req.request_status, 'PENDING')

        # Verify donor profile was automatically created and synced
        d_profile = donor_table.objects.filter(LOGIN=p_user).first()
        self.assertIsNotNone(d_profile)
        self.assertEqual(d_profile.blood_group, p_profile.blood_group)
        self.assertEqual(d_profile.address, p_profile.address)

    def test_edit_profile_syncs_both_tables_equally(self):
        user = User.objects.create_user(username='dual_user', password='Password@123', email='dual@gmail.com')
        group_p, _ = Group.objects.get_or_create(name='patient')
        group_d, _ = Group.objects.get_or_create(name='donor')
        user.groups.add(group_p, group_d)

        utab = user_table.objects.create(
            LOGIN=user,
            name='Original Name',
            email='dual@gmail.com',
            phone=9876543213,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )
        patient = patient_table.objects.create(
            LOGIN=user,
            USER=utab,
            HOSPITAL=self.hospital,
            name='Original Name',
            dob=datetime.date(1990, 1, 1),
            blood_group='A+',
            address='Old Address'
        )
        donor = donor_table.objects.create(
            LOGIN=user,
            USER=utab,
            dob=datetime.date(1990, 1, 1),
            blood_group='A+',
            address='Old Address',
            eligibility_status='eligible'
        )

        self.client.force_login(user)

        # Edit profile with new details
        response = self.client.post('/myapp/edit_profile/', {
            'full_name': 'Updated Equal Name',
            'email': 'updated_dual@gmail.com',
            'phone': '9123456789',
            'blood_group': 'AB+',
            'address': 'New Equal Street 42',
            'last_donation': '2026-01-01'
        })
        self.assertRedirects(response, '/myapp/donor_home/')

        # Refresh from database and verify complete equality across all tables
        utab.refresh_from_db()
        patient.refresh_from_db()
        donor.refresh_from_db()

        self.assertEqual(utab.name, 'Updated Equal Name')
        self.assertEqual(utab.email, 'updated_dual@gmail.com')
        self.assertEqual(utab.phone, 9123456789)

        self.assertEqual(patient.name, 'Updated Equal Name')
        self.assertEqual(patient.blood_group, 'AB+')
        self.assertEqual(patient.address, 'New Equal Street 42')

        self.assertEqual(donor.blood_group, 'AB+')
        self.assertEqual(donor.address, 'New Equal Street 42')
        self.assertEqual(donor.last_donation_date, datetime.date(2026, 1, 1))


class HospitalAssignDonorAndDonorDetailsTests(TestCase):
    def setUp(self):
        self.client = Client()
        
        # Setup hospital
        self.h_user = User.objects.create_user(username='hosp_assign_user', password='Password@123', email='hosp_assign@gmail.com')
        h_group, _ = Group.objects.get_or_create(name='hospital')
        self.h_user.groups.add(h_group)
        self.h_utab = user_table.objects.create(
            LOGIN=self.h_user,
            name='Assign Test Hospital',
            email='hosp_assign@gmail.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=self.h_user,
            USER=self.h_utab,
            hospital_name='Assign Test Hospital',
            license_number='LIC-ASSIGN-99',
            address='Calicut Medical Road',
            contact_person='Dr. Adams',
            phone=9876543210,
            email='hosp_assign@gmail.com',
            status='active'
        )

        # Setup donor
        self.d_user = User.objects.create_user(username='donor_assign_user', password='Password@123', email='donor_assign@gmail.com')
        d_group, _ = Group.objects.get_or_create(name='donor')
        self.d_user.groups.add(d_group)
        self.d_utab = user_table.objects.create(
            LOGIN=self.d_user,
            name='David Volunteer',
            email='david_volunteer@gmail.com',
            phone=9876543299,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )
        self.donor = donor_table.objects.create(
            LOGIN=self.d_user,
            USER=self.d_utab,
            dob=datetime.date(1996, 5, 15),
            blood_group='O+',
            address='123 Donor St, Calicut',
            last_donation_date=datetime.date(2026, 1, 10),
            eligibility_status='eligible'
        )

        # Setup patient request
        self.p_user = User.objects.create_user(username='patient_assign_user', password='Password@123', email='patient_assign@gmail.com')
        p_group, _ = Group.objects.get_or_create(name='patient')
        self.p_user.groups.add(p_group)
        self.p_utab = user_table.objects.create(
            LOGIN=self.p_user,
            name='Patient Peter',
            email='patient_peter@gmail.com',
            phone=9876543288,
            role='patient',
            status='active',
            created_at=datetime.date.today()
        )
        self.patient = patient_table.objects.create(
            LOGIN=self.p_user,
            USER=self.p_utab,
            HOSPITAL=self.hospital,
            name='Patient Peter',
            dob=datetime.date(2000, 1, 1),
            blood_group='O+',
            address='City Center'
        )
        self.blood_req = blood_requests_table.objects.create(
            PATIENT=self.patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='2 Units',
            location='Ward 3B',
            description='Urgent Surgery',
            request_status='APPROVED',
            emergency='no',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            patient_name='Patient Peter',
            age=26,
            required_date=datetime.date.today()
        )

        from myapp.models import donor_response_table
        self.donor_response = donor_response_table.objects.create(
            DONOR=self.donor,
            BLOOD_REQUEST=self.blood_req,
            response_status='ACCEPTED',
            response_time='2026-09-01 12:00'
        )

    def test_hospital_dashboard_displays_donor_details_and_assigns_donor(self):
        from myapp.models import donor_response_table
        self.client.force_login(self.h_user)

        # GET dashboard
        response = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'David Volunteer')
        self.assertContains(response, 'assignDonorModal')
        self.assertContains(response, 'openAssignDonorModal')

        # Check donor_age calculated
        accepted_list = response.context['accepted_donors_list']
        self.assertEqual(len(accepted_list), 1)
        resp_item = accepted_list[0]
        self.assertIsNotNone(resp_item.donor_age)
        self.assertNotEqual(resp_item.donor_age, 'N/A')

        # POST action assign_donor
        response = self.client.post('/myapp/hospital_dashboard/', {
            'action': 'assign_donor',
            'response_id': self.donor_response.id
        })
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        # Verify status is updated to ASSIGNED
        self.donor_response.refresh_from_db()
        self.assertEqual(self.donor_response.response_status, 'ASSIGNED')

        # Verify blood request remains APPROVED and is NOT prematurely marked as COMPLETED
        self.blood_req.refresh_from_db()
        self.assertEqual(self.blood_req.request_status, 'APPROVED')

        # Verify donor is NOT removed from accepted donors list in hospital dashboard
        hosp_resp = self.client.get('/myapp/hospital_dashboard/')
        self.assertEqual(len(hosp_resp.context['accepted_donors_list']), 1)
        self.assertEqual(hosp_resp.context['accepted_donors_list'][0].response_status, 'ASSIGNED')
        self.assertEqual(hosp_resp.context['assigned_donors_count'], 1)
        self.assertEqual(hosp_resp.context['pending_assignment_count'], 0)
        self.assertContains(hosp_resp, 'Assigned Donors')
        self.assertContains(hosp_resp, 'View Details')

        # Verify donor is NOT removed from accepted responses in patient tracking
        self.client.force_login(self.p_user)
        p_res = self.client.get('/myapp/patient_home/')
        self.assertEqual(p_res.status_code, 200)
        p_req = p_res.context['my_requests'][0]
        self.assertEqual(p_req.accepted_count, 1)
        self.assertEqual(len(p_req.accepted_responses), 1)
        self.assertEqual(p_req.accepted_responses[0].response_status, 'ASSIGNED')
        self.assertEqual(p_req.request_status, 'APPROVED')
        self.assertContains(p_res, 'Assigned by Hospital')
        self.assertContains(p_res, 'timeline-badge pending" id="timeline-badge-5"')
        self.assertContains(p_res, 'Waiting for hospital completion confirmation & transfusion recording.')

        # Verify donor is also retained in donor tracking view (when donor also has personal requests)
        from myapp.models import patient_table
        d_patient = patient_table.objects.create(
            LOGIN=self.d_user,
            USER=self.d_utab,
            HOSPITAL=self.hospital,
            name='David Volunteer Patient',
            dob=datetime.date(1996, 5, 15),
            blood_group='O+',
            address='123 Donor St, Calicut'
        )
        d_req_obj = blood_requests_table.objects.create(
            PATIENT=d_patient,
            HOSPITAL=self.hospital,
            blood_group='O+',
            units_required='1 Unit',
            location='Ward 1',
            description='Test',
            request_status='APPROVED',
            emergency='no',
            created_at=datetime.date.today().strftime('%Y-%m-%d'),
            patient_name='David Volunteer Patient',
            age=28,
            required_date=datetime.date.today()
        )
        donor_response_table.objects.create(
            DONOR=self.donor,
            BLOOD_REQUEST=d_req_obj,
            response_status='ASSIGNED',
            response_time='2026-09-01 13:00'
        )
        self.client.force_login(self.d_user)
        d_res = self.client.get('/myapp/donor_home/')
        self.assertEqual(d_res.status_code, 200)
        d_req = d_res.context['my_requests'][0]
        self.assertEqual(d_req.accepted_count, 1)
        self.assertEqual(len(d_req.accepted_responses), 1)
        self.assertEqual(d_req.accepted_responses[0].response_status, 'ASSIGNED')
        self.assertContains(d_res, 'Assigned by Hospital')

        # Transfusion details draft saved (action_type='save') -> Request remains APPROVED
        self.client.force_login(self.h_user)
        draft_res = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.blood_req.id,
            'donor_id': str(self.donor.id),
            'blood_bag_id': 'BAG-2026-001',
            'quantity': '350 ml',
            'staff_name': 'Dr. Test Staff',
            'clinical_notes': 'Transfusion initial unit',
            'action_type': 'save'
        })
        self.assertRedirects(draft_res, '/myapp/hospital_dashboard/')
        self.blood_req.refresh_from_db()
        self.assertEqual(self.blood_req.request_status, 'APPROVED')

        # Hospital staff clicks "Mark Request as Fulfilled" (action_type='fulfill') -> Request marked as COMPLETED
        fulfill_res = self.client.post('/myapp/hospital_save_transfusion/', {
            'request_id': self.blood_req.id,
            'donor_id': str(self.donor.id),
            'blood_bag_id': 'BAG-2026-002',
            'quantity': '350 ml',
            'staff_name': 'Dr. Test Staff',
            'clinical_notes': 'Transfusion completed and request marked fulfilled',
            'action_type': 'fulfill'
        })
        self.assertRedirects(fulfill_res, '/myapp/hospital_dashboard/')

        self.blood_req.refresh_from_db()
        self.assertEqual(self.blood_req.request_status, 'COMPLETED')

        # Hospital view confirms request marked as FULFILLED
        hosp_res_final = self.client.get('/myapp/hospital_dashboard/')
        self.assertContains(hosp_res_final, 'FULFILLED')
        self.assertContains(hosp_res_final, 'Mark Request as Fulfilled')

        # Patient view confirms request marked as Fulfilled in tracking
        self.client.force_login(self.p_user)
        p_res_final = self.client.get('/myapp/patient_home/')
        self.assertEqual(p_res_final.status_code, 200)
        self.assertContains(p_res_final, 'Fulfilled')
        self.assertContains(p_res_final, 'Medical facility confirmed transfusion fulfillment.')
        self.assertEqual(p_res_final.context['my_requests'][0].request_status, 'COMPLETED')

        # Donor view confirms request marked as Fulfilled
        self.client.force_login(self.d_user)
        d_res_final = self.client.get('/myapp/donor_home/')
        self.assertEqual(d_res_final.status_code, 200)
        self.assertContains(d_res_final, 'Fulfilled')


class UsernameUniquenessValidationTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Seed an existing user
        self.existing_user = User.objects.create_user(
            username='global_unique_user',
            password='Password@123',
            email='global_user@test.com'
        )

        # Create a hospital for patient registration tests
        h_user = User.objects.create_user(
            username='hosp_for_unique_test',
            password='Password@123',
            email='hosp_unique@test.com'
        )
        h_user_tab = user_table.objects.create(
            LOGIN=h_user,
            name='Unique Test Hospital',
            email='hosp_unique@test.com',
            phone=9876543210,
            role='hospital',
            status='active',
            created_at=datetime.date.today()
        )
        self.hospital = hospitl_table.objects.create(
            LOGIN=h_user,
            USER=h_user_tab,
            hospital_name='Unique Test Hospital',
            license_number='LIC_UNQ_1',
            address='Unique Address',
            contact_person='Dr. Unique',
            phone=9876543210,
            email='hosp_unique@test.com',
            status='active'
        )

    def test_donor_registration_duplicate_username_fails(self):
        # Exact match
        response = self.client.post('/myapp/donor_registration/', {
            'full_name': 'Donor Duplicate Test',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'new_donor@test.com',
            'address': '123 Test St',
            'last_donation': '',
            'username': 'global_unique_user',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

        # Case-insensitive match
        response = self.client.post('/myapp/donor_registration/', {
            'full_name': 'Donor Duplicate Test Case',
            'dob': '2000-01-01',
            'blood_group': 'O+',
            'gender': 'Male',
            'phone': '9876543210',
            'email': 'new_donor2@test.com',
            'address': '123 Test St',
            'last_donation': '',
            'username': 'Global_Unique_User',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

    def test_patient_registration_duplicate_username_fails(self):
        response = self.client.post('/myapp/patient_registration/', {
            'full_name': 'Patient Duplicate Test',
            'dob': '2000-01-01',
            'gender': 'Female',
            'blood_group': 'A+',
            'phone': '9876543210',
            'email': 'new_patient@test.com',
            'address': '456 Patient St',
            'hospital': self.hospital.id,
            'username': 'global_unique_user',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

        # Case-insensitive
        response = self.client.post('/myapp/patient_registration/', {
            'full_name': 'Patient Duplicate Test',
            'dob': '2000-01-01',
            'gender': 'Female',
            'blood_group': 'A+',
            'phone': '9876543210',
            'email': 'new_patient2@test.com',
            'address': '456 Patient St',
            'hospital': self.hospital.id,
            'username': 'GLOBAL_UNIQUE_USER',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

    def test_hospital_registration_duplicate_username_fails(self):
        response = self.client.post('/myapp/hospital_registration/', {
            'hospital_name': 'Duplicate Hospital',
            'license_number': 'LIC_DUP_1',
            'address': 'Hospital Road',
            'contact_person': 'Dr. Dup',
            'phone': '9876543210',
            'email': 'new_hosp@test.com',
            'username': 'GLOBAL_UNIQUE_USER',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

    def test_bloodbank_registration_duplicate_username_fails(self):
        response = self.client.post('/myapp/bloodbank_registration/', {
            'bloodbank_name': 'Duplicate Bank',
            'license_number': 'LIC_BB_DUP',
            'contact_person': 'Bank Manager',
            'address': 'Bank St',
            'phone': '9876543210',
            'email': 'new_bank@test.com',
            'username': 'global_unique_user',
            'password': 'Password@123',
            'confirm_password': 'Password@123'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Username is already taken!")

    def test_edit_profile_duplicate_username_fails(self):
        # Create user to edit
        user2 = User.objects.create_user(
            username='user_to_edit',
            password='Password@123',
            email='edit_user@test.com'
        )
        group, _ = Group.objects.get_or_create(name='donor')
        user2.groups.add(group)
        u_tab = user_table.objects.create(
            LOGIN=user2,
            name='User To Edit',
            email='edit_user@test.com',
            phone=9876543210,
            role='donor',
            status='active',
            created_at=datetime.date.today()
        )
        donor_table.objects.create(
            LOGIN=user2,
            USER=u_tab,
            dob=datetime.date(2000, 1, 1),
            blood_group='O+',
            address='123 St',
            eligibility_status='eligible'
        )

        self.client.force_login(user2)
        response = self.client.post('/myapp/edit_profile/', {
            'full_name': 'User To Edit',
            'email': 'edit_user@test.com',
            'phone': '9876543210',
            'blood_group': 'O+',
            'address': '123 St',
            'username': 'Global_Unique_User'
        })
        # Should redirect with error
        self.assertRedirects(response, '/myapp/donor_home/')
        user2.refresh_from_db()
        self.assertEqual(user2.username, 'user_to_edit')


class BloodRequestDeletionAndListingTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Create hospital
        hosp_user = User.objects.create_user(username='testhospital', password='Password@123', email='hosp@test.com')
        group_hosp, _ = Group.objects.get_or_create(name='hospital')
        hosp_user.groups.add(group_hosp)
        u_hosp = user_table.objects.create(
            LOGIN=hosp_user, name='City Hospital', email='hosp@test.com', phone=9876543210, role='hospital', status='active', created_at=datetime.date.today()
        )
        self.hospital_user = hosp_user
        self.hospital = hospitl_table.objects.create(
            LOGIN=hosp_user, USER=u_hosp, hospital_name='City Hospital', license_number='LIC123', address='Hospital Road', contact_person='Dr. John', phone=9876543210, email='hosp@test.com', status='active'
        )

        # Create donor user 1
        self.donor_user1 = User.objects.create_user(username='donor1', password='Password@123', email='donor1@test.com')
        group_donor, _ = Group.objects.get_or_create(name='donor')
        self.donor_user1.groups.add(group_donor)
        self.u_donor1 = user_table.objects.create(
            LOGIN=self.donor_user1, name='Donor One', email='donor1@test.com', phone=9876543211, role='donor', status='active', created_at=datetime.date.today()
        )
        self.donor_profile1 = donor_table.objects.create(
            LOGIN=self.donor_user1, USER=self.u_donor1, dob=datetime.date(1995, 5, 5), blood_group='A+', address='Street 1', eligibility_status='eligible'
        )

        # Create donor user 2
        self.donor_user2 = User.objects.create_user(username='donor2', password='Password@123', email='donor2@test.com')
        self.donor_user2.groups.add(group_donor)
        self.u_donor2 = user_table.objects.create(
            LOGIN=self.donor_user2, name='Donor Two', email='donor2@test.com', phone=9876543212, role='donor', status='active', created_at=datetime.date.today()
        )
        self.donor_profile2 = donor_table.objects.create(
            LOGIN=self.donor_user2, USER=self.u_donor2, dob=datetime.date(1996, 6, 6), blood_group='B+', address='Street 2', eligibility_status='eligible'
        )

        # Create patient record for donor 1
        self.patient_rec1 = patient_table.objects.create(
            LOGIN=self.donor_user1,
            USER=self.u_donor1,
            HOSPITAL=self.hospital,
            name='Donor Patient 1',
            blood_group='A+',
            address='Street 1'
        )

        # Create patient record for donor 2
        self.patient_rec2 = patient_table.objects.create(
            LOGIN=self.donor_user2,
            USER=self.u_donor2,
            HOSPITAL=self.hospital,
            name='Donor Patient 2',
            blood_group='B+',
            address='Street 2'
        )

    def test_delete_pending_blood_request_success_donor(self):
        # Create pending request for donor 1
        req = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='Patient 1',
            blood_group='A+',
            units_required='2',
            emergency='yes',
            description='Surgery',
            location='Hospital Road',
            request_status='PENDING',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        req_id = req.id

        self.client.force_login(self.donor_user1)
        response = self.client.post('/myapp/delete_blood_request/', {'request_id': req_id})
        self.assertRedirects(response, '/myapp/donor_home/?tab=myrequests')
        self.assertFalse(blood_requests_table.objects.filter(id=req_id).exists())

    def test_delete_pending_blood_request_success_patient(self):
        # Create patient user
        pat_user = User.objects.create_user(username='pat1', password='Password@123', email='pat1@test.com')
        group_pat, _ = Group.objects.get_or_create(name='patient')
        pat_user.groups.add(group_pat)
        u_pat = user_table.objects.create(
            LOGIN=pat_user, name='Patient User', email='pat1@test.com', phone=9876543213, role='patient', status='active', created_at=datetime.date.today()
        )
        patient_rec = patient_table.objects.create(
            LOGIN=pat_user, USER=u_pat, HOSPITAL=self.hospital, name='Patient User', blood_group='O-', address='Patient Address'
        )
        req = blood_requests_table.objects.create(
            PATIENT=patient_rec,
            HOSPITAL=self.hospital,
            patient_name='Patient User',
            blood_group='O-',
            units_required='1',
            emergency='no',
            description='Transfusion',
            location='Hospital Road',
            request_status='PENDING',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=3)
        )

        self.client.force_login(pat_user)
        response = self.client.post('/myapp/delete_blood_request/', {'request_id': req.id})
        self.assertRedirects(response, '/myapp/patient_home/?tab=myrequests')
        self.assertFalse(blood_requests_table.objects.filter(id=req.id).exists())

    def test_delete_approved_blood_request_forbidden(self):
        # Approved blood request cannot be deleted
        req = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='Patient 1',
            blood_group='A+',
            units_required='2',
            emergency='yes',
            description='Surgery',
            location='Hospital Road',
            request_status='APPROVED',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        self.client.force_login(self.donor_user1)
        response = self.client.post('/myapp/delete_blood_request/', {'request_id': req.id})
        self.assertRedirects(response, '/myapp/donor_home/?tab=myrequests')
        self.assertTrue(blood_requests_table.objects.filter(id=req.id).exists())

    def test_delete_other_user_request_forbidden(self):
        # Donor 1 tries to delete Donor 2's request
        req2 = blood_requests_table.objects.create(
            PATIENT=self.patient_rec2,
            HOSPITAL=self.hospital,
            patient_name='Patient 2',
            blood_group='B+',
            units_required='1',
            emergency='no',
            description='Routine',
            location='Hospital Road',
            request_status='PENDING',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        self.client.force_login(self.donor_user1)
        response = self.client.post('/myapp/delete_blood_request/', {'request_id': req2.id})
        self.assertRedirects(response, '/myapp/donor_home/?tab=myrequests')
        self.assertTrue(blood_requests_table.objects.filter(id=req2.id).exists())

    def test_donor_home_my_requests_multiple_listed(self):
        # Create 2 requests for donor 1: one pending, one approved
        req_pending = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='First Patient',
            blood_group='A+',
            units_required='2',
            emergency='yes',
            description='First Request Detail',
            location='Hospital Road',
            request_status='PENDING',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        req_approved = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='Second Patient',
            blood_group='A+',
            units_required='3',
            emergency='yes',
            description='Second Request Detail',
            location='Hospital Road',
            request_status='APPROVED',
            created_at='2026-09-09 11:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=1)
        )

        self.client.force_login(self.donor_user1)
        response = self.client.get('/myapp/donor_home/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('my_requests', response.context)
        my_reqs = list(response.context['my_requests'])
        self.assertEqual(len(my_reqs), 2)
        self.assertContains(response, 'First Request Detail')
        self.assertContains(response, 'Second Request Detail')
        self.assertContains(response, 'Delete Request')

    def test_patient_cannot_mark_request_as_fulfilled(self):
        pat_user = User.objects.create_user(username='pat_complete', password='Password@123', email='pat_c@test.com')
        group_pat, _ = Group.objects.get_or_create(name='patient')
        pat_user.groups.add(group_pat)
        u_pat = user_table.objects.create(
            LOGIN=pat_user, name='Patient Complete', email='pat_c@test.com', phone=9876543299, role='patient', status='active', created_at=datetime.date.today()
        )
        patient_rec = patient_table.objects.create(
            LOGIN=pat_user, USER=u_pat, HOSPITAL=self.hospital, name='Patient Complete', blood_group='A+', address='Patient Address'
        )
        req = blood_requests_table.objects.create(
            PATIENT=patient_rec,
            HOSPITAL=self.hospital,
            patient_name='Patient Complete',
            blood_group='A+',
            units_required='2 Units',
            emergency='no',
            description='Post-op blood',
            location='Hospital Road',
            request_status='APPROVED',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=1)
        )

        self.client.force_login(pat_user)
        # Attempt to mark fulfilled by patient -> should be denied
        response = self.client.post('/myapp/complete_blood_request/', {'request_id': req.id})
        self.assertRedirects(response, '/myapp/patient_home/?tab=myrequests')
        
        req.refresh_from_db()
        self.assertEqual(req.request_status, 'APPROVED')  # Not completed

        # Verify patient page does NOT contain fulfillment button or modal
        home_res = self.client.get('/myapp/patient_home/')
        self.assertNotContains(home_res, 'id="myreq-det-complete-btn"')
        self.assertNotContains(home_res, 'id="timeline-complete-btn"')
        self.assertNotContains(home_res, 'id="completeRequestModal"')

    def test_donor_cannot_mark_request_as_fulfilled(self):
        req = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='Donor User Request',
            blood_group='A+',
            units_required='1 Unit',
            emergency='no',
            description='Surgery recovery',
            location='Hospital Road',
            request_status='APPROVED',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )

        self.client.force_login(self.donor_user1)
        # Attempt to mark fulfilled by donor -> should be denied
        response = self.client.post('/myapp/complete_blood_request/', {'request_id': req.id})
        self.assertRedirects(response, '/myapp/donor_home/?tab=myrequests')

        req.refresh_from_db()
        self.assertEqual(req.request_status, 'APPROVED')  # Not completed

        # Verify donor page does NOT contain fulfillment button or modal
        home_res = self.client.get('/myapp/donor_home/')
        self.assertNotContains(home_res, 'id="myreq-det-complete-btn"')
        self.assertNotContains(home_res, 'id="timeline-complete-btn"')
        self.assertNotContains(home_res, 'id="completeRequestModal"')

    def test_hospital_can_mark_request_as_fulfilled(self):
        req = blood_requests_table.objects.create(
            PATIENT=self.patient_rec1,
            HOSPITAL=self.hospital,
            patient_name='Hospital Fulfilled Test',
            blood_group='A+',
            units_required='1 Unit',
            emergency='no',
            description='Hospital fulfillment test',
            location='Hospital Road',
            request_status='APPROVED',
            created_at='2026-09-09 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )

        self.client.force_login(self.hospital_user)
        response = self.client.post('/myapp/complete_blood_request/', {'request_id': req.id})
        self.assertRedirects(response, '/myapp/hospital_dashboard/')

        req.refresh_from_db()
        self.assertEqual(req.request_status, 'COMPLETED')


class LocationUtilsTests(TestCase):
    def setUp(self):
        self.hospital_group, _ = Group.objects.get_or_create(name='hospital')
        self.bb_group, _ = Group.objects.get_or_create(name='bloodbank')
        self.donor_group, _ = Group.objects.get_or_create(name='donor')

        # Create hospital in Kozhikode
        h_user1 = User.objects.create_user(username='hosp_calicut', password='Password@123', email='hosp1@test.com')
        h_user1.groups.add(self.hospital_group)
        u_h1 = user_table.objects.create(LOGIN=h_user1, name='Calicut Beach Hospital', email='hosp1@test.com', phone=9876543211, role='hospital', status='active', created_at=datetime.date.today())
        self.hosp_calicut = hospitl_table.objects.create(LOGIN=h_user1, USER=u_h1, hospital_name='Calicut Beach Hospital', license_number='LIC101', address='Kozhikode, Kerala', contact_person='Dr. Nair', phone=9876543211, email='hosp1@test.com', status='active')

        # Create hospital in Kochi / Ernakulam
        h_user2 = User.objects.create_user(username='hosp_kochi', password='Password@123', email='hosp2@test.com')
        h_user2.groups.add(self.hospital_group)
        u_h2 = user_table.objects.create(LOGIN=h_user2, name='Kochi General Hospital', email='hosp2@test.com', phone=9876543212, role='hospital', status='active', created_at=datetime.date.today())
        self.hosp_kochi = hospitl_table.objects.create(LOGIN=h_user2, USER=u_h2, hospital_name='Kochi General Hospital', license_number='LIC102', address='Ernakulam, Kochi', contact_person='Dr. Menon', phone=9876543212, email='hosp2@test.com', status='active')

        # Create Blood Bank in Kozhikode
        bb_user1 = User.objects.create_user(username='bb_calicut', password='Password@123', email='bb1@test.com')
        bb_user1.groups.add(self.bb_group)
        u_bb1 = user_table.objects.create(LOGIN=bb_user1, name='Calicut Blood Bank', email='bb1@test.com', phone=9876543213, role='bloodbank', status='active', created_at=datetime.date.today())
        self.bb_calicut = blood_banks_table.objects.create(LOGIN=bb_user1, blood_bank_name='Calicut Central Blood Bank', license_number='BBLIC1', address='Mavoor Road, Kozhikode', contact_person='Officer Roy', phone=9876543213, email='bb1@test.com', status='active')

        # Create Donors
        d_user1 = User.objects.create_user(username='donor_calicut', password='Password@123', email='d1@test.com')
        d_user1.groups.add(self.donor_group)
        u_d1 = user_table.objects.create(LOGIN=d_user1, name='Calicut Donor', email='d1@test.com', phone=9876543214, role='donor', status='active', created_at=datetime.date.today())
        self.donor_calicut = donor_table.objects.create(LOGIN=d_user1, USER=u_d1, blood_group='O+', dob=datetime.date(1995, 1, 1), address='Kozhikode, Kerala', last_donation_date='2026-01-01', eligibility_status='eligible')

    def test_haversine_distance_calculation(self):
        from myapp.location_utils import haversine_distance
        # Kozhikode to Ernakulam is ~135-155 km in straight line
        dist = haversine_distance(11.2588, 75.7804, 9.9816, 76.2999)
        self.assertGreater(dist, 130)
        self.assertLess(dist, 160)

    def test_calculate_distance_km(self):
        from myapp.location_utils import calculate_distance_km
        dist_same = calculate_distance_km('Kozhikode', 'Kozhikode')
        self.assertEqual(dist_same, 0.0)

        dist_diff = calculate_distance_km('Kozhikode', 'Kochi')
        self.assertGreater(dist_diff, 100)

    def test_calculate_distance_fallback_no_crash(self):
        from myapp.location_utils import calculate_distance_km
        # Unknown or custom addresses should resolve gracefully without exceptions
        dist = calculate_distance_km('Unknown Villa 42, XYZ Nagar', 'Kozhikode, Kerala')
        self.assertIsInstance(dist, float)
        self.assertGreaterEqual(dist, 0.0)

    def test_format_distance_str(self):
        from myapp.location_utils import format_distance_str
        self.assertEqual(format_distance_str(0.5), '500 m away')
        self.assertEqual(format_distance_str(0.0), '0 m away')
        self.assertEqual(format_distance_str(2.4), '2.4 km away')
        self.assertEqual(format_distance_str(15.8), '15.8 km away')

    def test_blood_compatibility_matrix(self):
        from myapp.location_utils import is_blood_compatible, get_compatible_donor_groups
        # O- is universal donor (can donate to everyone)
        all_groups = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+']
        for group in all_groups:
            self.assertTrue(is_blood_compatible('O-', group), f"O- should be compatible donor for recipient {group}")

        # AB+ is universal recipient (can receive from everyone)
        for group in all_groups:
            self.assertTrue(is_blood_compatible(group, 'AB+'), f"{group} should be compatible donor for recipient AB+")

        # AB+ can only donate to AB+
        self.assertTrue(is_blood_compatible('AB+', 'AB+'))
        self.assertFalse(is_blood_compatible('AB+', 'A+'))
        self.assertFalse(is_blood_compatible('AB+', 'O+'))

        # O+ can donate to O+, A+, B+, AB+
        self.assertTrue(is_blood_compatible('O+', 'O+'))
        self.assertTrue(is_blood_compatible('O+', 'A+'))
        self.assertTrue(is_blood_compatible('O+', 'B+'))
        self.assertTrue(is_blood_compatible('O+', 'AB+'))
        self.assertFalse(is_blood_compatible('O+', 'O-'))
        self.assertFalse(is_blood_compatible('O+', 'A-'))

        # get_compatible_donor_groups for B+
        donors_for_b_plus = get_compatible_donor_groups('B+')
        self.assertEqual(set(donors_for_b_plus), {'O-', 'O+', 'B-', 'B+'})

    def test_get_nearest_hospitals(self):
        from myapp.location_utils import get_nearest_hospitals
        # From Kozhikode, Calicut Beach Hospital should be ranked closest
        ranked = get_nearest_hospitals('Kozhikode, Kerala', limit=10)
        self.assertGreaterEqual(len(ranked), 2)
        self.assertEqual(ranked[0]['hospital'].id, self.hosp_calicut.id)
        self.assertLess(ranked[0]['distance_km'], ranked[1]['distance_km'])

    def test_get_nearest_blood_banks(self):
        from myapp.location_utils import get_nearest_blood_banks
        ranked = get_nearest_blood_banks('Kozhikode', limit=5)
        self.assertGreaterEqual(len(ranked), 1)
        self.assertEqual(ranked[0]['blood_bank'].id, self.bb_calicut.id)

    def test_get_nearest_donors_with_compatibility(self):
        from myapp.location_utils import get_nearest_donors
        # Donor is O+, recipient is AB+ (compatible)
        ranked = get_nearest_donors('Kozhikode', blood_group='AB+', limit=5)
        self.assertGreaterEqual(len(ranked), 1)
        self.assertEqual(ranked[0]['donor'].id, self.donor_calicut.id)
        self.assertTrue(ranked[0]['is_compatible'])


class ApiNearbyFacilitiesTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.hospital_group, _ = Group.objects.get_or_create(name='hospital')
        self.bb_group, _ = Group.objects.get_or_create(name='bloodbank')

        h_user = User.objects.create_user(username='hosp_api', password='Password@123', email='hapi@test.com')
        h_user.groups.add(self.hospital_group)
        u_h = user_table.objects.create(LOGIN=h_user, name='API Hospital', email='hapi@test.com', phone=9876543211, role='hospital', status='active', created_at=datetime.date.today())
        self.hosp = hospitl_table.objects.create(LOGIN=h_user, USER=u_h, hospital_name='API Hospital', license_number='LICAPI1', address='Kozhikode, Kerala', contact_person='Dr. Test', phone=9876543211, email='hapi@test.com', status='active')

        bb_user = User.objects.create_user(username='bb_api', password='Password@123', email='bbapi@test.com')
        bb_user.groups.add(self.bb_group)
        u_bb = user_table.objects.create(LOGIN=bb_user, name='API Blood Bank', email='bbapi@test.com', phone=9876543212, role='bloodbank', status='active', created_at=datetime.date.today())
        self.bb = blood_banks_table.objects.create(LOGIN=bb_user, blood_bank_name='API Blood Bank', license_number='BBLICAPI1', address='Kozhikode, Kerala', contact_person='Manager API', phone=9876543212, email='bbapi@test.com', status='active')

    def test_api_nearby_facilities_success(self):
        response = self.client.get('/myapp/api/nearby-facilities/?location=Kozhikode&blood_group=A+')
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data['success'])
        self.assertEqual(data['location'], 'Kozhikode')
        self.assertIn('hospitals', data)
        self.assertIn('blood_banks', data)
        self.assertIn('donors', data)
        self.assertGreaterEqual(len(data['hospitals']), 1)
        self.assertEqual(data['hospitals'][0]['name'], 'API Hospital')
        self.assertIn('distance_str', data['hospitals'][0])


class ProximityBloodRequestIntegrationTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.patient_group, _ = Group.objects.get_or_create(name='patient')
        self.hospital_group, _ = Group.objects.get_or_create(name='hospital')
        self.donor_group, _ = Group.objects.get_or_create(name='donor')

        # Hospital in Kozhikode
        h_user1 = User.objects.create_user(username='hosp_cal', password='Password@123', email='hospcal@test.com')
        h_user1.groups.add(self.hospital_group)
        u_h1 = user_table.objects.create(LOGIN=h_user1, name='Calicut Hospital', email='hospcal@test.com', phone=9876543211, role='hospital', status='active', created_at=datetime.date.today())
        self.hosp_cal = hospitl_table.objects.create(LOGIN=h_user1, USER=u_h1, hospital_name='Calicut Hospital', license_number='LICCAL1', address='Kozhikode, Kerala', contact_person='Dr. Cal', phone=9876543211, email='hospcal@test.com', status='active')

        # Hospital in Trivandrum
        h_user2 = User.objects.create_user(username='hosp_tvm', password='Password@123', email='hosptvm@test.com')
        h_user2.groups.add(self.hospital_group)
        u_h2 = user_table.objects.create(LOGIN=h_user2, name='Trivandrum Hospital', email='hosptvm@test.com', phone=9876543212, role='hospital', status='active', created_at=datetime.date.today())
        self.hosp_tvm = hospitl_table.objects.create(LOGIN=h_user2, USER=u_h2, hospital_name='Trivandrum Hospital', license_number='LICTVM1', address='Thiruvananthapuram, Kerala', contact_person='Dr. TVM', phone=9876543212, email='hosptvm@test.com', status='active')

        # Patient in Kozhikode
        self.pat_user = User.objects.create_user(username='patient_cal', password='Password@123', email='patcal@test.com')
        self.pat_user.groups.add(self.patient_group)
        u_pat = user_table.objects.create(LOGIN=self.pat_user, name='Patient Calicut', email='patcal@test.com', phone=9876543213, role='patient', status='active', created_at=datetime.date.today())
        self.patient_rec = patient_table.objects.create(LOGIN=self.pat_user, USER=u_pat, HOSPITAL=self.hosp_cal, name='Patient Calicut', blood_group='B+', address='Kozhikode, Kerala', is_first_login=False)

        # Donor in Kozhikode
        self.donor_user = User.objects.create_user(username='donor_cal', password='Password@123', email='donorcal@test.com')
        self.donor_user.groups.add(self.donor_group)
        u_don = user_table.objects.create(LOGIN=self.donor_user, name='Donor Calicut', email='donorcal@test.com', phone=9876543214, role='donor', status='active', created_at=datetime.date.today())
        self.donor_rec = donor_table.objects.create(LOGIN=self.donor_user, USER=u_don, blood_group='B+', dob=datetime.date(1998, 1, 1), address='Kozhikode, Kerala', last_donation_date='2026-01-01', eligibility_status='eligible')

    def test_patient_blood_request_page_does_not_show_distance(self):
        self.client.force_login(self.pat_user)
        response = self.client.get('/myapp/patient_blood_request/')
        self.assertEqual(response.status_code, 200)
        self.assertNotIn('nearest_hospitals', response.context)
        self.assertNotIn('nearest_bloodbanks', response.context)
        self.assertNotContains(response, 'Sorted by Proximity')
        self.assertNotContains(response, 'Nearby Healthcare & Blood Facilities')
        self.assertNotContains(response, 'km away')

    def test_patient_blood_request_submission(self):
        self.client.force_login(self.pat_user)
        future_date = (datetime.date.today() + datetime.timedelta(days=2)).strftime('%Y-%m-%d')
        response = self.client.post('/myapp/patient_blood_request/', {
            'patient_name': 'Emergency Patient',
            'age': '30',
            'blood_group': 'B+',
            'units_required': '2 Units',
            'required_date': future_date,
            'hospital': str(self.hosp_cal.id),
            'location': 'Kozhikode, Kerala',
            'description': 'Urgent requirement in Kozhikode'
        })
        self.assertRedirects(response, '/myapp/patient_home/')
        # Verify created request was associated with selected hospital
        req = blood_requests_table.objects.filter(patient_name='Emergency Patient').first()
        self.assertIsNotNone(req)
        self.assertEqual(req.HOSPITAL.id, self.hosp_cal.id)

    def test_donor_home_ranks_requests_by_proximity(self):
        # Create request 1 in Trivandrum (far)
        req_far = blood_requests_table.objects.create(
            PATIENT=self.patient_rec,
            HOSPITAL=self.hosp_tvm,
            patient_name='Far Patient',
            blood_group='B+',
            units_required='1',
            emergency='no',
            description='Far request in Trivandrum',
            location='Thiruvananthapuram, Kerala',
            request_status='APPROVED',
            created_at='2026-09-10 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=3)
        )
        # Create request 2 in Kozhikode (near)
        req_near = blood_requests_table.objects.create(
            PATIENT=self.patient_rec,
            HOSPITAL=self.hosp_cal,
            patient_name='Near Patient',
            blood_group='B+',
            units_required='1',
            emergency='yes',
            description='Near request in Kozhikode',
            location='Kozhikode, Kerala',
            request_status='APPROVED',
            created_at='2026-09-10 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )

        self.client.force_login(self.donor_user)
        response = self.client.get('/myapp/donor_home/')
        self.assertEqual(response.status_code, 200)
        requests_list = list(response.context['verified_requests'])
        # The nearest request (Kozhikode) must be ranked before the far one (Trivandrum)
        self.assertGreaterEqual(len(requests_list), 2)
        self.assertEqual(requests_list[0].id, req_near.id)
        self.assertEqual(requests_list[1].id, req_far.id)
        self.assertNotContains(response, 'Nearest First')
        self.assertNotContains(response, 'Proximity Distance')

    def test_patient_home_blood_requests_feed_does_not_show_distance(self):
        # Create other patient and request in Kozhikode
        other_user = User.objects.create_user(username='other_pat', password='Password@123', email='otherpat@test.com')
        other_user.groups.add(self.patient_group)
        u_other = user_table.objects.create(LOGIN=other_user, name='Other Patient', email='otherpat@test.com', phone=9876543299, role='patient', status='active', created_at=datetime.date.today())
        other_patient_rec = patient_table.objects.create(LOGIN=other_user, USER=u_other, HOSPITAL=self.hosp_cal, name='Other Patient', blood_group='B+', address='Kozhikode, Kerala', is_first_login=False)

        req = blood_requests_table.objects.create(
            PATIENT=other_patient_rec,
            HOSPITAL=self.hosp_cal,
            patient_name='Other Patient',
            blood_group='B+',
            units_required='1',
            emergency='no',
            description='Test request',
            location='Kozhikode, Kerala',
            request_status='APPROVED',
            created_at='2026-09-10 10:00:00',
            required_date=datetime.date.today() + datetime.timedelta(days=2)
        )
        self.client.force_login(self.pat_user)
        response = self.client.get('/myapp/patient_home/')
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'Nearest First')
        self.assertNotContains(response, 'Proximity Distance')

    def test_question_mark_icon_removed_from_navbars(self):
        # Test patient home navbar
        self.client.force_login(self.pat_user)
        res_pat = self.client.get('/myapp/patient_home/')
        self.assertEqual(res_pat.status_code, 200)
        self.assertNotContains(res_pat, 'bi-question-circle')

        # Test patient blood request navbar
        res_req = self.client.get('/myapp/patient_blood_request/')
        self.assertEqual(res_req.status_code, 200)
        self.assertNotContains(res_req, 'bi-question-circle')

        # Test donor home navbar
        self.client.force_login(self.donor_user)
        res_don = self.client.get('/myapp/donor_home/')
        self.assertEqual(res_don.status_code, 200)
        self.assertNotContains(res_don, 'bi-question-circle')










