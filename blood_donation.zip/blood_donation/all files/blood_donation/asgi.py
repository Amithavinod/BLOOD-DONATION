"""
ASGI config for blood_donation project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""

import os
import sys
from pathlib import Path

# Add 'all files' folder to system path dynamically
all_files_path = Path(__file__).resolve().parent.parent
if str(all_files_path) not in sys.path:
    sys.path.insert(0, str(all_files_path))

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'blood_donation.settings')

application = get_asgi_application()

