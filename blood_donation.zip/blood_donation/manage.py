#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Run administrative tasks."""
    # Add 'all files' folder to system path dynamically to avoid ModuleNotFoundError
    from pathlib import Path
    all_files_path = Path(__file__).resolve().parent / "all files"
    if str(all_files_path) not in sys.path:
        sys.path.insert(0, str(all_files_path))

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'blood_donation.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
